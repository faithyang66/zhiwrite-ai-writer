# 智写AI（ZhiWrite AI Writer）开发 TODO（分步实现）

> 目标：在不牺牲 WordPress 后台性能的前提下，把配置与生成工作流做得“可控、可观测、可扩展”。
> 原则：**先底座、再体验、再高级**；所有功能都要有权限与可回滚策略。

---

## 可实现性说明（必须先统一预期）

- **纯插件内可实现（100%）**：配置项、权限、日志、导入导出、生成模板、发布流程、基础 SEO 规则、内部链接策略（基于站内数据）、失败诊断等。
- **依赖第三方/模型能力（可实现但受限）**：内容安全检测、事实核查、真实费用结算（不同厂商计费口径）、外部 webhook 工作流等。此类功能可以做“接口化 + 可选开关 + 降级策略”，但无法保证所有环境都一致。

---

## Phase 1：底座（稳定性 + 可观测 + 权限）

### 1.1 请求可靠性
- [x] **重试策略**：次数、退避、仅对幂等/特定错误重试  
  - 已实现：`Retry-After`/429/5xx 等错误的重试与退避（可配置）
- [x] **超时策略增强**：连接超时/响应超时（若当前 HTTP 客户端支持）  
  - 已实现：请求超时可配置（用于 `wp_remote_request`）
- [x] **失败降级**：统一错误码映射，用户可读提示 + 技术详情（管理员可见）  
  - 已实现：生成失败返回可读错误；后台日志保留技术细节（供管理员排查）

### 1.2 并发与队列（避免后台卡顿）
- [x] **并发上限**：同一用户/全站并发限制  
  - 已实现：基于 WP options 的最佳努力锁（带 TTL），返回 `busy` 提示；可配置用户并发/全局并发/锁 TTL
- [x] **队列执行器**：WP-Cron/Action Scheduler（若引入）/自建轻量队列（取舍待定）  
  - 已实现：新增任务表 + WP-Cron 处理器；提供「后台队列」开关，开启后生成任务入队后台执行
- [x] **任务状态机**：pending/running/succeeded/failed/cancelled + 重跑  
  - 已实现：任务表包含 `pending/running/succeeded/failed/cancelled` 状态字段；当前实现 pending→running→succeeded/failed，并支持前端拉取结果

### 1.3 权限细分与安全
- [x] **能力开关**：哪些角色可生成、可改模板、可查看 key、可看日志  
  - 已实现：生成/日志的 capability 可分别配置（`manage_options` / `edit_posts`），菜单与 AJAX 权限同步生效
- [x] **敏感配置保护**：API Key 显示/编辑策略（遮罩、仅管理员可见）  
  - 已实现：Key 不回显到 HTML；未填写新 Key 时保存会保留旧 Key；“测试接口”支持使用已保存的 Key（前端不传 Key）
- [x] **Nonce/CSRF**：所有后台 action 与 ajax 统一校验  
  - 已核对：当前所有 `wp_ajax_*` 入口均已统一使用 `check_ajax_referer('zhiwrite_ai_nonce','nonce')`

### 1.4 观测与审计
- [x] **审计日志**：谁、何时、用哪个接口/模板、生成了什么（内容可选脱敏）  
  - 已实现：设置变更审计、生成请求/响应摘要日志（用于追踪问题）
- [x] **诊断导出**：一键导出脱敏后的调试包（配置摘要 + 最近错误 + 环境信息）  
  - 已实现：后台“导出诊断包（JSON）”，包含环境信息/配置摘要（Key 脱敏）/最近错误日志（截断）

### 1.5 配置管理
- [x] **导入/导出 JSON**：含校验、版本号、向后兼容  
  - 已实现：后台一键导入/导出插件配置 JSON（含基础校验）；导入后自动刷新生效
- [x] **迁移机制**：options schema version + 升级脚本  
  - 已实现：新增 `schema_version`（options），插件加载时自动执行增量迁移入口 `maybe_migrate()`（仅补缺省，不覆盖旧值）

**验收**：大批量/高频操作下后台不假死；遇到错误可定位；权限不会越权。

---

## Phase 2：易用性（让用户“一次就配对”）

### 2.1 连通性测试（已部分存在“测试”按钮，需增强）
- [x] **测试报告**：DNS/握手/HTTP 状态/耗时/响应片段（脱敏）/建议修复
- [x] **批量测试**：对所有接口一键测试（含可复制的汇总报告）

### 2.2 示例配置向导
- [X] **场景化预设**：资讯/电商/知识库/本地生活等
- [X] **一键生成推荐配置**：超时、默认接口、模板、发布策略等

### 2.3 模板库与变量
- [X] **模板管理 UI**：新增/复制/版本/回滚
- [X] **变量系统**：站点名、分类、标签、作者、语言、关键词等
- [X] **输出风格预设**：语气、长度、结构、是否小标题等

### 2.4 快捷入口
- [X] **顶部按钮区**：测试接口/清缓存/查看用量/打开日志

**验收**：新用户 2 分钟内完成配置并成功生成；模板可复用且可回滚。

---

## Phase 3：成本与安全（可控与合规）

### 3.1 用量统计与预算告警
- [x] **用量统计**：按天/接口/用户统计请求数、耗时、tokens（若可得）
- [x] **预算阈值**：达到阈值限制生成 + 通知（邮件/站内）
- [x] **导出 CSV**：便于财务与运营复盘

> 说明：**真实费用**受厂商计费与汇率影响，可提供“估算成本”（可选）而非承诺对账一致。

### 3.2 隐私与脱敏
- [x] **PII 脱敏**：邮箱/手机号等正则脱敏再发模型（可选开关）
- [x] **禁用外发字段**：例如禁止把作者邮箱、订单号等送出

### 3.3 内容安全
- [x] **敏感词库**：命中策略（拦截/替换/提示）
- [x] **内容安全检测接口化**：本地规则 + 可选接第三方检测（开关 + 降级）

**验收**：可限制爆费；可避免明显违规内容进入发布链路；隐私不外泄。

---

## Phase 4：内容工作流（SEO + 发布体验）

- [x] **SEO 规则**：标题长度、meta 描述、H 标签策略、关键词密度提示
- [x] **内部链接策略**：相关文章推荐与插入规则（数量、锚文本）
- [x] **自动摘要/导语**：写入摘要字段/正文开头
- [x] **自动目录（TOC）**：按 H2/H3 插入
- [x] **自动 FAQ**：条数与位置
- [x] **分类/标签建议**：建议后需人工确认（默认）
- [x] **发布前校验清单**：缺图/缺摘要/外链超限/敏感词命中等

**验收**：生成内容更结构化；发布前能拦截明显问题；运营效率提升。

---

## Phase 5：高级（可选，按需求取舍）

- [x] **主备模型/接口切换**：失败自动切换（含熔断/恢复）
- [x] **模型路由规则**：按任务类型自动选模型
- [x] **缓存策略**：相同输入短期复用（避免重复扣费）
- [x] **Webhook 回调**：生成完成回调外部系统（需安全签名）
- [x] **事实核查模式（有限）**：输出“可验证要点清单/引用来源建议”

> 说明：事实核查与引用来源很大程度取决于模型与数据源；建议作为“辅助提示”，不作为绝对保证。

---

## Phase 6：增强与工作流落地（新增）

### 6.1 文章列表快捷操作（edit.php）
- [x] **一键生成标签并保存**：在 `wp-admin/edit.php` 文章列表的行操作中增加「生成标签」按钮；点击后调用 AI 生成 tags 并写入文章（`wp_set_post_terms`），支持 toast 结果提示、失败原因提示、权限与 nonce 校验、并记录日志（action=generate_tags）。  
- [x] **批量生成标签**：支持勾选多篇文章后批量触发（后台队列/并发限制复用现有机制），展示进度与结果汇总。

### 6.2 Webhook 增强
- [x] **回调重试与队列**：Webhook 失败进入队列重试（指数退避、最大次数、死信）；后台提供查看与重发。
- [x] **回调日志面板**：在后台展示最近回调记录（耗时/HTTP 状态/响应片段脱敏/签名是否启用）。

### 6.3 缓存与成本观测增强
- [x] **缓存命中统计**：统计 cache_hit 次数、节省请求数/预计 tokens，并在“用量统计”页展示。
- [x] **缓存清理工具**：在后台提供“一键清理缓存”按钮（仅清理本插件 transient）。

### 6.4 生成体验增强
- [x] **结果区可编辑再保存**：在“仅展示结果”模式下支持对标题/摘要/正文直接编辑后再保存，同时保留原始生成版本用于回滚。
- [x] **模板/变量真正接入生成**：将“模板库/变量系统/风格预设”从 TODO 文档落地为可选择的提示词构建器（可版本化、可回滚、可导入导出）。

---

## 开发顺序（建议）

1. Phase 1（底座）先完成 70%：队列/日志/权限/导入导出  
2. Phase 2（体验）把“测试 + 向导 + 模板”做出来  
3. Phase 3（成本与安全）上线“统计 + 预算 + 脱敏”  
4. Phase 4（内容工作流）按站点实际需求挑选  
5. Phase 5（高级）按真实使用反馈逐个加

---

## 完成记录

- 2026-03-18：完成「1.3 能力开关」。新增 `cap_generate`/`cap_logs` 配置项，并将菜单与相关 AJAX 权限校验改为分别使用对应 capability。（文件：`includes/class-zhiwrite-ai-writer-settings.php`、`includes/class-zhiwrite-ai-writer.php`、`includes/class-zhiwrite-ai-writer-admin.php`）
- 2026-03-18：完成「1.3 敏感配置保护」。设置页 API Key 默认不回显；保存时空 Key 自动保留旧值（可勾选“清空 Key”）；单个接口测试支持使用已保存 Key（前端不传 Key）。（文件：`includes/class-zhiwrite-ai-writer-settings.php`、`includes/class-zhiwrite-ai-writer-admin.php`、`assets/admin.js`）
- 2026-03-18：完成「1.3 Nonce/CSRF」。复核确认全部 AJAX 入口均已做 nonce 校验（`check_ajax_referer`）。（文件：`includes/class-zhiwrite-ai-writer-admin.php`）
- 2026-03-18：完成「1.4 诊断导出」。新增“导出诊断包（脱敏）”按钮与 AJAX，导出 JSON 含环境信息/配置摘要（不含 Key）/最近 generate_error 日志（meta 截断）。（文件：`includes/class-zhiwrite-ai-writer.php`、`includes/class-zhiwrite-ai-writer-settings.php`、`includes/class-zhiwrite-ai-writer-admin.php`、`assets/admin.js`）
- 2026-03-18：完成「1.5 迁移机制」。新增 options schema version，并在插件加载时运行 `maybe_migrate()` 进行增量迁移。（文件：`includes/class-zhiwrite-ai-writer-settings.php`、`includes/class-zhiwrite-ai-writer.php`）
- 2026-03-18：完成「1.2 队列执行器 + 任务状态机」。新增任务表 `zhiwrite_ai_tasks` 与 WP-Cron 队列处理器；新增设置开关 `enable_queue`（默认关闭），开启后生成改为入队执行并通过轮询显示进度，完成后可拉取结果。（文件：`includes/class-zhiwrite-ai-writer-db.php`、`includes/class-zhiwrite-ai-writer-settings.php`、`includes/class-zhiwrite-ai-writer.php`、`includes/class-zhiwrite-ai-writer-admin.php`、`assets/admin.js`）
- 2026-03-19：完成「2.1 测试报告增强」。接口测试报告支持 DNS/TCP 探测、HTTP 状态/耗时、响应片段（脱敏截断）与修复建议；批量测试支持可复制汇总报告。（文件：`includes/class-zhiwrite-ai-writer-admin.php`、`includes/class-zhiwrite-ai-writer-api.php`、`assets/admin.js`）
- 2026-03-19：完成「3.1 用量统计（部分）」：日志表新增 `elapsed_ms/prompt_tokens/completion_tokens/total_tokens` 字段并自动采集；新增后台「用量统计」页面支持按天/接口汇总；支持导出用量明细 CSV。（文件：`includes/class-zhiwrite-ai-writer-db.php`、`includes/class-zhiwrite-ai-writer-api.php`、`includes/class-zhiwrite-ai-writer.php`、`includes/class-zhiwrite-ai-writer-admin.php`、`assets/admin.js`）
- 2026-03-19：完成「3.1 预算阈值」。新增预算配置（启用开关、每日请求/每日 tokens 上限、邮件通知）；生成入口与队列消费均会在超额时拦截生成并提示，且每天仅通知一次。（文件：`includes/class-zhiwrite-ai-writer-settings.php`、`includes/class-zhiwrite-ai-writer-admin.php`）
 - 2026-03-19：完成「3.2 PII 脱敏（基础版）」。新增“隐私与脱敏”设置区及“PII 脱敏后再发模型”开关；开启后，会在同步生成与队列生成流程中，对写作标题与需求文案中的邮箱、手机号及 8–20 位数字串做基础正则脱敏，然后再发送给模型与写入日志，减少敏感信息外发风险。（文件：`includes/class-zhiwrite-ai-writer-settings.php`、`includes/class-zhiwrite-ai-writer-admin.php`）
 - 2026-03-19：完成「3.2 禁用外发字段」。新增“禁用外发字段”开关与关键字列表（每行一个）；开启后会对用户输入与系统信息按“行”匹配关键字，命中行将把冒号/等号后的值替换为 `***removed***`，再发送给模型并写入日志，以降低作者邮箱、订单号等字段外发风险。（文件：`includes/class-zhiwrite-ai-writer-settings.php`、`includes/class-zhiwrite-ai-writer-admin.php`）
 - 2026-03-19：修复「功能配置页未展示隐私/预算设置」。为设置页新增 Tab「隐私与脱敏」「用量与预算」，并在对应 Tab 中渲染 `zhiwrite_ai_writer_privacy`/`zhiwrite_ai_writer_budget` 字段。（文件：`includes/class-zhiwrite-ai-writer-admin.php`）
 - 2026-03-19：增强「邮件通知」：在“用量与预算 -> 邮件通知”旁新增“发送测试邮件”按钮，通过 AJAX 调用后台 `wp_mail` 发送测试邮件到站点管理员邮箱，并用 toast 提示成功/失败。（文件：`includes/class-zhiwrite-ai-writer-settings.php`、`includes/class-zhiwrite-ai-writer.php`、`includes/class-zhiwrite-ai-writer-admin.php`、`assets/admin.js`）
 - 2026-03-19：新增「SMTP 邮件配置」。新增独立 Tab“SMTP 邮件配置”，支持 `系统邮件（wp_mail/站点邮件插件）` 与 `插件 SMTP（仅影响智写AI发送的邮件）` 两种模式；实现敏感密码不回显、可清空；预算通知与测试邮件统一走插件 `send_mail()`，按配置决定是否临时注入 `phpmailer_init` SMTP 参数。（文件：`includes/class-zhiwrite-ai-writer-settings.php`、`includes/class-zhiwrite-ai-writer-admin.php`）
 - 2026-03-19：增强「SMTP 超时设置」。新增“测试邮件超时/正式邮件超时”两个配置项；发送测试邮件与预算通知等正式邮件分别使用不同超时，并在 SMTP 模式下写入 PHPMailer `Timeout/Timelimit`，避免发信长时间卡住。（文件：`includes/class-zhiwrite-ai-writer-settings.php`、`includes/class-zhiwrite-ai-writer-admin.php`）
 - 2026-03-19：优化「队列管理状态展示」。队列管理列表的任务状态改为中文标签（未执行/正在执行/已完成/失败/已取消），并增加 badge 样式；同时 AJAX 实时刷新也返回 `status_label` 并用相同标签样式渲染。（文件：`includes/class-zhiwrite-ai-writer-admin.php`、`assets/admin.js`、`assets/admin.css`）
 - 2026-03-19：完成「3.3 敏感词库（本地）」：新增“内容安全”Tab，支持敏感词库（每行一个）与命中策略（提示/替换/拦截）；在同步生成、队列生成、以及“仅展示结果后的保存/发布”前统一执行检测，按策略替换或阻止保存。（文件：`includes/class-zhiwrite-ai-writer-settings.php`、`includes/class-zhiwrite-ai-writer-admin.php`）
 - 2026-03-19：完成「3.3 内容安全检测接口化」。在“内容安全”Tab 新增外部检测配置（开关/URL/超时/失败降级）；启用后在本地检测后调用外部接口，外部异常时按 fail-open/严格拦截策略降级；同时保留 `zhiwrite_ai_content_safety_apply` 钩子便于第三方扩展。（文件：`includes/class-zhiwrite-ai-writer-settings.php`、`includes/class-zhiwrite-ai-writer-admin.php`）
 - 2026-03-19：完成「4 SEO 规则」。新增“SEO 规则”Tab（可配置标题/摘要长度阈值、H2 最少数量、焦点关键词密度区间）；生成后在结果区展示 SEO 提示，并在保存文章时写入 `_zhiwrite_seo_hints` meta 便于后续复查。（文件：`includes/class-zhiwrite-ai-writer-settings.php`、`includes/class-zhiwrite-ai-writer-admin.php`、`assets/admin.js`、`assets/admin.css`）
 - 2026-03-19：完成「4 内部链接策略（最小可用）」。新增“内部链接”Tab（开关/最多插入数量/插入位置/推荐策略）；生成后基于站内公开文章（按焦点关键词/标题搜索，兜底取最近文章）生成“相关文章推荐”块并插入正文（HTML/Markdown 自适配），并写入 `_zhiwrite_internal_links` meta 便于复查。（文件：`includes/class-zhiwrite-ai-writer-settings.php`、`includes/class-zhiwrite-ai-writer-admin.php`、`assets/admin.js`）
 - 2026-03-19：完成「4 自动摘要/导语」。新增“导语/摘要”Tab（自动摘要长度、是否写入正文开头、导语前缀）；当 AI 未返回摘要时从正文自动生成 excerpt；可选把摘要以导语形式插入正文开头（HTML/Markdown 自适配）。同步生成与队列生成统一生效。（文件：`includes/class-zhiwrite-ai-writer-settings.php`、`includes/class-zhiwrite-ai-writer-admin.php`）
 - 2026-03-19：修复「分类/标签未写入文章」。在同步保存/队列保存/预览后保存三种保存路径中，按 AI 返回的 categories/tags 调用 `wp_set_post_terms` 写入文章分类与标签；新增“分类/标签写入”配置（可选自动创建不存在术语，默认关闭）。同时预览保存 AJAX 会把建议的分类/标签一并提交。（文件：`includes/class-zhiwrite-ai-writer-admin.php`、`includes/class-zhiwrite-ai-writer-settings.php`、`assets/admin.js`）
 - 2026-03-19：完成「4 自动目录（TOC）」。新增“目录（TOC）”Tab（开关/包含 H3/最少标题数/插入位置）；同步生成与队列生成会根据正文 H2/H3 自动生成目录并插入正文（HTML/Markdown 自适配），并写入 `_zhiwrite_toc` meta 便于复查。（文件：`includes/class-zhiwrite-ai-writer-settings.php`、`includes/class-zhiwrite-ai-writer-admin.php`、`assets/admin.js`、`assets/admin.css`）
 - 2026-03-19：完成「4 自动 FAQ」。新增“FAQ”Tab（开关/条数/位置）；启用后会在 system prompt 中要求模型输出 `faq` 问答数组，并在同步生成与队列生成中把 FAQ 块按规则插入正文（HTML/Markdown 自适配），同时写入 `_zhiwrite_faq` meta 便于复查。（文件：`includes/class-zhiwrite-ai-writer-settings.php`、`includes/class-zhiwrite-ai-writer-admin.php`、`assets/admin.js`、`assets/admin.css`）
 - 2026-03-19：完成「4 分类/标签建议需人工确认（默认）」。新增配置 `terms_require_confirm`（默认开启）；在“仅展示结果”模式下，分类/标签建议改为可勾选确认，保存/发布时仅写入你勾选的术语；同步/队列自动保存路径在开启确认时不自动写入术语，避免误写。（文件：`includes/class-zhiwrite-ai-writer-settings.php`、`includes/class-zhiwrite-ai-writer-admin.php`、`assets/admin.js`）
 - 2026-03-19：完成「4 发布前校验清单」。新增“发布前校验”Tab（缺摘要/缺图/外链上限/内容安全命中等）；生成后在结果区展示清单；可选开启“发布时强制拦截”，在预览发布时未通过则自动回退为草稿并提示。（文件：`includes/class-zhiwrite-ai-writer-settings.php`、`includes/class-zhiwrite-ai-writer-admin.php`、`assets/admin.js`、`assets/admin.css`）
 - 2026-03-19：完成「5 缓存策略」。新增“缓存策略”Tab（开关/TTL/缓存范围）；同步生成与队列生成在调用模型前先查 transient 缓存，命中则直接复用结果并避免重复扣费。（文件：`includes/class-zhiwrite-ai-writer-settings.php`、`includes/class-zhiwrite-ai-writer-admin.php`）
 - 2026-03-19：完成「5 主备接口切换（含熔断）」。新增“主备接口切换”配置（开关/失败阈值/冷却时间）；生成时若当前接口失败会自动尝试其他已配置接口；对连续失败接口进行熔断并在冷却期内跳过，成功后自动恢复。（文件：`includes/class-zhiwrite-ai-writer-settings.php`、`includes/class-zhiwrite-ai-writer-admin.php`）
 - 2026-03-19：完成「5 模型路由规则」。新增“模型路由规则”配置（开关/长需求阈值与模型/SEO结构化任务模型）；当生成页未手动指定模型时，按选项与输入长度自动选择模型（同步/队列一致）。（文件：`includes/class-zhiwrite-ai-writer-settings.php`、`includes/class-zhiwrite-ai-writer-admin.php`）
 - 2026-03-19：完成「5 Webhook 回调」。新增“Webhook 回调”配置（开关/URL/签名密钥/超时）；在生成成功/预览/失败等关键事件中发送 JSON 回调，并支持 `X-ZhiWrite-Signature`（HMAC-SHA256）签名。（文件：`includes/class-zhiwrite-ai-writer-settings.php`、`includes/class-zhiwrite-ai-writer-admin.php`）
 - 2026-03-19：完成「5 事实核查模式（有限）」。新增“事实核查”开关；启用后要求模型额外输出 `verify_points`（可验证要点）与 `source_hints`（引用来源建议），解析后在结果区展示，并在保存文章时写入 `_zhiwrite_fact_check` meta。（文件：`includes/class-zhiwrite-ai-writer-settings.php`、`includes/class-zhiwrite-ai-writer-admin.php`、`assets/admin.js`）
- 2026-03-19：完成「6.1 一键生成标签并保存」。在 `wp-admin/edit.php` 文章列表行操作新增“生成标签”按钮；点击后通过 AJAX 调用 AI 生成 tags 并写入文章标签（`post_tag`），支持 toast 成功/失败提示（含失败原因）、权限与 nonce 校验，并写入日志（action=generate_tags / generate_tags_error / generate_tags_empty）。（文件：`includes/class-zhiwrite-ai-writer.php`、`includes/class-zhiwrite-ai-writer-admin.php`、`assets/admin.js`）
- 2026-03-19：完成「6.1 批量生成标签」。在文章列表增加“批量生成标签”按钮：读取勾选文章后弹窗选择接口/模型/数量/覆盖或增量，然后将每篇文章作为 `task_type=generate_tags` 的队列任务入库并后台执行；前端弹窗轮询显示进度与成功/失败汇总，并在完成后用服务端返回的 `tagsHtml` 刷新列表标签列显示。（文件：`includes/class-zhiwrite-ai-writer.php`、`includes/class-zhiwrite-ai-writer-admin.php`、`assets/admin.js`、`includes/class-zhiwrite-ai-writer-db.php`）
- 2026-03-19：完成「6.2 回调重试与队列」。Webhook 发送失败（网络错误或 HTTP 非 2xx）会写入 `task_type=webhook_retry` 队列任务，按指数退避 + jitter 重试，达到最大次数转为失败（死信）；新增“Webhook 队列”后台页用于查看最近重试任务并可手动触发立即重试；并在“Webhook 回调”配置中增加重试开关与参数。（文件：`includes/class-zhiwrite-ai-writer-settings.php`、`includes/class-zhiwrite-ai-writer.php`、`includes/class-zhiwrite-ai-writer-admin.php`、`assets/admin.js`）
- 2026-03-19：完成「6.2 回调日志面板」。Webhook 回调（成功/失败）与重试（成功/失败）都会写入日志，记录耗时、HTTP 状态、响应片段（截断）、是否启用签名；新增后台“Webhook 日志”页面实时刷新展示最近记录。（文件：`includes/class-zhiwrite-ai-writer.php`、`includes/class-zhiwrite-ai-writer-admin.php`、`assets/admin.js`）
- 2026-03-19：完成「6.3 缓存命中统计」。在生成日志 meta 写入 `cache_hit` 与 usage tokens（命中时用于估算节省）；“用量统计”页按统计范围汇总缓存命中次数与预计节省 tokens，并用提示条展示。（文件：`includes/class-zhiwrite-ai-writer-admin.php`）
- 2026-03-19：完成「6.3 缓存清理工具」。在缓存写入时记录本插件 transient key 索引；在“功能配置 -> 缓存策略”新增“一键清理缓存”按钮，AJAX 删除索引内 transient 并清空索引。（文件：`includes/class-zhiwrite-ai-writer-settings.php`、`includes/class-zhiwrite-ai-writer.php`、`includes/class-zhiwrite-ai-writer-admin.php`、`assets/admin.js`）
- 2026-03-19：完成「6.4 结果区可编辑再保存」。在“仅展示结果”模式下将标题/摘要/正文渲染为可编辑表单，保存/发布时提交编辑后的内容；同时在保存时写入 `_zhiwrite_original_generation`（原始生成版本）到文章 meta，并在文章编辑页侧边栏提供“回滚到原始版本”按钮（AJAX 回滚并刷新）。（文件：`assets/admin.js`、`includes/class-zhiwrite-ai-writer-admin.php`、`includes/class-zhiwrite-ai-writer.php`、`WORK_TODO.md`）
- 2026-03-19：完成「6.4 模板/变量真正接入生成」。新增“功能配置 -> 提示词构建器”Tab：以 JSON 管理模板/风格/变量，保存自动保留最近 10 个历史版本并支持一键回滚；生成页支持选择模板/风格与本次变量覆盖（JSON），后端将模板/风格渲染为 system prompt 追加段并记录到日志 meta（template_id/style_id），队列/同步生成一致。（文件：`includes/class-zhiwrite-ai-writer-settings.php`、`includes/class-zhiwrite-ai-writer-admin.php`、`includes/class-zhiwrite-ai-writer.php`、`assets/admin.js`、`WORK_TODO.md`）


