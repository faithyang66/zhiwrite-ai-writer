<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class ZhiWrite_AI_Writer_API {
	/**
	 * Decide whether a failure is transient and worth retrying.
	 *
	 * @param mixed $resp wp_remote_post response array or WP_Error.
	 * @param int   $http_code HTTP status code if available.
	 * @return bool
	 */
	private static function should_retry( $resp, $http_code = 0 ) {
		if ( is_wp_error( $resp ) ) {
			// Most transport errors are transient (dns/timeout/connect).
			return true;
		}
		$code = (int) $http_code;
		return in_array( $code, array( 408, 425, 429, 500, 502, 503, 504 ), true );
	}

	/**
	 * Calls an OpenAI-compatible chat completions endpoint.
	 *
	 * @param array $args { api_base_url, api_key, model, messages, timeout, retry_times, retry_backoff_ms }
	 * @return array { ok:bool, text:string, raw:array, error:string, error_code:string, meta:array }
	 */
	public static function chat_completions( array $args ) {
		$api_base_url = isset( $args['api_base_url'] ) ? trim( (string) $args['api_base_url'] ) : '';
		$api_key      = isset( $args['api_key'] ) ? trim( (string) $args['api_key'] ) : '';
		$model        = isset( $args['model'] ) ? trim( (string) $args['model'] ) : '';
		$messages     = isset( $args['messages'] ) && is_array( $args['messages'] ) ? $args['messages'] : array();
		$timeout      = isset( $args['timeout'] ) ? (int) $args['timeout'] : 60;
		$retry_times  = isset( $args['retry_times'] ) ? (int) $args['retry_times'] : 0;
		$backoff_ms   = isset( $args['retry_backoff_ms'] ) ? (int) $args['retry_backoff_ms'] : 0;

		if ( '' === $api_base_url || '' === $api_key || '' === $model ) {
			return array(
				'ok'         => false,
				'text'       => '',
				'raw'        => array(),
				'error'      => __( '请先在“设置”中填写 API 接口地址、API Key 与默认模型名称。', 'zhiwrite-ai-writer' ),
				'error_code' => 'missing_config',
				'meta'       => array(),
			);
		}

		$api_base_url = rtrim( $api_base_url, '/' );
		$endpoint     = $api_base_url . '/chat/completions';

		$payload = array(
			'model'    => $model,
			'messages' => $messages,
		);

		$timeout     = max( 5, min( 300, $timeout ) );
		$retry_times = max( 0, min( 5, $retry_times ) );
		$backoff_ms  = max( 0, min( 10000, $backoff_ms ) );

		$attempts = 0;
		$resp     = null;
		$code     = 0;
		$body     = '';

		$start_ts = microtime( true );
		do {
			$attempts++;
			$resp = wp_remote_post(
				$endpoint,
				array(
					'timeout' => $timeout,
					'headers' => array(
						'Content-Type'  => 'application/json',
						'Authorization' => 'Bearer ' . $api_key,
					),
					'body'    => wp_json_encode( $payload ),
				)
			);

			if ( is_wp_error( $resp ) ) {
				$code = 0;
				$body = '';
			} else {
				$code = (int) wp_remote_retrieve_response_code( $resp );
				$body = (string) wp_remote_retrieve_body( $resp );
			}

			$is_last = ( $attempts >= ( 1 + $retry_times ) );
			if ( $is_last || ! self::should_retry( $resp, $code ) ) {
				break;
			}
			if ( $backoff_ms > 0 ) {
				usleep( $backoff_ms * 1000 );
			}
		} while ( $attempts < ( 1 + $retry_times ) );
		$elapsed_ms = (int) round( ( microtime( true ) - $start_ts ) * 1000 );

		if ( is_wp_error( $resp ) ) {
			return array(
				'ok'         => false,
				'text'       => '',
				'raw'        => array(),
				'error'      => $resp->get_error_message(),
				'error_code' => (string) $resp->get_error_code(),
				'meta'       => array(
					'endpoint'    => $endpoint,
					'timeout'     => $timeout,
					'attempts'    => $attempts,
					'retry_times' => $retry_times,
					'backoff_ms'  => $backoff_ms,
					'elapsed_ms'  => $elapsed_ms,
				),
			);
		}
		$json = json_decode( $body, true );
		if ( ! is_array( $json ) ) {
			return array(
				'ok'         => false,
				'text'       => '',
				'raw'        => array( 'http_code' => $code, 'body' => $body ),
				'error'      => __( '接口返回非 JSON。请检查接口地址是否为 OpenAI 兼容的 /v1。', 'zhiwrite-ai-writer' ),
				'error_code' => 'non_json',
				'meta'       => array(
					'endpoint'   => $endpoint,
					'timeout'    => $timeout,
					'http_code'  => $code,
					'body_snip'  => mb_substr( preg_replace( '/\s+/', ' ', $body ), 0, 220 ),
					'attempts'   => $attempts,
					'elapsed_ms' => $elapsed_ms,
				),
			);
		}

		if ( $code < 200 || $code >= 300 ) {
			$err = isset( $json['error']['message'] ) ? (string) $json['error']['message'] : ( isset( $json['message'] ) ? (string) $json['message'] : __( '请求失败。', 'zhiwrite-ai-writer' ) );
			return array(
				'ok'         => false,
				'text'       => '',
				'raw'        => $json,
				'error'      => $err,
				'error_code' => 'http_' . $code,
				'meta'       => array(
					'endpoint'  => $endpoint,
					'timeout'   => $timeout,
					'http_code' => $code,
					'attempts'  => $attempts,
					'elapsed_ms' => $elapsed_ms,
				),
			);
		}

		$text = '';
		if ( isset( $json['choices'][0]['message']['content'] ) ) {
			$text = (string) $json['choices'][0]['message']['content'];
		} elseif ( isset( $json['choices'][0]['text'] ) ) {
			$text = (string) $json['choices'][0]['text'];
		}

		$usage = isset( $json['usage'] ) && is_array( $json['usage'] ) ? $json['usage'] : array();
		$prompt_tokens     = isset( $usage['prompt_tokens'] ) ? (int) $usage['prompt_tokens'] : 0;
		$completion_tokens = isset( $usage['completion_tokens'] ) ? (int) $usage['completion_tokens'] : 0;
		$total_tokens      = isset( $usage['total_tokens'] ) ? (int) $usage['total_tokens'] : 0;

		return array(
			'ok'         => true,
			'text'       => $text,
			'raw'        => $json,
			'error'      => '',
			'error_code' => '',
			'meta'       => array(
				'endpoint'  => $endpoint,
				'timeout'   => $timeout,
				'http_code' => $code,
				'attempts'  => $attempts,
				'elapsed_ms' => $elapsed_ms,
				'prompt_tokens' => $prompt_tokens,
				'completion_tokens' => $completion_tokens,
				'total_tokens' => $total_tokens,
			),
		);
	}

	// Streaming removed. Only direct output (`chat_completions`) is supported.
}


