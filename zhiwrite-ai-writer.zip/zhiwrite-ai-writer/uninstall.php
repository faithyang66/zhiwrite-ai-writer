<?php

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

// Keep data by default unless user opted out.
$opts = get_option( 'zhiwrite_ai_writer_options', array() );
$keep = isset( $opts['keep_data_on_uninstall'] ) ? (int) $opts['keep_data_on_uninstall'] : 1;
if ( 1 === $keep ) {
	return;
}

global $wpdb;
$table = $wpdb->prefix . 'zhiwrite_ai_logs';

// Drop logs table.
// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.SchemaChange
$wpdb->query( "DROP TABLE IF EXISTS {$table}" );

delete_option( 'zhiwrite_ai_writer_options' );


