<?php
/**
 * Plugin Name:       智写-AI写作助手
 * Plugin URI:        https://blog.sg65.cn/
 * Description:       在 WordPress 后台使用 AI 生成/改写文章，支持多模型切换、批量生成、定时发布、模板库、SEO字段生成、分类/标签与生成记录管理。
 * Version:           0.1.0
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Author:            晨晖时光网络科技有限公司
 * Author URI:        https://blog.sg65.cn/
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       zhiwrite-ai-writer
 * Domain Path:       /languages
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'ZHIWRITE_AI_WRITER_VERSION', '0.1.0' );
define( 'ZHIWRITE_AI_WRITER_SLUG', 'zhiwrite-ai-writer' );
define( 'ZHIWRITE_AI_WRITER_PATH', plugin_dir_path( __FILE__ ) );
define( 'ZHIWRITE_AI_WRITER_URL', plugin_dir_url( __FILE__ ) );

require_once ZHIWRITE_AI_WRITER_PATH . 'includes/class-zhiwrite-ai-writer.php';

register_activation_hook( __FILE__, array( 'ZhiWrite_AI_Writer', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'ZhiWrite_AI_Writer', 'deactivate' ) );

add_action(
	'plugins_loaded',
	static function () {
		ZhiWrite_AI_Writer::instance();
	}
);


