<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/class-zhiwrite-ai-writer-db.php';
require_once __DIR__ . '/class-zhiwrite-ai-writer-settings.php';
require_once __DIR__ . '/class-zhiwrite-ai-writer-admin.php';
require_once __DIR__ . '/class-zhiwrite-ai-writer-api.php';

final class ZhiWrite_AI_Writer {
	/** @var ZhiWrite_AI_Writer|null */
	private static $instance = null;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		load_plugin_textdomain( 'zhiwrite-ai-writer', false, dirname( plugin_basename( ZHIWRITE_AI_WRITER_PATH . 'zhiwrite-ai-writer.php' ) ) . '/languages' );
		// Instance is created on plugins_loaded, so run these immediately here.
		ZhiWrite_AI_Writer_Settings::maybe_migrate();
		ZhiWrite_AI_Writer_DB::maybe_create_tables();
		$this->hooks();
	}

	private function hooks() {
		add_action( 'admin_menu', array( $this, 'admin_menu' ) );
		add_action( 'admin_init', array( 'ZhiWrite_AI_Writer_Settings', 'register' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'admin_assets' ) );
		add_action( 'add_meta_boxes', array( $this, 'add_meta_boxes' ) );
		add_filter( 'post_row_actions', array( 'ZhiWrite_AI_Writer_Admin', 'post_row_actions' ), 10, 2 );

		add_action( 'wp_ajax_zhiwrite_ai_generate', array( 'ZhiWrite_AI_Writer_Admin', 'ajax_generate' ) );
		add_action( 'wp_ajax_zhiwrite_ai_generation_status', array( 'ZhiWrite_AI_Writer_Admin', 'ajax_generation_status' ) );
		add_action( 'wp_ajax_zhiwrite_ai_save_post', array( 'ZhiWrite_AI_Writer_Admin', 'ajax_save_post' ) );
		add_action( 'wp_ajax_zhiwrite_ai_apply_terms', array( 'ZhiWrite_AI_Writer_Admin', 'ajax_apply_terms' ) );
		add_action( 'wp_ajax_zhiwrite_ai_test_api', array( 'ZhiWrite_AI_Writer_Admin', 'ajax_test_api' ) );
		add_action( 'wp_ajax_zhiwrite_ai_test_api_all', array( 'ZhiWrite_AI_Writer_Admin', 'ajax_test_api_all' ) );
		add_action( 'wp_ajax_zhiwrite_ai_export_settings', array( 'ZhiWrite_AI_Writer_Admin', 'ajax_export_settings' ) );
		add_action( 'wp_ajax_zhiwrite_ai_import_settings', array( 'ZhiWrite_AI_Writer_Admin', 'ajax_import_settings' ) );
		add_action( 'wp_ajax_zhiwrite_ai_export_diagnostics', array( 'ZhiWrite_AI_Writer_Admin', 'ajax_export_diagnostics' ) );
		add_action( 'wp_ajax_zhiwrite_ai_get_task_result', array( 'ZhiWrite_AI_Writer_Admin', 'ajax_get_task_result' ) );
		add_action( 'wp_ajax_zhiwrite_ai_delete_log', array( 'ZhiWrite_AI_Writer_Admin', 'ajax_delete_log' ) );
		add_action( 'wp_ajax_zhiwrite_ai_export_logs', array( 'ZhiWrite_AI_Writer_Admin', 'ajax_export_logs' ) );
		add_action( 'wp_ajax_zhiwrite_ai_cancel_task', array( 'ZhiWrite_AI_Writer_Admin', 'ajax_cancel_task' ) );
		add_action( 'wp_ajax_zhiwrite_ai_queue_status', array( 'ZhiWrite_AI_Writer_Admin', 'ajax_queue_status' ) );
		add_action( 'wp_ajax_zhiwrite_ai_delete_task', array( 'ZhiWrite_AI_Writer_Admin', 'ajax_delete_task' ) );
		add_action( 'wp_ajax_zhiwrite_ai_export_usage', array( 'ZhiWrite_AI_Writer_Admin', 'ajax_export_usage' ) );
		add_action( 'wp_ajax_zhiwrite_ai_test_email', array( 'ZhiWrite_AI_Writer_Admin', 'ajax_test_email' ) );
		add_action( 'wp_ajax_zhiwrite_ai_generate_tags', array( 'ZhiWrite_AI_Writer_Admin', 'ajax_generate_tags' ) );
		add_action( 'wp_ajax_zhiwrite_ai_enqueue_tags_batch', array( 'ZhiWrite_AI_Writer_Admin', 'ajax_enqueue_tags_batch' ) );
		add_action( 'wp_ajax_zhiwrite_ai_tags_batch_status', array( 'ZhiWrite_AI_Writer_Admin', 'ajax_tags_batch_status' ) );
		add_action( 'wp_ajax_zhiwrite_ai_webhook_queue_status', array( 'ZhiWrite_AI_Writer_Admin', 'ajax_webhook_queue_status' ) );
		add_action( 'wp_ajax_zhiwrite_ai_webhook_retry_now', array( 'ZhiWrite_AI_Writer_Admin', 'ajax_webhook_retry_now' ) );
		add_action( 'wp_ajax_zhiwrite_ai_webhook_logs', array( 'ZhiWrite_AI_Writer_Admin', 'ajax_webhook_logs' ) );
		add_action( 'wp_ajax_zhiwrite_ai_clear_cache', array( 'ZhiWrite_AI_Writer_Admin', 'ajax_clear_cache' ) );
		add_action( 'wp_ajax_zhiwrite_ai_rollback_post', array( 'ZhiWrite_AI_Writer_Admin', 'ajax_rollback_post' ) );
		add_action( 'wp_ajax_zhiwrite_ai_prompt_builder_rollback', array( 'ZhiWrite_AI_Writer_Admin', 'ajax_prompt_builder_rollback' ) );

		// Queue processor (WP-Cron).
		add_action( 'zhiwrite_ai_process_queue', array( 'ZhiWrite_AI_Writer_Admin', 'process_queue' ) );

		// Settings audit log.
		add_action( 'update_option_' . ZhiWrite_AI_Writer_Settings::OPTION_KEY, array( $this, 'on_options_updated' ), 10, 2 );
	}

	public function admin_menu() {
		$cap_generate = ZhiWrite_AI_Writer_Settings::capability_generate();
		$cap_logs     = ZhiWrite_AI_Writer_Settings::capability_logs();

		add_menu_page(
			__( '智写AI', 'zhiwrite-ai-writer' ),
			__( '智写AI', 'zhiwrite-ai-writer' ),
			$cap_generate,
			'zhiwrite-ai',
			array( 'ZhiWrite_AI_Writer_Admin', 'render_generate_page' ),
			'dashicons-edit-page',
			58
		);

		add_submenu_page(
			'zhiwrite-ai',
			__( '生成内容', 'zhiwrite-ai-writer' ),
			__( '生成内容', 'zhiwrite-ai-writer' ),
			$cap_generate,
			'zhiwrite-ai',
			array( 'ZhiWrite_AI_Writer_Admin', 'render_generate_page' )
		);

		add_submenu_page(
			'zhiwrite-ai',
			__( '功能配置', 'zhiwrite-ai-writer' ),
			__( '功能配置', 'zhiwrite-ai-writer' ),
			'manage_options',
			'zhiwrite-ai-settings',
			array( 'ZhiWrite_AI_Writer_Admin', 'render_settings_page' )
		);

		add_submenu_page(
			'zhiwrite-ai',
			__( '生成记录', 'zhiwrite-ai-writer' ),
			__( '生成记录', 'zhiwrite-ai-writer' ),
			$cap_logs,
			'zhiwrite-ai-logs',
			array( 'ZhiWrite_AI_Writer_Admin', 'render_logs_page' )
		);

		add_submenu_page(
			'zhiwrite-ai',
			__( '队列管理', 'zhiwrite-ai-writer' ),
			__( '队列管理', 'zhiwrite-ai-writer' ),
			$cap_logs,
			'zhiwrite-ai-queue',
			array( 'ZhiWrite_AI_Writer_Admin', 'render_queue_page' )
		);

		add_submenu_page(
			'zhiwrite-ai',
			__( 'Webhook 队列', 'zhiwrite-ai-writer' ),
			__( 'Webhook 队列', 'zhiwrite-ai-writer' ),
			$cap_logs,
			'zhiwrite-ai-webhook-queue',
			array( 'ZhiWrite_AI_Writer_Admin', 'render_webhook_queue_page' )
		);

		add_submenu_page(
			'zhiwrite-ai',
			__( 'Webhook 日志', 'zhiwrite-ai-writer' ),
			__( 'Webhook 日志', 'zhiwrite-ai-writer' ),
			$cap_logs,
			'zhiwrite-ai-webhook-logs',
			array( 'ZhiWrite_AI_Writer_Admin', 'render_webhook_logs_page' )
		);

		add_submenu_page(
			'zhiwrite-ai',
			__( '用量统计', 'zhiwrite-ai-writer' ),
			__( '用量统计', 'zhiwrite-ai-writer' ),
			$cap_logs,
			'zhiwrite-ai-usage',
			array( 'ZhiWrite_AI_Writer_Admin', 'render_usage_page' )
		);
	}

	public function admin_assets( $hook_suffix ) {
		$hook_suffix = (string) $hook_suffix;
		$is_plugin_pages = false !== strpos( $hook_suffix, 'zhiwrite-ai' );
		$is_post_list = 'edit.php' === $hook_suffix;
		$is_post_edit = in_array( $hook_suffix, array( 'post.php', 'post-new.php' ), true );
		if ( ! $is_plugin_pages && ! $is_post_list && ! $is_post_edit ) {
			return;
		}

		wp_enqueue_style(
			'zhiwrite-ai-writer-admin',
			ZHIWRITE_AI_WRITER_URL . 'assets/admin.css',
			array(),
			ZHIWRITE_AI_WRITER_VERSION
		);

		wp_enqueue_script(
			'zhiwrite-ai-writer-admin',
			ZHIWRITE_AI_WRITER_URL . 'assets/admin.js',
			array( 'jquery' ),
			ZHIWRITE_AI_WRITER_VERSION,
			true
		);

		wp_localize_script(
			'zhiwrite-ai-writer-admin',
			'ZhiWriteAI',
			array(
				'ajaxUrl' => admin_url( 'admin-ajax.php' ),
				'nonce'   => wp_create_nonce( 'zhiwrite_ai_nonce' ),
				'opts'    => array(
					'defaultPostStatus' => (string) ZhiWrite_AI_Writer_Settings::get_options()['default_post_status'],
					'canPublish'        => current_user_can( 'publish_posts' ) ? 1 : 0,
					'defaultInterfaceId' => (string) ZhiWrite_AI_Writer_Settings::get_options()['default_interface_id'],
					'tagGen'            => array(
						'defaultInterfaceId' => (string) ZhiWrite_AI_Writer_Settings::get_options()['tag_gen_interface_id'],
						'defaultModel'       => (string) ZhiWrite_AI_Writer_Settings::get_options()['tag_gen_model'],
						'defaultCount'       => (int) ZhiWrite_AI_Writer_Settings::get_options()['tag_gen_count'],
						'defaultApplyMode'   => (string) ZhiWrite_AI_Writer_Settings::get_options()['tag_gen_apply_mode'],
					),
					'interfaces'         => array_values(
						array_map(
							static function ( $iface ) {
								$iface = is_array( $iface ) ? $iface : array();
								return array(
									'id'    => isset( $iface['id'] ) ? (string) $iface['id'] : '',
									'name'  => isset( $iface['name'] ) ? (string) $iface['name'] : '',
									'model' => isset( $iface['model'] ) ? (string) $iface['model'] : '',
								);
							},
							is_array( ZhiWrite_AI_Writer_Settings::get_options()['interfaces'] ) ? ZhiWrite_AI_Writer_Settings::get_options()['interfaces'] : array()
						)
					),
				),
				'i18n'    => array(
					'confirmDeleteInterface' => __( '确定删除该接口吗？此操作不会立即保存，需点击“保存更改”后生效。', 'zhiwrite-ai-writer' ),
					'test'                  => __( '测试', 'zhiwrite-ai-writer' ),
					'testAll'               => __( '一键测试全部接口', 'zhiwrite-ai-writer' ),
					'testing'               => __( '测试中...', 'zhiwrite-ai-writer' ),
					'testingOne'            => __( '正在测试接口连接...', 'zhiwrite-ai-writer' ),
					'testingAll'            => __( '正在批量测试所有接口...', 'zhiwrite-ai-writer' ),
					'remaining'             => __( '剩余', 'zhiwrite-ai-writer' ),
					'testingRemaining'      => __( '测试中...（剩余 %ss）', 'zhiwrite-ai-writer' ),
					'batchDone'             => __( '批量测试完成：成功 %1 / %2', 'zhiwrite-ai-writer' ),
					'hideDebug'             => __( '隐藏调试信息', 'zhiwrite-ai-writer' ),
					'showDebug'             => __( '显示调试信息', 'zhiwrite-ai-writer' ),
					'clearResult'           => __( '清空结果', 'zhiwrite-ai-writer' ),
					'copyReport'            => __( '复制报告', 'zhiwrite-ai-writer' ),
					'reportText'            => __( '报告文本（可复制）', 'zhiwrite-ai-writer' ),
					'copiedReport'          => __( '已复制报告到剪贴板。', 'zhiwrite-ai-writer' ),
					'copyFailed'            => __( '复制失败，请手动选择文本复制。', 'zhiwrite-ai-writer' ),
					'testBusy'              => __( '已有测试任务进行中，请稍候…', 'zhiwrite-ai-writer' ),
					'batchFailed'           => __( '批量测试失败。', 'zhiwrite-ai-writer' ),
					'batchReportTitle'      => __( 'ZhiWriteAI 批量测试报告', 'zhiwrite-ai-writer' ),
					'generateTags'          => __( '生成标签', 'zhiwrite-ai-writer' ),
					'generatingTags'        => __( '生成中…', 'zhiwrite-ai-writer' ),
					'generateTagsTitle'     => __( '生成标签并保存', 'zhiwrite-ai-writer' ),
					'chooseInterface'       => __( '选择接口', 'zhiwrite-ai-writer' ),
					'chooseModelOptional'   => __( '模型（可选）', 'zhiwrite-ai-writer' ),
					'tagCount'              => __( '标签数量', 'zhiwrite-ai-writer' ),
					'tagApplyMode'          => __( '写入方式', 'zhiwrite-ai-writer' ),
					'tagApplyReplace'       => __( '覆盖原有标签', 'zhiwrite-ai-writer' ),
					'tagApplyAppend'        => __( '增量添加（保留原有）', 'zhiwrite-ai-writer' ),
					'confirm'               => __( '确定', 'zhiwrite-ai-writer' ),
					'cancel'                => __( '取消', 'zhiwrite-ai-writer' ),
				),
			)
		);
	}

	public static function activate() {
		ZhiWrite_AI_Writer_DB::maybe_create_tables();
		ZhiWrite_AI_Writer_Settings::maybe_init_defaults();
	}

	public static function deactivate() {
		// Intentionally no-op. Data is kept until user deletes.
	}

	public function add_meta_boxes() {
		add_meta_box(
			'zhiwrite-ai-original-generation',
			__( '智写AI：原始生成版本', 'zhiwrite-ai-writer' ),
			array( 'ZhiWrite_AI_Writer_Admin', 'render_original_generation_metabox' ),
			'post',
			'side',
			'low'
		);
	}

	/**
	 * Insert an audit log when plugin settings are updated.
	 *
	 * @param mixed $old_value
	 * @param mixed $value
	 */
	public function on_options_updated( $old_value, $value ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$old = is_array( $old_value ) ? $old_value : array();
		$new = is_array( $value ) ? $value : array();

		$changes = ZhiWrite_AI_Writer_Admin::diff_options_for_audit( $old, $new );
		if ( empty( $changes ) ) {
			return;
		}

		ZhiWrite_AI_Writer_DB::insert_log(
			array(
				'action' => 'settings_update',
				'meta'   => wp_json_encode(
					array(
						'changes' => $changes,
						'ip'      => isset( $_SERVER['REMOTE_ADDR'] ) ? (string) $_SERVER['REMOTE_ADDR'] : '',
					)
				),
			)
		);
	}
}


