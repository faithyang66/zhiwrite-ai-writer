(function ($) {
  function t(key, fallback) {
    try {
      if (window.ZhiWriteAI && window.ZhiWriteAI.i18n && window.ZhiWriteAI.i18n[key]) {
        return String(window.ZhiWriteAI.i18n[key]);
      }
    } catch (e) {}
    return String(fallback || "");
  }

  var zhiwriteIfTestBusy = false;
  function setIfTestBusy(isBusy) {
    zhiwriteIfTestBusy = !!isBusy;
    try {
      // Disable all test triggers to avoid concurrent timers/overwrites.
      $("#zhiwrite-if-test-all").prop("disabled", zhiwriteIfTestBusy);
      $(".zhiwrite-if-test").prop("disabled", zhiwriteIfTestBusy);
    } catch (e) {}
  }

  // Settings page: left nav toggles sections (show/hide cards)
  function initSettingsNav() {
    var $nav = $("#zhiwrite_settings_nav");
    if (!$nav.length) return;

    var $items = $nav.find(".zhiwrite-settings-nav__item");
    var sections = [];

    $items.each(function () {
      var $a = $(this);
      var id = $a.data("zhiwriteTarget");
      if (!id) return;
      var el = document.getElementById(String(id));
      if (!el) return;
      sections.push({ id: String(id), el: el, $a: $a });
    });

    function setActive(id) {
      $items.removeClass("is-active");
      var found = false;
      sections.forEach(function (s) {
        if (s.id === id) {
          s.$a.addClass("is-active");
          found = true;
        }
      });
      if (!found && sections[0]) sections[0].$a.addClass("is-active");
    }

    function showOnly(id) {
      var showId = String(id || "");
      sections.forEach(function (s) {
        if (!showId || s.id === showId) $(s.el).removeClass("is-hidden");
        else $(s.el).addClass("is-hidden");
      });
    }

    // Click -> toggle cards (no scrolling)
    $(document).on(
      "click",
      "#zhiwrite_settings_nav .zhiwrite-settings-nav__item",
      function (e) {
        var id = $(this).data("zhiwriteTarget");
        if (!id) return;
        var el = document.getElementById(String(id));
        if (!el) return;
        e.preventDefault();

        setActive(String(id));
        showOnly(String(id));

        window.history && window.history.replaceState
          ? window.history.replaceState(null, "", "#" + String(id))
          : (window.location.hash = "#" + String(id));
      }
    );

    // Initial active from hash or first
    var hash = (window.location.hash || "").replace("#", "");
    var initial = null;
    if (hash) {
      sections.forEach(function (s) {
        if (s.id === hash) initial = s.id;
      });
    }
    if (!initial && sections[0]) initial = sections[0].id;

    if (initial) {
      setActive(initial);
      showOnly(initial);
    }
  }

  // Settings page (tabs mode): no JS required, but clean stale hashes from old anchor navigation.
  function initSettingsTabs() {
    var $tabs = $(".nav-tab-wrapper");
    if (!$tabs.length) return;
    if (window.location.hash && window.location.hash.indexOf("zhiwrite_settings_") === 1) {
      try {
        window.history && window.history.replaceState
          ? window.history.replaceState(null, "", window.location.href.split("#")[0])
          : (window.location.hash = "");
      } catch (e) {}
    }
  }

  function getToastContainer() {
    var $c = $("#zhiwrite_ai_toast_container");
    if ($c.length) return $c;
    $c = $(
      '<div id="zhiwrite_ai_toast_container" class="zhiwrite-ai-toast-container"></div>'
    );
    $("body").append($c);
    return $c;
  }

  function hideToast($toast) {
    if (!$toast || !$toast.length) return;
    $toast.addClass("zhiwrite-ai-toast--out");
    window.setTimeout(function () {
      $toast.remove();
    }, 200);
  }

  function showToast(type, message, durationMs) {
    var $c = getToastContainer();
    var cls = "zhiwrite-ai-toast zhiwrite-ai-toast--" + (type || "info");
    var safeMsg = escHtml(message);
    var iconSvg = getToastIconSvg(type);

    var $toast = $(
      '<div class="' +
        cls +
        '" role="status" aria-live="polite">' +
        '<div class="zhiwrite-ai-toast__row">' +
        '<span class="zhiwrite-ai-toast__icon" aria-hidden="true">' +
        iconSvg +
        "</span>" +
        '<p class="zhiwrite-ai-toast__msg">' +
        safeMsg +
        "</p>" +
        '<button type="button" class="zhiwrite-ai-toast__close" aria-label="关闭">' +
        getCloseIconSvg() +
        "</button>" +
        "</div>" +
        "</div>"
    );

    $toast.on("click", ".zhiwrite-ai-toast__close", function () {
      hideToast($toast);
    });

    $c.append($toast);

    var ms = typeof durationMs === "number" ? durationMs : 3000;
    if (ms > 0) {
      window.setTimeout(function () {
        hideToast($toast);
      }, ms);
    }
  }

  // Expose toast for PHP-rendered pages (e.g. settings saved message)
  window.zhiwriteShowToast = showToast;

  // Logs page: missing post handler.
  $(document).on("click", ".zhiwrite-ai-post-missing", function (e) {
    e.preventDefault();
    var reason = String($(this).data("reason") || "");
    if (reason === "trash") {
      showToast("warning", "文章在回收站中。", 4500);
      return;
    }
    showToast("warning", "文章不存在。", 4500);
  });

  // Init after DOM ready
  $(function () {
    initSettingsNav();
    initSettingsTabs();
    initPostListBulkTags();
  });

  // Generate page empty-state: quick fill examples.
  $(document).on("click", ".zhiwrite-empty-chip", function (e) {
    e.preventDefault();
    var txt = String($(this).data("zhiwriteFill") || $(this).data("zhiwrite-fill") || "");
    if (!txt) return;
    if ($("#zhiwrite_prompt").length) {
      $("#zhiwrite_prompt").val(txt).trigger("input").trigger("change").trigger("focus");
      showToast("success", "已填入示例需求，可直接开始生成。", 2200);
      return;
    }
  });

  // Post list: inject bulk generate button + helpers.
  function initPostListBulkTags() {
    var $wrap = $("#posts-filter");
    if (!$wrap.length) return;
    if ($("#zhiwrite_bulk_generate_tags").length) return;

    var $bulk = $wrap.find(".tablenav.top .bulkactions").first();
    if (!$bulk.length) return;

    var $btn = $(
      '<button type="button" class="button" id="zhiwrite_bulk_generate_tags" style="margin-left:6px;">批量生成标签</button>'
    );
    $bulk.append($btn);
  }

  function getSelectedPostIds() {
    var ids = [];
    try {
      $('input[name="post[]"]:checked').each(function () {
        var v = parseInt($(this).val() || "0", 10) || 0;
        if (v) ids.push(v);
      });
    } catch (e) {}
    var seen = {};
    var out = [];
    ids.forEach(function (id) {
      if (seen[id]) return;
      seen[id] = 1;
      out.push(id);
    });
    return out;
  }

  function ensureBatchProgressModal() {
    var $m = $("#zhiwrite_ai_tags_batch_modal");
    if ($m.length) return $m;
    $m = $(
      '<div id="zhiwrite_ai_tags_batch_modal" class="zhiwrite-ai-modal" style="display:none;" aria-hidden="true">' +
        '<div class="zhiwrite-ai-modal__backdrop" data-zhiwrite-batch-close="1"></div>' +
        '<div class="zhiwrite-ai-modal__dialog" role="dialog" aria-modal="true" aria-labelledby="zhiwrite_ai_batch_title">' +
        '<div class="zhiwrite-ai-modal__header">' +
        '<div id="zhiwrite_ai_batch_title" class="zhiwrite-ai-modal__title">批量生成标签</div>' +
        '<button type="button" class="zhiwrite-ai-modal__x" aria-label="关闭" data-zhiwrite-batch-close="1">' +
        getCloseIconSvg() +
        "</button>" +
        "</div>" +
        '<div class="zhiwrite-ai-modal__body">' +
        '<div id="zhiwrite_ai_batch_summary" style="margin-bottom:10px;color:#1f2329;"></div>' +
        '<progress id="zhiwrite_ai_batch_progress" max="100" class="zhiwrite-ai-progressbar" style="width:100%;height:14px;"></progress>' +
        '<div id="zhiwrite_ai_batch_list" style="margin-top:12px;max-height:360px;overflow:auto;"></div>' +
        "</div>" +
        '<div class="zhiwrite-ai-modal__footer">' +
        '<button type="button" class="button" data-zhiwrite-batch-close="1">关闭</button>' +
        "</div>" +
        "</div>" +
        "</div>"
    );
    $("body").append($m);
    return $m;
  }

  function openBatchProgressModal() {
    var $m = ensureBatchProgressModal();
    $m.show().attr("aria-hidden", "false");
    $("body").addClass("zhiwrite-ai-modal-open");
    return $m;
  }

  function closeBatchProgressModal() {
    var $m = $("#zhiwrite_ai_tags_batch_modal");
    if (!$m.length) return;
    $m.hide().attr("aria-hidden", "true");
    $("body").removeClass("zhiwrite-ai-modal-open");
  }

  $(document).on(
    "click",
    "#zhiwrite_ai_tags_batch_modal [data-zhiwrite-batch-close]",
    function () {
      closeBatchProgressModal();
    }
  );

  function renderBatchList(rows) {
    rows = rows || [];
    var html =
      "<table class='widefat striped'><thead><tr>" +
      "<th style='width:90px;'>文章ID</th><th style='width:110px;'>状态</th><th>信息</th></tr></thead><tbody>";
    rows.forEach(function (r) {
      var st = r.status || "";
      var label = st;
      if (st === "pending") label = "未执行";
      if (st === "running") label = "执行中";
      if (st === "succeeded") label = "成功";
      if (st === "failed") label = "失败";
      if (st === "cancelled") label = "已取消";
      html +=
        "<tr>" +
        "<td>" +
        escHtml(String(r.postId || "")) +
        "</td>" +
        "<td>" +
        escHtml(label) +
        "</td>" +
        "<td>" +
        escHtml(String(r.message || "")) +
        "</td>" +
        "</tr>";
    });
    html += "</tbody></table>";
    return html;
  }

  function updateRowTagsCell(postId, tagsHtml) {
    if (!postId) return;
    var $row = $("#post-" + String(postId));
    if (!$row.length) return;
    var $cell = $row.find("td.tags, td.column-tags, td.taxonomy-post_tag").first();
    if (!$cell.length) return;
    if (typeof tagsHtml === "string" && String(tagsHtml).trim()) {
      $cell.html(String(tagsHtml));
    }
  }

  function pollBatch(batchId, $modal) {
    var polling = true;
    var tries = 0;
    function tick() {
      if (!polling) return;
      tries++;
      $.post(ZhiWriteAI.ajaxUrl, {
        action: "zhiwrite_ai_tags_batch_status",
        nonce: ZhiWriteAI.nonce,
        batch_id: batchId,
      })
        .done(function (res) {
          if (!res || !res.success || !res.data) return;
          var d = res.data;
          var total = parseInt(d.total || 0, 10) || 0;
          var done = parseInt(d.done || 0, 10) || 0;
          var ok = parseInt(d.ok || 0, 10) || 0;
          var fail = parseInt(d.fail || 0, 10) || 0;
          var pct = total > 0 ? Math.round((done * 100) / total) : 0;
          $modal
            .find("#zhiwrite_ai_batch_summary")
            .text("进度：" + done + "/" + total + "，成功 " + ok + "，失败 " + fail);
          $modal.find("#zhiwrite_ai_batch_progress").val(pct);
          $modal.find("#zhiwrite_ai_batch_list").html(renderBatchList(d.rows || []));

          (d.rows || []).forEach(function (r) {
            if (r && r.status === "succeeded" && r.tagsHtml) {
              updateRowTagsCell(r.postId, r.tagsHtml);
            }
          });

          if (total > 0 && done >= total) {
            polling = false;
            showToast("success", "批量生成完成：成功 " + ok + "，失败 " + fail, 4500);
          }
        })
        .always(function () {
          if (!polling) return;
          var delay = tries < 10 ? 1200 : 2000;
          window.setTimeout(tick, delay);
        });
    }
    tick();
    return function stop() {
      polling = false;
    };
  }

  $(document).on("click", "#zhiwrite_bulk_generate_tags", function (e) {
    e.preventDefault();
    var ids = getSelectedPostIds();
    if (!ids.length) {
      showToast("warning", "请先勾选要批量生成标签的文章。", 3500);
      return;
    }
    openGenerateTagsModal(
      ids[0],
      function (payload) {
        payload = payload || {};
        showToast("info", "正在提交批量任务到后台队列…", 2000);
        $.ajax({
          url: ZhiWriteAI.ajaxUrl,
          method: "POST",
          dataType: "json",
          data: {
            action: "zhiwrite_ai_enqueue_tags_batch",
            nonce: ZhiWriteAI.nonce,
            post_ids: ids,
            interface_id: payload.interfaceId || "",
            model: payload.model || "",
            tag_count: payload.tagCount || 10,
            apply_mode: payload.applyMode || "append",
          },
        })
          .done(function (res) {
            if (!res || !res.success || !res.data) {
              var msg = (res && res.data && res.data.message) || "提交失败。";
              showToast("error", msg, 6500);
              return;
            }
            var batchId = res.data.batchId;
            var en = parseInt(res.data.enqueued || 0, 10) || 0;
            var sk = parseInt(res.data.skipped || 0, 10) || 0;
            showToast("success", "已入队：" + en + "，跳过：" + sk + "。正在执行…", 3500);
            var $m = openBatchProgressModal();
            $m.find("#zhiwrite_ai_batch_summary").text("已入队 " + en + " 个任务，正在执行…");
            $m.find("#zhiwrite_ai_batch_progress").val(1);
            pollBatch(batchId, $m);
          })
          .fail(function (xhr) {
            var msg =
              (xhr && xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message) ||
              "提交失败。";
            showToast("error", msg, 6500);
          });
      },
      { hasExistingTags: true }
    );
  });

  // Webhook queue page: live refresh.
  function initWebhookQueuePage() {
    var $tbody = $("#zhiwrite-webhook-queue-tbody");
    if (!$tbody.length) return;

    function renderRows(rows) {
      rows = rows || [];
      if (!rows.length) {
        return "<tr><td colspan='5'>暂无数据。</td></tr>";
      }
      var html = "";
      rows.forEach(function (r) {
        html +=
          "<tr>" +
          "<td>" +
          escHtml(String(r.id || "")) +
          "</td>" +
          "<td>" +
          (r.status_badge || escHtml(String(r.status_label || r.status || ""))) +
          "</td>" +
          "<td>" +
          escHtml(String(r.updated_at || "")) +
          "</td>" +
          "<td>" +
          escHtml(String(r.message || "")) +
          "</td>" +
          "<td>" +
          "<button type='button' class='button button-small zhiwrite-webhook-retry' data-id='" +
          escHtml(String(r.id || "")) +
          "'>重试</button>" +
          "</td>" +
          "</tr>";
      });
      return html;
    }

    function refresh() {
      $.post(ZhiWriteAI.ajaxUrl, {
        action: "zhiwrite_ai_webhook_queue_status",
        nonce: ZhiWriteAI.nonce,
      })
        .done(function (res) {
          if (!res || !res.success || !res.data) return;
          $tbody.html(renderRows(res.data.rows || []));
        })
        .fail(function () {});
    }

    $(document).on("click", "#zhiwrite-webhook-refresh", function (e) {
      e.preventDefault();
      refresh();
    });

    $(document).on("click", ".zhiwrite-webhook-retry", function (e) {
      e.preventDefault();
      var id = parseInt($(this).data("id") || "0", 10) || 0;
      if (!id) return;
      var $btn = $(this);
      $btn.prop("disabled", true);
      $.post(ZhiWriteAI.ajaxUrl, {
        action: "zhiwrite_ai_webhook_retry_now",
        nonce: ZhiWriteAI.nonce,
        id: id,
      })
        .done(function (res) {
          if (!res || !res.success) {
            var msg = (res && res.data && res.data.message) || "触发失败。";
            showToast("error", msg, 5000);
            return;
          }
          showToast("success", (res.data && res.data.message) || "已触发重试。", 2500);
          window.setTimeout(refresh, 600);
        })
        .always(function () {
          $btn.prop("disabled", false);
        });
    });

    refresh();
    window.setInterval(refresh, 4000);
  }

  function initWebhookLogsPage() {
    var $tbody = $("#zhiwrite-webhook-logs-tbody");
    if (!$tbody.length) return;

    function labelAction(a) {
      if (a === "webhook_send") return "发送成功";
      if (a === "webhook_error") return "发送失败";
      if (a === "webhook_retry_ok") return "重试成功";
      if (a === "webhook_retry_error") return "重试失败";
      return a || "";
    }

    function refresh() {
      $.post(ZhiWriteAI.ajaxUrl, { action: "zhiwrite_ai_webhook_logs", nonce: ZhiWriteAI.nonce })
        .done(function (res) {
          if (!res || !res.success || !res.data) return;
          var rows = res.data.rows || [];
          if (!rows.length) {
            $tbody.html("<tr><td colspan='6'>暂无数据。</td></tr>");
            return;
          }
          var html = "";
          rows.forEach(function (r) {
            var sig = r.signature_enabled ? "启用" : "未启用";
            var http = r.http_code ? String(r.http_code) : "-";
            var el = r.elapsed_ms ? String(r.elapsed_ms) : "-";
            var url = r.url || "";
            var tail = r.err ? ("错误：" + r.err) : (r.resp ? ("响应：" + r.resp) : "");
            var extra = "";
            if (r.attempt && r.max) extra = "（" + r.attempt + "/" + r.max + "）";
            html +=
              "<tr>" +
              "<td>" + escHtml(String(r.created_at || "")) + "</td>" +
              "<td>" + escHtml(labelAction(r.action) + extra) + "</td>" +
              "<td>" + escHtml(http) + "</td>" +
              "<td>" + escHtml(el) + "</td>" +
              "<td>" + escHtml(sig) + "</td>" +
              "<td><div><code>" + escHtml(url) + "</code></div><div style='margin-top:6px;color:#646970;'>" + escHtml(tail) + "</div></td>" +
              "</tr>";
          });
          $tbody.html(html);
        })
        .fail(function () {});
    }

    $(document).on("click", "#zhiwrite-webhook-logs-refresh", function (e) {
      e.preventDefault();
      refresh();
    });

    refresh();
    window.setInterval(refresh, 5000);
  }

  function getConfirmModal() {
    var $m = $("#zhiwrite_ai_confirm_modal");
    if ($m.length) return $m;

    $m = $(
      '<div id="zhiwrite_ai_confirm_modal" class="zhiwrite-ai-modal" style="display:none;" aria-hidden="true">' +
        '<div class="zhiwrite-ai-modal__backdrop" data-zhiwrite-modal-close="1"></div>' +
        '<div class="zhiwrite-ai-modal__dialog" role="dialog" aria-modal="true" aria-labelledby="zhiwrite_ai_confirm_title">' +
        '<div class="zhiwrite-ai-modal__header">' +
        '<div id="zhiwrite_ai_confirm_title" class="zhiwrite-ai-modal__title">提示</div>' +
        '<button type="button" class="zhiwrite-ai-modal__x" aria-label="关闭" data-zhiwrite-modal-close="1">' +
        getCloseIconSvg() +
        "</button>" +
        "</div>" +
        '<div class="zhiwrite-ai-modal__body">' +
        '<div class="zhiwrite-ai-modal__msg"></div>' +
        "</div>" +
        '<div class="zhiwrite-ai-modal__footer">' +
        '<button type="button" class="button zhiwrite-ai-modal__cancel" data-zhiwrite-modal-close="1">取消</button>' +
        '<button type="button" class="button button-primary zhiwrite-ai-modal__ok">确定</button>' +
        "</div>" +
        "</div>" +
        "</div>"
    );

    $("body").append($m);
    return $m;
  }

  function zhiwriteConfirm(message, onOk) {
    var $m = getConfirmModal();
    var msg = String(message || "");

    $m.find(".zhiwrite-ai-modal__msg").text(msg);
    $m.data("zhiwriteOnOk", typeof onOk === "function" ? onOk : null);

    $m.show().attr("aria-hidden", "false");
    $("body").addClass("zhiwrite-ai-modal-open");

    // Focus OK for keyboard flow.
    window.setTimeout(function () {
      $m.find(".zhiwrite-ai-modal__ok").trigger("focus");
    }, 0);
  }

  function closeConfirmModal() {
    var $m = $("#zhiwrite_ai_confirm_modal");
    if (!$m.length) return;
    $m.hide().attr("aria-hidden", "true");
    $m.data("zhiwriteOnOk", null);
    $("body").removeClass("zhiwrite-ai-modal-open");
  }

  // Modal events (delegated).
  $(document).on(
    "click",
    "#zhiwrite_ai_confirm_modal [data-zhiwrite-modal-close]",
    function () {
      closeConfirmModal();
    }
  );

  $(document).on("click", "#zhiwrite_ai_confirm_modal .zhiwrite-ai-modal__ok", function () {
    var $m = $("#zhiwrite_ai_confirm_modal");
    var cb = $m.data("zhiwriteOnOk");
    closeConfirmModal();
    if (typeof cb === "function") cb();
  });

  $(document).on("keydown", function (e) {
    var $m = $("#zhiwrite_ai_confirm_modal");
    if (!$m.length || !$m.is(":visible")) return;
    if (e.key === "Escape") {
      e.preventDefault();
      closeConfirmModal();
    }
  });

  function getGenerateTagsModal() {
    var $m = $("#zhiwrite_ai_generate_tags_modal");
    if ($m.length) return $m;

    $m = $(
      '<div id="zhiwrite_ai_generate_tags_modal" class="zhiwrite-ai-modal" style="display:none;" aria-hidden="true">' +
        '<div class="zhiwrite-ai-modal__backdrop" data-zhiwrite-gt-close="1"></div>' +
        '<div class="zhiwrite-ai-modal__dialog" role="dialog" aria-modal="true" aria-labelledby="zhiwrite_ai_gt_title">' +
        '<div class="zhiwrite-ai-modal__header">' +
        '<div id="zhiwrite_ai_gt_title" class="zhiwrite-ai-modal__title"></div>' +
        '<button type="button" class="zhiwrite-ai-modal__x" aria-label="关闭" data-zhiwrite-gt-close="1">' +
        getCloseIconSvg() +
        "</button>" +
        "</div>" +
        '<div class="zhiwrite-ai-modal__body">' +
        '<div class="zhiwrite-ai-formrow">' +
        '<label for="zhiwrite_gt_interface" style="display:block;font-weight:600;margin:0 0 6px;"></label>' +
        '<select id="zhiwrite_gt_interface" class="regular-text" style="width:100%;max-width:420px;"></select>' +
        '<p class="description" id="zhiwrite_gt_interface_hint" style="margin:6px 0 0;"></p>' +
        "</div>" +
        '<div class="zhiwrite-ai-formrow" style="margin-top:12px;">' +
        '<label for="zhiwrite_gt_model" style="display:block;font-weight:600;margin:0 0 6px;"></label>' +
        '<input type="text" id="zhiwrite_gt_model" class="regular-text" style="width:100%;max-width:420px;" placeholder="" />' +
        '<p class="description" style="margin:6px 0 0;">留空则使用该接口默认模型/全局默认模型。</p>' +
        "</div>" +
        '<div class="zhiwrite-ai-formrow" style="margin-top:12px;">' +
        '<label for="zhiwrite_gt_count" style="display:block;font-weight:600;margin:0 0 6px;"></label>' +
        '<input type="number" id="zhiwrite_gt_count" min="3" max="20" step="1" value="10" style="width:120px;" />' +
        '<span class="description" style="margin-left:8px;">建议 5-12 个。</span>' +
        "</div>" +
        '<div class="zhiwrite-ai-formrow" id="zhiwrite_gt_apply_mode_wrap" style="margin-top:12px;display:none;">' +
        '<div style="font-weight:600;margin:0 0 6px;" id="zhiwrite_gt_apply_mode_label"></div>' +
        '<label style="display:block;margin:4px 0;">' +
        '<input type="radio" name="zhiwrite_gt_apply_mode" value="replace" checked /> ' +
        '<span id="zhiwrite_gt_apply_mode_replace"></span>' +
        "</label>" +
        '<label style="display:block;margin:4px 0;">' +
        '<input type="radio" name="zhiwrite_gt_apply_mode" value="append" /> ' +
        '<span id="zhiwrite_gt_apply_mode_append"></span>' +
        "</label>" +
        '<p class="description" style="margin:6px 0 0;">若选择“增量添加”，将把新生成的标签追加到原有标签中。</p>' +
        "</div>" +
        "</div>" +
        '<div class="zhiwrite-ai-modal__footer">' +
        '<button type="button" class="button zhiwrite-ai-gt-cancel" data-zhiwrite-gt-close="1"></button>' +
        '<button type="button" class="button button-primary zhiwrite-ai-gt-ok"></button>' +
        "</div>" +
        "</div>" +
        "</div>"
    );

    $("body").append($m);
    return $m;
  }

  // Settings: prompt builder rollback.
  $(document).on("click", "#zhiwrite-prompt-builder-rollback", function (e) {
    e.preventDefault();
    var idx = $("#zhiwrite_prompt_builder_rev").val();
    idx = idx === null || typeof idx === "undefined" ? "" : String(idx);
    if (!idx) {
      showToast("warning", "请先选择一个历史版本。", 3500);
      return;
    }
    zhiwriteConfirm("确定回滚到所选版本吗？当前内容将被覆盖。", function () {
      showToast("info", "正在回滚…", 1500);
      $.post(ZhiWriteAI.ajaxUrl, {
        action: "zhiwrite_ai_prompt_builder_rollback",
        nonce: ZhiWriteAI.nonce,
        idx: idx,
      })
        .done(function (res) {
          if (!res || !res.success) {
            var msg = (res && res.data && res.data.message) || "回滚失败。";
            showToast("error", msg, 6500);
            return;
          }
          showToast("success", (res.data && res.data.message) || "已回滚。", 2500);
          window.setTimeout(function () {
            window.location.reload();
          }, 600);
        })
        .fail(function (xhr) {
          var msg =
            (xhr && xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message) ||
            "回滚失败。";
          showToast("error", msg, 6500);
        });
    });
  });

  function openGenerateTagsModal(postId, onOk, options) {
    var $m = getGenerateTagsModal();
    options = options || {};
    $m.data("zhiwriteGtPostId", parseInt(postId || 0, 10) || 0);
    $m.data("zhiwriteGtOnOk", typeof onOk === "function" ? onOk : null);

    $m.find("#zhiwrite_ai_gt_title").text(t("generateTagsTitle", "生成标签并保存"));
    $m.find('label[for="zhiwrite_gt_interface"]').text(t("chooseInterface", "选择接口"));
    $m.find('label[for="zhiwrite_gt_model"]').text(t("chooseModelOptional", "模型（可选）"));
    $m.find('label[for="zhiwrite_gt_count"]').text(t("tagCount", "标签数量"));
    $m.find("#zhiwrite_gt_apply_mode_label").text(t("tagApplyMode", "写入方式"));
    $m.find("#zhiwrite_gt_apply_mode_replace").text(t("tagApplyReplace", "覆盖原有标签"));
    $m.find("#zhiwrite_gt_apply_mode_append").text(t("tagApplyAppend", "增量添加（保留原有）"));
    $m.find(".zhiwrite-ai-gt-cancel").text(t("cancel", "取消"));
    $m.find(".zhiwrite-ai-gt-ok").text(t("confirm", "确定"));

    var interfaces = (ZhiWriteAI && ZhiWriteAI.opts && ZhiWriteAI.opts.interfaces) || [];
    var tg = (ZhiWriteAI && ZhiWriteAI.opts && ZhiWriteAI.opts.tagGen) || {};
    var defId = tg.defaultInterfaceId || (ZhiWriteAI && ZhiWriteAI.opts && ZhiWriteAI.opts.defaultInterfaceId) || "";
    var $sel = $m.find("#zhiwrite_gt_interface");
    $sel.empty();
    if (!interfaces || !interfaces.length) {
      $sel.append('<option value="">未配置接口（请先到智写AI->功能配置添加）</option>');
    } else {
      interfaces.forEach(function (it) {
        if (!it || !it.id) return;
        var name = it.name || it.id;
        var model = it.model ? "（" + it.model + "）" : "";
        var opt = '<option value="' + escHtml(it.id) + '">' + escHtml(name + model) + "</option>";
        $sel.append(opt);
      });
      if (defId) $sel.val(String(defId));
    }

    // When interface changes, prefill model placeholder.
    function updateHint() {
      var cur = String($sel.val() || "");
      var m = "";
      interfaces.forEach(function (it) {
        if (String(it.id) === cur) m = it.model || "";
      });
      $m.find("#zhiwrite_gt_model").attr("placeholder", m ? "例如：" + m : "例如：gpt-4.1-mini");
      $m.find("#zhiwrite_gt_interface_hint").text(cur ? "" : "未选择接口将无法生成。");
    }
    $sel.off("change.zhiwriteGt").on("change.zhiwriteGt", updateHint);
    updateHint();

    // Apply defaults from settings (tagGen).
    try {
      var defCount = parseInt(tg.defaultCount || "10", 10) || 10;
      if (defCount < 3) defCount = 3;
      if (defCount > 20) defCount = 20;
      $m.find("#zhiwrite_gt_count").val(String(defCount));
      if (tg.defaultModel) $m.find("#zhiwrite_gt_model").val(String(tg.defaultModel));
    } catch (e) {}

    // Apply mode visibility (only show when it seems the post already has tags).
    var hasExistingTags = !!options.hasExistingTags;
    if (hasExistingTags) {
      $m.find("#zhiwrite_gt_apply_mode_wrap").show();
      var mode = (tg && tg.defaultApplyMode) || "append";
      if (mode !== "append" && mode !== "replace") mode = "append";
      $m.find('input[name="zhiwrite_gt_apply_mode"][value="' + mode + '"]').prop("checked", true);
    } else {
      $m.find("#zhiwrite_gt_apply_mode_wrap").hide();
      $m
        .find('input[name="zhiwrite_gt_apply_mode"][value="replace"]')
        .prop("checked", true);
    }

    $m.show().attr("aria-hidden", "false");
    $("body").addClass("zhiwrite-ai-modal-open");
    window.setTimeout(function () {
      $sel.trigger("focus");
    }, 0);
  }

  function closeGenerateTagsModal() {
    var $m = $("#zhiwrite_ai_generate_tags_modal");
    if (!$m.length) return;
    $m.hide().attr("aria-hidden", "true");
    $m.data("zhiwriteGtPostId", null);
    $m.data("zhiwriteGtOnOk", null);
    $("body").removeClass("zhiwrite-ai-modal-open");
  }

  $(document).on(
    "click",
    "#zhiwrite_ai_generate_tags_modal [data-zhiwrite-gt-close]",
    function () {
      closeGenerateTagsModal();
    }
  );

  $(document).on("keydown", function (e) {
    var $m = $("#zhiwrite_ai_generate_tags_modal");
    if (!$m.length || !$m.is(":visible")) return;
    if (e.key === "Escape") {
      e.preventDefault();
      closeGenerateTagsModal();
    }
  });

  $(document).on("click", "#zhiwrite_ai_generate_tags_modal .zhiwrite-ai-gt-ok", function () {
    var $m = $("#zhiwrite_ai_generate_tags_modal");
    var postId = parseInt($m.data("zhiwriteGtPostId") || "0", 10) || 0;
    var cb = $m.data("zhiwriteGtOnOk");
    var interfaceId = String($m.find("#zhiwrite_gt_interface").val() || "");
    var model = String($m.find("#zhiwrite_gt_model").val() || "").trim();
    var tagCount = parseInt($m.find("#zhiwrite_gt_count").val() || "10", 10) || 10;
    var applyMode = String(
      $m.find('input[name="zhiwrite_gt_apply_mode"]:checked').val() || "replace"
    );
    if (applyMode !== "append" && applyMode !== "replace") applyMode = "replace";
    if (tagCount < 3) tagCount = 3;
    if (tagCount > 20) tagCount = 20;

    if (!interfaceId) {
      showToast("error", "请选择接口后再继续。", 4500);
      return;
    }

    closeGenerateTagsModal();
    if (typeof cb === "function")
      cb({
        postId: postId,
        interfaceId: interfaceId,
        model: model,
        tagCount: tagCount,
        applyMode: applyMode,
      });
  });

  function setLoading(isLoading) {
    if (isLoading) {
      $("#zhiwrite_generate_btn").prop("disabled", true);
      $(".zhiwrite-ai-spinner").addClass("is-active");
    } else {
      $("#zhiwrite_generate_btn").prop("disabled", false);
      $(".zhiwrite-ai-spinner").removeClass("is-active");
    }
  }

  // Streaming / cancel / self-test features removed. Keep only direct output mode.

  function setTestLoading(isLoading) {
    if (isLoading) {
      $("#zhiwrite_test_api_btn").prop("disabled", true);
      $("#zhiwrite_test_api_spinner").addClass("is-active");
    } else {
      $("#zhiwrite_test_api_btn").prop("disabled", false);
      $("#zhiwrite_test_api_spinner").removeClass("is-active");
    }
  }

  function escHtml(str) {
    return String(str || "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#039;");
  }

  function getToastIconSvg(type) {
    var t = type || "info";
    // Plugin svg icons (filled). Colors are controlled by CSS (currentColor).
    if (t === "success") {
      return (
        '<svg class="zhiwrite-ai-toast__svg" viewBox="0 0 1024 1024" width="18" height="18" focusable="false" aria-hidden="true" fill="currentColor">' +
        '<path d="M512 85.333333c235.648 0 426.666667 191.018667 426.666667 426.666667s-191.018667 426.666667-426.666667 426.666667S85.333333 747.648 85.333333 512 276.352 85.333333 512 85.333333z m150.485333 318.549334a32 32 0 0 0-45.226666 0.298666l-145.877334 147.754667-64.768-64.725333a32 32 0 0 0-45.226666 45.269333l87.552 87.466667a32 32 0 0 0 45.397333-0.128l168.448-170.666667a32 32 0 0 0-0.298667-45.226667z"></path>' +
        "</svg>"
      );
    }
    if (t === "error") {
      return (
        '<svg class="zhiwrite-ai-toast__svg" viewBox="0 0 1024 1024" width="18" height="18" focusable="false" aria-hidden="true" fill="currentColor">' +
        '<path d="M512 85.333333c235.648 0 426.666667 191.018667 426.666667 426.666667s-191.018667 426.666667-426.666667 426.666667S85.333333 747.648 85.333333 512 276.352 85.333333 512 85.333333z m-133.333333 293.333334a32 32 0 0 1 45.226666 0L512 466.773333l88.106667-88.106666a32 32 0 1 1 45.226666 45.226666L557.226667 512l88.106666 88.106667a32 32 0 0 1-45.226666 45.226666L512 557.226667l-88.106667 88.106666a32 32 0 0 1-45.226666-45.226666L466.773333 512l-88.106666-88.106667a32 32 0 0 1 0-45.226666z"></path>' +
        "</svg>"
      );
    }
    if (t === "warning") {
      return (
        '<svg class="zhiwrite-ai-toast__svg" viewBox="0 0 1024 1024" width="18" height="18" focusable="false" aria-hidden="true" fill="currentColor">' +
        '<path d="M512 85.333333c235.648 0 426.666667 191.018667 426.666667 426.666667s-191.018667 426.666667-426.666667 426.666667S85.333333 747.648 85.333333 512 276.352 85.333333 512 85.333333z m4.266667 522.666667H512a32 32 0 0 0-32 32v4.266667a32 32 0 0 0 31.872 32h4.266667a32 32 0 0 0 32.128-32V640a32 32 0 0 0-32-32z m-2.133334-298.666667a32 32 0 0 0-32 32v170.666667a32 32 0 1 0 64 0V341.333333a32 32 0 0 0-32-32z"></path>' +
        "</svg>"
      );
    }
    return (
      '<svg class="zhiwrite-ai-toast__svg" viewBox="0 0 1024 1024" width="18" height="18" focusable="false" aria-hidden="true" fill="currentColor">' +
      '<path d="M512 85.333333c235.648 0 426.666667 191.018667 426.666667 426.666667s-191.018667 426.666667-426.666667 426.666667S85.333333 747.648 85.333333 512 276.352 85.333333 512 85.333333z m2.133333 356.266667a32 32 0 0 0-32 32v170.666667a32 32 0 0 0 64 0v-170.666667a32 32 0 0 0-32-32z m2.005334-132.266667h-4.266667a32 32 0 0 0-31.872 32v4.266667c0 17.664 14.336 32 32 32h4.266667a32 32 0 0 0 32-32V341.333333a32 32 0 0 0-32.128-32z"></path>' +
      "</svg>"
    );
  }

  function getCloseIconSvg() {
    return (
      '<svg class="zhiwrite-ai-toast__svg" viewBox="0 0 24 24" width="16" height="16" focusable="false" aria-hidden="true">' +
      '<path d="M18.3 5.7 12 12l6.3 6.3-1.4 1.4L10.6 13.4 4.3 19.7 2.9 18.3 9.2 12 2.9 5.7 4.3 4.3l6.3 6.3 6.3-6.3z"></path>' +
      "</svg>"
    );
  }

  $(document).on("click", "#zhiwrite_generate_btn", function (e) {
    e.preventDefault();

    function genRequestId() {
      return (
        "req_" +
        Date.now().toString(36) +
        "_" +
        Math.random().toString(36).slice(2, 10)
      );
    }

    function formatSeconds(sec) {
      sec = Math.max(0, parseInt(sec || 0, 10) || 0);
      var m = Math.floor(sec / 60);
      var s = sec % 60;
      if (m <= 0) return s + " 秒";
      return m + " 分 " + s + " 秒";
    }

    function stageLabel(stage) {
      var map = {
        start: "启动",
        prepare: "读取配置",
        prompt: "构建提示词",
        request: "请求接口生成",
        parse: "解析结果",
        save: "保存草稿",
        finalize: "收尾",
        done: "完成",
        error: "错误",
      };
      return map[stage] || stage || "处理中";
    }

    function renderProgressUI() {
      return (
        "<div class='zhiwrite-ai-progress'>" +
        "<div class='zhiwrite-ai-progress__head'>" +
        "<span class='zhiwrite-ai-spinner is-active' aria-hidden='true'></span>" +
        "<strong id='zhiwrite_progress_stage'>正在启动…</strong>" +
        "<span class='description' id='zhiwrite_progress_meta'>已耗时 0 秒</span>" +
        "</div>" +
        "<div id='zhiwrite_progress_wrap' class='zhiwrite-ai-progressbar2 is-indeterminate' aria-hidden='true'>" +
        "<div class='zhiwrite-ai-progressbar2__fill' id='zhiwrite_progress_fill' style='width:6%'></div>" +
        "</div>" +
        "<div class='description' id='zhiwrite_progress_msg' style='margin-top:8px;'>正在准备…</div>" +
        "<div class='description' id='zhiwrite_progress_hint' style='margin-top:6px;color:#646970;'>" +
        "提示：生成时间取决于模型响应与文章长度；如果长时间无心跳，可能是网络阻塞但后台仍在执行。" +
        "</div>" +
        "</div>"
      );
    }

    var interfaceId = $("#zhiwrite_interface").val();
    var title = $("#zhiwrite_title").val();
    var prompt = $("#zhiwrite_prompt").val();
    var model = $("#zhiwrite_model").val();
    var templateId = $("#zhiwrite_template_id").length ? $("#zhiwrite_template_id").val() : "";
    var styleId = $("#zhiwrite_style_id").length ? $("#zhiwrite_style_id").val() : "";
    var varsOverride = $("#zhiwrite_vars_override").length ? $("#zhiwrite_vars_override").val() : "";
    var doSeo = $("#zhiwrite_do_seo").is(":checked") ? 1 : 0;
    var doTerms = $("#zhiwrite_do_terms").is(":checked") ? 1 : 0;
    var doDisc = $("#zhiwrite_do_disclaimer").is(":checked") ? 1 : 0;

    var requestId = genRequestId();
    var pollTimer = null;
    var elapsedTimer = null;
    var localStartedAt = Date.now();
    var queuedMode = false;
    var finalHandled = false;

    setLoading(true);
    $("#zhiwrite_result").html(renderProgressUI());
    showToast("info", "已提交生成任务，正在获取进度…", 1800);

    function stopTimers() {
      if (pollTimer) window.clearInterval(pollTimer);
      pollTimer = null;
      if (elapsedTimer) window.clearInterval(elapsedTimer);
      elapsedTimer = null;
    }

    function renderResultPayload(d) {
      d = d || {};
      var html = "";
      if (d.saved) {
        showToast("success", "已生成并保存。", 2500);
        if (d.editUrl) {
          html +=
            '<p><a class="button button-primary" target="_blank" href="' +
            escHtml(d.editUrl) +
            '">打开文章</a></p>';
        }
      } else {
        showToast("success", queuedMode ? "后台任务已完成：仅展示结果（未保存）。" : "已生成：仅展示结果（未保存）。", 2500);
        html += "<p>";
        html +=
          '<button class="button button-primary" id="zhiwrite_save_draft_btn">保存为草稿</button> ';
        if (ZhiWriteAI.opts && parseInt(ZhiWriteAI.opts.canPublish || 0, 10) === 1) {
          html += '<button class="button" id="zhiwrite_publish_btn">直接发布</button> ';
        }
        html += '<button class="button" id="zhiwrite_reset_original_btn" style="margin-left:8px;">恢复原始生成版本</button>';
        html += '<span class="description" style="margin-left:8px;">可直接编辑后再保存/发布（会保留原始版本用于回滚）</span>';
        html += "</p>";
      }
      if (!d.saved) {
        html += "<h3>标题（可编辑）</h3>";
        html +=
          "<div class='zhiwrite-ai-box'><input type='text' id='zhiwrite_edit_title' class='regular-text' style='width:100%;max-width:860px;' value='" +
          escHtml(d.title) +
          "' /></div>";
        html += "<h3>摘要（可编辑）</h3>";
        html +=
          "<div class='zhiwrite-ai-box'><textarea id='zhiwrite_edit_excerpt' rows='4' class='large-text' style='width:100%;max-width:860px;'>" +
          escHtml(d.excerpt || "") +
          "</textarea></div>";
        html += "<h3>正文（可编辑）</h3>";
        html +=
          "<div class='zhiwrite-ai-box'><textarea id='zhiwrite_edit_content' rows='18' class='large-text code' style='width:100%;max-width:860px;'>" +
          escHtml(d.content || "") +
          "</textarea></div>";
      } else {
        html += "<h3>标题</h3><div class='zhiwrite-ai-box'>" + escHtml(d.title) + "</div>";
        html += "<h3>摘要</h3><div class='zhiwrite-ai-box'>" + escHtml(d.excerpt) + "</div>";
        html += "<h3>正文</h3><pre class='zhiwrite-ai-pre'>" + escHtml(d.content) + "</pre>";
      }

      if (d.seo) {
        html += "<h3>SEO</h3>";
        html +=
          "<div class='zhiwrite-ai-box'><strong>slug：</strong>" +
          escHtml(d.seo.slug) +
          "<br /><strong>焦点关键词：</strong>" +
          escHtml(d.seo.focusKeyword) +
          "</div>";
      }
      if (d.seoHints && d.seoHints.length) {
        html += "<h3>SEO 提示</h3>";
        html += "<ul class='zhiwrite-ai-hints'>";
        for (var i = 0; i < d.seoHints.length; i++) {
          html += "<li>" + escHtml(String(d.seoHints[i] || "")) + "</li>";
        }
        html += "</ul>";
      }
      if (d.internalLinks && d.internalLinks.enabled) {
        html += "<h3>内部链接</h3>";
        var inserted = parseInt(d.internalLinks.inserted || 0, 10) || 0;
        html +=
          "<div class='zhiwrite-ai-box'>已插入：" +
          escHtml(String(inserted)) +
          " 条</div>";
      }
      if (d.toc && d.toc.enabled) {
        html += "<h3>目录（TOC）</h3>";
        var ins2 = parseInt(d.toc.inserted || 0, 10) || 0;
        html += "<div class='zhiwrite-ai-box'>已插入：" + escHtml(String(ins2)) + " 条标题</div>";
      }
      if (d.faq && d.faq.enabled) {
        html += "<h3>FAQ</h3>";
        var ins3 = parseInt(d.faq.inserted || 0, 10) || 0;
        html += "<div class='zhiwrite-ai-box'>已插入：" + escHtml(String(ins3)) + " 条</div>";
      }
      if (d.precheck && d.precheck.enabled) {
        html += "<h3>发布前校验清单</h3>";
        var items = d.precheck.items || [];
        if (!items.length) {
          html += "<div class='zhiwrite-ai-box'>（无）</div>";
        } else {
          html += "<ul class='zhiwrite-ai-precheck'>";
          for (var pi = 0; pi < items.length; pi++) {
            var it = items[pi] || {};
            var lvl = String(it.level || "ok");
            var cls = "zhiwrite-precheck zhiwrite-precheck--" + lvl;
            html += "<li class='" + escHtml(cls) + "'>" + escHtml(String(it.text || "")) + "</li>";
          }
          html += "</ul>";
        }
      }
      if (d.fact && (d.fact.verify_points || d.fact.source_hints)) {
        html += "<h3>事实核查（有限）</h3>";
        var vp = (d.fact.verify_points || []).slice(0);
        var sh = (d.fact.source_hints || []).slice(0);
        if (vp.length) {
          html += "<div class='zhiwrite-ai-box'><strong>可验证要点：</strong><ul class='zhiwrite-ai-hints'>";
          for (var vi = 0; vi < vp.length; vi++) {
            html += "<li>" + escHtml(String(vp[vi] || "")) + "</li>";
          }
          html += "</ul></div>";
        }
        if (sh.length) {
          html += "<div class='zhiwrite-ai-box' style='margin-top:10px;'><strong>引用来源建议：</strong><ul class='zhiwrite-ai-hints'>";
          for (var si = 0; si < sh.length; si++) {
            html += "<li>" + escHtml(String(sh[si] || "")) + "</li>";
          }
          html += "</ul></div>";
        }
      }
      if (d.terms) {
        html += "<h3>分类/标签建议</h3>";
        html += "<div class='zhiwrite-ai-box'>";
        html += "<div><strong>分类：</strong></div>";
        var cats = (d.terms.categories || []).slice(0);
        if (!cats.length) html += "<div class='description'>（无）</div>";
        for (var ci = 0; ci < cats.length; ci++) {
          var c = String(cats[ci] || "");
          if (!c) continue;
          html +=
            "<label style='margin-right:10px;display:inline-block;'>" +
            "<input type='checkbox' class='zhiwrite-term-cat' value='" +
            escHtml(c) +
            "' /> " +
            escHtml(c) +
            "</label>";
        }
        html += "<hr style='margin:10px 0;' />";
        html += "<div><strong>标签：</strong></div>";
        var tags = (d.terms.tags || []).slice(0);
        if (!tags.length) html += "<div class='description'>（无）</div>";
        for (var ti = 0; ti < tags.length; ti++) {
          var t = String(tags[ti] || "");
          if (!t) continue;
          html +=
            "<label style='margin-right:10px;display:inline-block;'>" +
            "<input type='checkbox' class='zhiwrite-term-tag' value='" +
            escHtml(t) +
            "' /> " +
            escHtml(t) +
            "</label>";
        }
        html += "<p class='description' style='margin-top:8px;'>提示：勾选后保存/发布才会写入文章分类/标签。</p>";
        if (d.saved) {
          html +=
            "<p style='margin-top:10px;'><button class='button button-secondary' id='zhiwrite_apply_terms_btn' data-post-id='" +
            escHtml(String(d.postId || 0)) +
            "'>应用所选分类/标签</button> " +
            "<span class='description' style='margin-left:8px;'>将勾选的术语写入文章</span></p>";
        }
        html += "</div>";
      }

      $("#zhiwrite_result").html(html);

      // Preserve original generation for reset + backend meta save.
      if (!window.__zhiwriteLastGenOriginal) {
        window.__zhiwriteLastGenOriginal = {
          title: d.title || "",
          excerpt: d.excerpt || "",
          content: d.content || "",
          contentFormat: d.contentFormat || d.format || "",
          seo: d.seo || {},
          terms: d.terms || {},
        };
      }

      window.__zhiwriteLastGen = {
        title: d.title || "",
        excerpt: d.excerpt || "",
        content: d.content || "",
        contentFormat: d.contentFormat || d.format || "",
        seo: d.seo || {},
        terms: d.terms || {},
        seoHints: d.seoHints || [],
        internalLinks: d.internalLinks || {},
        toc: d.toc || {},
        faq: d.faq || {},
        precheck: d.precheck || {},
        fact: d.fact || {},
      };

      // For apply-terms fallback.
      if (d && d.saved && d.postId) {
        window.__zhiwriteLastSavedPostId = parseInt(d.postId || 0, 10) || 0;
      }
    }

    function fetchQueuedResult() {
      var fd = new FormData();
      fd.append("action", "zhiwrite_ai_get_task_result");
      fd.append("nonce", ZhiWriteAI.nonce);
      fd.append("request_id", requestId);
      fetch(ZhiWriteAI.ajaxUrl, { method: "POST", body: fd })
        .then(function (r) { return r.json(); })
        .then(function (res) {
          if (res && res.success && res.data) {
            renderResultPayload(res.data);
          } else {
            var msg = (res && res.data && res.data.message) || "获取结果失败。";
            showToast("error", msg, 6000);
          }
        })
        .catch(function () {
          showToast("error", "获取结果失败。", 6000);
        })
        .finally(function () {
          stopTimers();
          setLoading(false);
        });
    }

    function updateProgressUI(st) {
      if (!st) return;
      var percent = st.percent;
      if (percent === null || typeof percent === "undefined") {
        // fallback: keep current bar value
        var curW = $("#zhiwrite_progress_fill").length
          ? parseInt(String($("#zhiwrite_progress_fill").css("width") || "0"), 10) || 5
          : 5;
        percent = curW;
      }
      percent = Math.max(0, Math.min(100, parseInt(percent, 10) || 0));

      var elapsed = typeof st.elapsed !== "undefined" ? st.elapsed : Math.round((Date.now() - localStartedAt) / 1000);
      var age = typeof st.age !== "undefined" ? st.age : 0;
      var stage = st.stage || "";

      $("#zhiwrite_progress_stage").text(stageLabel(stage) + "（" + percent + "%）");
      // Steady progressbar: use indeterminate stripes during the long request stage.
      if (stage === "request") {
        $("#zhiwrite_progress_wrap").addClass("is-indeterminate");
      } else {
        $("#zhiwrite_progress_wrap").removeClass("is-indeterminate");
      }
      if ($("#zhiwrite_progress_fill").length) {
        // Keep a minimum visible fill so it doesn't look stuck.
        var w = Math.max(6, Math.min(100, percent));
        $("#zhiwrite_progress_fill").css("width", String(w) + "%");
      }
      $("#zhiwrite_progress_msg").text(st.message || "处理中…");

      var meta = "已耗时 " + formatSeconds(elapsed);
      if (age >= 8) meta += " · 距离上次心跳 " + age + " 秒";
      $("#zhiwrite_progress_meta").text(meta);

      if (age >= 15) {
        $("#zhiwrite_progress_hint").text("心跳较久未更新：可能网络阻塞/接口较慢/服务器忙，但任务可能仍在后台执行。建议再等一会或稍后查看“生成记录”。");
      }

      // Queue mode: once done/error, fetch final result or stop.
      if (queuedMode && !finalHandled && (stage === "done" || stage === "error")) {
        finalHandled = true;
        if (stage === "done") {
          fetchQueuedResult();
        } else {
          stopTimers();
          setLoading(false);
          showToast("error", st.message || "任务失败。", 7000);
        }
      }
    }

    // Local elapsed ticker (even if status endpoint is temporarily unreachable).
    elapsedTimer = window.setInterval(function () {
      var elapsed = Math.round((Date.now() - localStartedAt) / 1000);
      var cur = $("#zhiwrite_progress_meta").text() || "";
      if (cur.indexOf("已耗时") >= 0) return; // status poll will update this anyway
      $("#zhiwrite_progress_meta").text("已耗时 " + formatSeconds(elapsed));
    }, 1000);

    // Poll server-side status to avoid "dry wait".
    function pollOnce() {
      var fd = new FormData();
      fd.append("action", "zhiwrite_ai_generation_status");
      fd.append("nonce", ZhiWriteAI.nonce);
      fd.append("request_id", requestId);
      fetch(ZhiWriteAI.ajaxUrl, { method: "POST", body: fd })
        .then(function (r) { return r.json(); })
        .then(function (res) {
          if (res && res.success && res.data) {
            updateProgressUI(res.data);
          }
        })
        .catch(function () {
          // ignore; UI still shows local timer
        });
    }
    pollOnce();
    pollTimer = window.setInterval(pollOnce, 1000);

    $.post(ZhiWriteAI.ajaxUrl, {
      action: "zhiwrite_ai_generate",
      nonce: ZhiWriteAI.nonce,
      request_id: requestId,
      // default: follow setting. If setting is manual, backend will turn it into preview.
      save_mode:
        (ZhiWriteAI.opts && ZhiWriteAI.opts.defaultPostStatus === "manual"
          ? "preview"
          : ""),
      interface_id: interfaceId,
      title: title,
      prompt: prompt,
      model: model,
      template_id: templateId,
      style_id: styleId,
      vars_override: varsOverride,
      do_seo: doSeo,
      do_terms: doTerms,
      do_disclaimer: doDisc,
    })
      .done(function (res) {
        if (!res || !res.success) {
          stopTimers();
          var code = (res && res.data && res.data.code) || "";
          var msg = (res && res.data && res.data.message) || "生成失败。";
          if (code === "busy") {
            // Concurrency limit hit: show as warning (not a hard error).
            showToast("warning", msg, 6000);
          } else {
            showToast("error", msg, 6000);
          }
          return;
        }

        var d = res.data || {};
        if (d.queued) {
          queuedMode = true;
          showToast("info", d.message || "任务已进入后台队列…", 2500);
          // Keep polling; final result will be fetched when stage becomes done.
          return;
        }

        stopTimers();
        renderResultPayload(d);
      })
      .fail(function (xhr) {
        stopTimers();
        var msg =
          (xhr && xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message) ||
          "请求失败。";
        showToast("error", msg, 6000);
      })
      .always(function () {
        if (!queuedMode) {
          stopTimers();
          setLoading(false);
        }
      });
  });

  // Manual save buttons (when default policy is "manual/preview").
  $(document).on("click", "#zhiwrite_save_draft_btn, #zhiwrite_publish_btn", function (e) {
    e.preventDefault();
    var isPublish = $(this).attr("id") === "zhiwrite_publish_btn";
    var payload = window.__zhiwriteLastGen || null;
    if (!payload || !payload.content) {
      showToast("error", "没有可保存的内容，请先生成。", 3500);
      return;
    }

    setLoading(true);
    showToast("info", isPublish ? "正在发布…" : "正在保存草稿…", 1800);

    // Collect selected terms from UI (manual confirm).
    var selCats = [];
    var selTags = [];
    try {
      $(".zhiwrite-term-cat:checked").each(function () {
        var v = String($(this).val() || "").trim();
        if (v) selCats.push(v);
      });
      $(".zhiwrite-term-tag:checked").each(function () {
        var v = String($(this).val() || "").trim();
        if (v) selTags.push(v);
      });
    } catch (e2) {}
    // Read edited values from UI if present.
    var editedTitle = $("#zhiwrite_edit_title").length ? String($("#zhiwrite_edit_title").val() || "") : payload.title;
    var editedExcerpt = $("#zhiwrite_edit_excerpt").length ? String($("#zhiwrite_edit_excerpt").val() || "") : payload.excerpt;
    var editedContent = $("#zhiwrite_edit_content").length ? String($("#zhiwrite_edit_content").val() || "") : payload.content;
    var orig = window.__zhiwriteLastGenOriginal || payload;

    $.post(ZhiWriteAI.ajaxUrl, {
      action: "zhiwrite_ai_save_post",
      nonce: ZhiWriteAI.nonce,
      post_status: isPublish ? "publish" : "draft",
      title: editedTitle,
      excerpt: editedExcerpt,
      content: editedContent,
      content_format: payload.contentFormat,
      slug: (payload.seo && payload.seo.slug) || "",
      focus_keyword: (payload.seo && payload.seo.focusKeyword) || "",
      categories: selCats,
      tags: selTags,
      original_title: orig.title || "",
      original_excerpt: orig.excerpt || "",
      original_content: orig.content || "",
      original_content_format: orig.contentFormat || payload.contentFormat || "",
    })
      .done(function (res) {
        if (!res || !res.success) {
          var code = (res && res.data && res.data.code) || "";
          if (code === "precheck") {
            var msg2 = (res && res.data && res.data.message) || "发布前校验未通过。";
            showToast("warning", msg2, 7000);
            var pc = res && res.data && res.data.precheck;
            if (pc && pc.enabled) {
              try {
                // re-render checklist if present
                var d = window.__zhiwriteLastGen || {};
                d.precheck = pc;
                window.__zhiwriteLastGen = d;
              } catch (e) {}
            }
            if (res && res.data && res.data.editUrl) {
              $("#zhiwrite_result").prepend(
                '<p><a class="button button-primary" target="_blank" href="' +
                  escHtml(res.data.editUrl) +
                  '">打开草稿</a></p>'
              );
            }
            return;
          }
          var msg = (res && res.data && res.data.message) || "保存失败。";
          showToast("error", msg, 6000);
          return;
        }
        var d = res.data || {};
        showToast("success", isPublish ? "已发布。" : "已保存为草稿。", 2500);
        if (d.editUrl) {
          $("#zhiwrite_result").prepend(
            '<p><a class="button button-primary" target="_blank" href="' +
              escHtml(d.editUrl) +
              '">打开文章</a></p>'
          );
        }
        $("#zhiwrite_save_draft_btn, #zhiwrite_publish_btn").prop("disabled", true);
      })
      .fail(function (xhr) {
        var msg =
          (xhr && xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message) ||
          "请求失败。";
        showToast("error", msg, 6000);
      })
      .always(function () {
        setLoading(false);
      });
  });

  // Apply selected terms to a saved post (auto-save draft/publish flow).
  $(document).on("click", "#zhiwrite_apply_terms_btn", function (e) {
    e.preventDefault();
    var postId =
      parseInt($(this).data("postId") || $(this).data("post-id") || "0", 10) ||
      (window.__zhiwriteLastSavedPostId || 0);
    if (!postId) {
      showToast("error", "未找到文章ID，无法写入分类/标签。", 4500);
      return;
    }
    var selCats = [];
    var selTags = [];
    try {
      $(".zhiwrite-term-cat:checked").each(function () {
        var v = String($(this).val() || "").trim();
        if (v) selCats.push(v);
      });
      $(".zhiwrite-term-tag:checked").each(function () {
        var v = String($(this).val() || "").trim();
        if (v) selTags.push(v);
      });
    } catch (e2) {}

    setLoading(true);
    showToast("info", "正在写入分类/标签…", 1500);
    $.post(ZhiWriteAI.ajaxUrl, {
      action: "zhiwrite_ai_apply_terms",
      nonce: ZhiWriteAI.nonce,
      post_id: postId,
      categories: selCats,
      tags: selTags,
    })
      .done(function (res) {
        if (!res || !res.success) {
          var msg = (res && res.data && res.data.message) || "写入失败。";
          // backend uses 200 for some non-fatal validations
          showToast("warning", msg, 6500);
          return;
        }
        showToast("success", (res.data && res.data.message) || "已写入。", 3500);
      })
      .fail(function (xhr) {
        var msg =
          (xhr && xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message) ||
          "写入失败。";
        showToast("error", msg, 6000);
      })
      .always(function () {
        setLoading(false);
      });
  });

  // Reset to original generation in manual mode.
  $(document).on("click", "#zhiwrite_reset_original_btn", function (e) {
    e.preventDefault();
    var orig = window.__zhiwriteLastGenOriginal || null;
    if (!orig) return;
    if ($("#zhiwrite_edit_title").length) $("#zhiwrite_edit_title").val(String(orig.title || ""));
    if ($("#zhiwrite_edit_excerpt").length) $("#zhiwrite_edit_excerpt").val(String(orig.excerpt || ""));
    if ($("#zhiwrite_edit_content").length) $("#zhiwrite_edit_content").val(String(orig.content || ""));
    showToast("success", "已恢复原始生成版本。", 2000);
  });

  // Post edit screen: rollback to original generation.
  $(document).on("click", "#zhiwrite-rollback-original", function (e) {
    e.preventDefault();
    var postId = parseInt($(this).data("postId") || $(this).data("post-id") || "0", 10) || 0;
    if (!postId) return;
    zhiwriteConfirm("确定要回滚到原始生成版本吗？将覆盖当前标题/摘要/正文。", function () {
      showToast("info", "正在回滚…", 1500);
      $.post(ZhiWriteAI.ajaxUrl, {
        action: "zhiwrite_ai_rollback_post",
        nonce: ZhiWriteAI.nonce,
        post_id: postId,
      })
        .done(function (res) {
          if (!res || !res.success) {
            var msg = (res && res.data && res.data.message) || "回滚失败。";
            showToast("error", msg, 6500);
            return;
          }
          showToast("success", (res.data && res.data.message) || "已回滚。", 2500);
          window.setTimeout(function () {
            window.location.reload();
          }, 600);
        })
        .fail(function (xhr) {
          var msg =
            (xhr && xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message) ||
            "回滚失败。";
          showToast("error", msg, 6500);
        });
    });
  });

  // Interfaces settings table (add/remove/test).
  function renumberInterfaceRows() {
    $("#zhiwrite-interfaces-table tbody tr.zhiwrite-interface-row").each(
      function (idx) {
        $(this)
          .find("input[name^='zhiwrite_ai_writer_options[interfaces]']")
          .each(function () {
            var name = $(this).attr("name");
            if (!name) return;
            // Replace [interfaces][<n>] with current idx.
            name = name.replace(
              /zhiwrite_ai_writer_options\[interfaces\]\[\d+\]/,
              "zhiwrite_ai_writer_options[interfaces][" + idx + "]"
            );
            $(this).attr("name", name);
          });
      }
    );
  }

  function createInterfaceRow(idx) {
    var uid =
      "if_" +
      Date.now().toString(36) +
      "_" +
      Math.random().toString(36).slice(2, 8);
    var optKey = "zhiwrite_ai_writer_options";
    return $(
      '<tr class="zhiwrite-interface-row" data-interface-id="' +
        escHtml(uid) +
        '">' +
        "<td>" +
        '<label><input type="radio" name="' +
        optKey +
        '[default_interface_id]" value="' +
        escHtml(uid) +
        '"> 默认</label>' +
        "</td>" +
        "<td>" +
        '<input type="hidden" name="' +
        optKey +
        "[interfaces][" +
        idx +
        '][id]" value="' +
        escHtml(uid) +
        '">' +
        '<input type="text" class="regular-text" name="' +
        optKey +
        "[interfaces][" +
        idx +
        '][name]" placeholder="例如：OpenAI / 中转A / 备用" value="">' +
        "</td>" +
        "<td>" +
        '<input type="url" class="regular-text zhiwrite-if-base-url" name="' +
        optKey +
        "[interfaces][" +
        idx +
        '][api_base_url]" placeholder="https://api.example.com/v1" value="">' +
        "</td>" +
        "<td>" +
        '<input type="password" class="regular-text zhiwrite-if-api-key" name="' +
        optKey +
        "[interfaces][" +
        idx +
        '][api_key]" autocomplete="new-password" value="" placeholder="请输入 API Key">' +
        '<div style="margin-top:6px;line-height:1.2;">' +
        '<label class="description"><input type="checkbox" class="zhiwrite-if-clear-key" name="' +
        optKey +
        "[interfaces][" +
        idx +
        '][clear_key]" value="1"> 清空 Key（谨慎）</label>' +
        "</div>" +
        "</td>" +
        "<td>" +
        '<input type="text" class="regular-text zhiwrite-if-model" name="' +
        optKey +
        "[interfaces][" +
        idx +
        '][model]" placeholder="gpt-4o-mini" value="">' +
        "</td>" +
        "<td>" +
        '<button type="button" class="button zhiwrite-if-test">测试</button> ' +
        '<button type="button" class="button link-delete zhiwrite-if-remove">删除</button>' +
        "</td>" +
        "</tr>"
    );
  }

  $(document).on("click", "#zhiwrite-if-add", function (e) {
    e.preventDefault();
    var $tbody = $("#zhiwrite-interfaces-table tbody");
    if (!$tbody.length) return;
    var idx = $tbody.find("tr.zhiwrite-interface-row").length;
    var $row = createInterfaceRow(idx);
    $tbody.append($row);
    // If no default selected yet, select the newly added.
    var $anyDefault = $(
      'input[name="zhiwrite_ai_writer_options[default_interface_id]"]:checked'
    );
    if (!$anyDefault.length) {
      $row
        .find('input[name="zhiwrite_ai_writer_options[default_interface_id]"]')
        .prop("checked", true);
    }
  });

  $(document).on("click", ".zhiwrite-if-remove", function (e) {
    e.preventDefault();
    var confirmMsg =
      (window.ZhiWriteAI &&
        window.ZhiWriteAI.i18n &&
        window.ZhiWriteAI.i18n.confirmDeleteInterface) ||
      "确定删除该接口吗？";

    var $btn = $(this);
    zhiwriteConfirm(confirmMsg, function () {
      var $row = $btn.closest("tr.zhiwrite-interface-row");
      if (!$row.length) return;

      var wasDefault = $row
        .find('input[name="zhiwrite_ai_writer_options[default_interface_id]"]')
        .is(":checked");

      $row.remove();
      renumberInterfaceRows();

      if (wasDefault) {
        // Pick first as default if exists.
        var $first = $("#zhiwrite-interfaces-table tbody tr.zhiwrite-interface-row")
          .first()
          .find(
            'input[name="zhiwrite_ai_writer_options[default_interface_id]"]'
          );
        if ($first.length) $first.prop("checked", true);
      }
    });
  });

  $(document).on("click", "#zhiwrite-if-test-all", function (e) {
    e.preventDefault();

    if (zhiwriteIfTestBusy) {
      showToast("info", t("testBusy", "已有测试任务进行中，请稍候…"), 2000);
      return;
    }
    setIfTestBusy(true);

    var $btn = $(this);
    var $result = $("#zhiwrite-if-test-result");
    var $toggleDbg = $("#zhiwrite-if-toggle-debug");
    var $clearBtn = $("#zhiwrite-if-clear-result");

    // Use the global timeout setting on the settings page (seconds).
    var timeoutSec = (function () {
      var $t = $('input[name="zhiwrite_ai_writer_options[timeout]"]');
      var n = $t.length ? parseInt($t.val(), 10) : 0;
      if (!n || isNaN(n)) n = 60;
      if (n < 5) n = 5;
      if (n > 300) n = 300;
      return n;
    })();

    function applyDebugVisibility() {
      var hidden = !!$result.data("zhiwriteDebugHidden");
      if (hidden) {
        $result.find("details").css("display", "none");
        if ($toggleDbg && $toggleDbg.length) $toggleDbg.text(t("showDebug", "显示调试信息"));
      } else {
        $result.find("details").css("display", "");
        if ($toggleDbg && $toggleDbg.length) $toggleDbg.text(t("hideDebug", "隐藏调试信息"));
      }
    }

    // Countdown UI.
    var remaining = timeoutSec;
    var timerId = null;

    function renderTestReport(isOk, title, ms, dbg, advice) {
      var lines = [];
      if (dbg && typeof dbg === "object") {
        if (dbg.endpoint) lines.push("endpoint: " + String(dbg.endpoint));
        if (dbg.host) lines.push("host: " + String(dbg.host));
        if (dbg.ip) lines.push("ip: " + String(dbg.ip));
        if (typeof dbg.dns_ms !== "undefined")
          lines.push("dns_ms: " + String(dbg.dns_ms));
        if (typeof dbg.tcp_ms !== "undefined")
          lines.push("tcp_ms: " + String(dbg.tcp_ms));
        if (typeof dbg.tcp_ok !== "undefined")
          lines.push("tcp_ok: " + String(dbg.tcp_ok));
        if (typeof dbg.http_code !== "undefined")
          lines.push("upstream_http: " + String(dbg.http_code));
        if (dbg.timeout) lines.push("timeout: " + String(dbg.timeout) + "s");
        if (typeof dbg.attempts !== "undefined")
          lines.push("attempts: " + String(dbg.attempts));
        if (dbg.error_code) lines.push("error_code: " + String(dbg.error_code));
        if (dbg.tcp_error) lines.push("tcp_error: " + String(dbg.tcp_error));
        if (dbg.body_snip) lines.push("body_snip: " + String(dbg.body_snip));
      }

      var html =
        '<div class="notice ' +
        (isOk ? "notice-success" : "notice-error") +
        ' is-dismissible" style="margin:10px 0 0;">' +
        "<p><strong>" +
        escHtml(title) +
        "</strong>" +
        (ms ? "（" + escHtml(String(ms)) + "ms）" : "") +
        "</p>";

      if (advice && advice.length) {
        html +=
          '<p style="margin:6px 0 0;"><strong>建议：</strong></p><ul style="margin:6px 0 0 18px;">';
        for (var i = 0; i < advice.length; i++) {
          html += "<li>" + escHtml(String(advice[i])) + "</li>";
        }
        html += "</ul>";
      }

      if (lines.length) {
        html +=
          '<details style="margin-top:8px;"><summary>调试信息</summary><pre style="white-space:pre-wrap;margin:8px 0 0;">' +
          escHtml(lines.join("\n")) +
          "</pre></details>";
      }
      html += "</div>";
      return html;
    }

    function buildPlainTextReport(items) {
      var out = [];
      out.push(t("batchReportTitle", "ZhiWriteAI 批量测试报告"));
      out.push("时间: " + new Date().toISOString());
      out.push("");
      for (var i = 0; i < items.length; i++) {
        var it = items[i] || {};
        var name = it.name || it.id || ("#"+String(i+1));
        out.push(
          "- " +
            String(name) +
            " => " +
            (it.ok ? "OK" : "FAIL") +
            (it.ms ? " (" + String(it.ms) + "ms)" : "") +
            " | " +
            String(it.message || "")
        );
        if (it.debug && typeof it.debug === "object") {
          if (it.debug.endpoint) out.push("  endpoint: " + String(it.debug.endpoint));
          if (it.debug.host) out.push("  host: " + String(it.debug.host));
          if (it.debug.ip) out.push("  ip: " + String(it.debug.ip));
          if (typeof it.debug.dns_ms !== "undefined")
            out.push("  dns_ms: " + String(it.debug.dns_ms));
          if (typeof it.debug.tcp_ms !== "undefined")
            out.push("  tcp_ms: " + String(it.debug.tcp_ms));
          if (typeof it.debug.http_code !== "undefined")
            out.push("  upstream_http: " + String(it.debug.http_code));
          if (it.debug.error_code) out.push("  error_code: " + String(it.debug.error_code));
        }
        if (it.advice && it.advice.length) {
          out.push("  advice: " + it.advice.join(" | "));
        }
        out.push("");
      }
      return out.join("\n");
    }

    $btn.prop("disabled", true).data("zhiwriteOldText", $btn.text());
    $btn.text(t("testing", "测试中..."));
    showToast("info", t("testingAll", "正在批量测试所有接口..."), 2500);

    if ($result && $result.length) {
      $result
        .empty()
        .append(
          '<div class="notice notice-info is-dismissible" style="margin:10px 0 0;"><p>' +
            escHtml(t("testingAll", "正在批量测试所有接口...")) +
            '（' +
            escHtml(t("remaining", "剩余")) +
            ' <span class="zhiwrite-if-remaining">' +
            escHtml(String(timeoutSec)) +
            "</span>s）</p></div>"
        );
    }

    // Disable tools during run.
    if ($toggleDbg && $toggleDbg.length) $toggleDbg.prop("disabled", true);
    if ($clearBtn && $clearBtn.length) $clearBtn.prop("disabled", true);

    $btn.text(t("testingRemaining", "测试中...（剩余 %ss）").replace("%s", String(timeoutSec)));
    timerId = window.setInterval(function () {
      remaining = remaining - 1;
      if (remaining < 0) remaining = 0;
      try {
        $btn.text(t("testingRemaining", "测试中...（剩余 %ss）").replace("%s", String(remaining)));
      } catch (err) {}
      if ($result && $result.length) {
        $result.find(".zhiwrite-if-remaining").text(String(remaining));
      }
      if (remaining <= 0) {
        window.clearInterval(timerId);
        timerId = null;
      }
    }, 1000);

    $.post(ZhiWriteAI.ajaxUrl, {
      action: "zhiwrite_ai_test_api_all",
      nonce: ZhiWriteAI.nonce,
    })
      .done(function (res) {
        var restore = function () {
          $btn.prop("disabled", false);
          var old = $btn.data("zhiwriteOldText");
          if (old) $btn.text(old);
          else $btn.text(t("testAll", "一键测试全部接口"));
        };

        if (!res || !res.success || !res.data || !res.data.items) {
          var msg =
            (res && res.data && res.data.message) ||
            t("batchFailed", "批量测试失败。");
          showToast("error", msg, 6000);
          if ($result && $result.length) {
            $result.empty().append(renderTestReport(false, msg, 0, null, []));
          }
          applyDebugVisibility();
          if ($toggleDbg && $toggleDbg.length) $toggleDbg.prop("disabled", false);
          if ($clearBtn && $clearBtn.length) $clearBtn.prop("disabled", false);
          restore();
          return;
        }

        var items = res.data.items || [];
        var okCount = 0;
        for (var i = 0; i < items.length; i++) if (items[i] && items[i].ok) okCount++;
        var title =
          t("batchDone", "批量测试完成：成功 %1 / %2")
            .replace("%1", String(okCount))
            .replace("%2", String(items.length));
        showToast("success", title, 3500);

        if ($result && $result.length) {
          var reportText = buildPlainTextReport(items);
          var header =
            '<div class="notice notice-info is-dismissible" style="margin:10px 0 0;">' +
            "<p><strong>" +
            escHtml(title) +
            '</strong> <button type="button" class="button button-secondary" id="zhiwrite-copy-test-report" style="margin-left:8px;">' +
            escHtml(t("copyReport", "复制报告")) +
            "</button></p>" +
            '<details style="margin-top:8px;"><summary>' +
            escHtml(t("reportText", "报告文本（可复制）")) +
            '</summary><pre id="zhiwrite-test-report-text" style="white-space:pre-wrap;margin:8px 0 0;">' +
            escHtml(reportText) +
            "</pre></details></div>";

          $result.empty().append(header);
          for (var j = 0; j < items.length; j++) {
            var it = items[j] || {};
            var name = it.name || it.id || ("接口#" + String(j + 1));
            $result.append(
              renderTestReport(!!it.ok, name + "： " + (it.message || ""), it.ms || 0, it.debug || null, it.advice || [])
            );
          }
        }
        applyDebugVisibility();

        if ($toggleDbg && $toggleDbg.length) $toggleDbg.prop("disabled", false);
        if ($clearBtn && $clearBtn.length) $clearBtn.prop("disabled", false);
        restore();
      })
      .fail(function (xhr) {
        var msg =
          (xhr && xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message) ||
          t("batchFailed", "批量测试失败。");
        showToast("error", msg, 6000);
        if ($result && $result.length) {
          $result.empty().append(renderTestReport(false, msg, 0, null, []));
        }
        applyDebugVisibility();
        if ($toggleDbg && $toggleDbg.length) $toggleDbg.prop("disabled", false);
        if ($clearBtn && $clearBtn.length) $clearBtn.prop("disabled", false);
        $btn.prop("disabled", false);
        var old = $btn.data("zhiwriteOldText");
        if (old) $btn.text(old);
        else $btn.text(t("testAll", "一键测试全部接口"));
      })
      .always(function () {
        if (timerId) {
          window.clearInterval(timerId);
          timerId = null;
        }
        setIfTestBusy(false);
      });
  });

  // Batch test tools: toggle debug details and clear result panel.
  $(document).on("click", "#zhiwrite-if-toggle-debug", function (e) {
    e.preventDefault();
    var $btn = $(this);
    var $result = $("#zhiwrite-if-test-result");
    if (!$result.length) return;

    var hidden = !!$result.data("zhiwriteDebugHidden");
    if (hidden) {
      // Show details.
      $result.find("details").css("display", "");
      $result.data("zhiwriteDebugHidden", 0);
      $btn.text(t("hideDebug", "隐藏调试信息"));
    } else {
      // Hide details blocks (debug sections).
      $result.find("details").css("display", "none");
      $result.data("zhiwriteDebugHidden", 1);
      $btn.text(t("showDebug", "显示调试信息"));
    }
  });

  $(document).on("click", "#zhiwrite-if-clear-result", function (e) {
    e.preventDefault();
    var $result = $("#zhiwrite-if-test-result");
    if ($result.length) {
      $result.empty().data("zhiwriteDebugHidden", 0);
    }
    var $toggleDbg = $("#zhiwrite-if-toggle-debug");
    var $clearBtn = $("#zhiwrite-if-clear-result");
    if ($toggleDbg.length) {
      $toggleDbg.text(t("hideDebug", "隐藏调试信息")).prop("disabled", true);
    }
    if ($clearBtn.length) {
      $clearBtn.prop("disabled", true);
    }
  });

  $(document).on("click", "#zhiwrite-copy-test-report", function (e) {
    e.preventDefault();
    var $pre = $("#zhiwrite-test-report-text");
    if (!$pre.length) return;
    var txt = $pre.text() || "";
    if (!txt) return;
    copyToClipboard(txt)
      .then(function () {
        showToast("success", t("copiedReport", "已复制报告到剪贴板。"), 2000);
      })
      .catch(function () {
        showToast("error", t("copyFailed", "复制失败，请手动选择文本复制。"), 4000);
      });
  });

  $(document).on("click", ".zhiwrite-if-test", function (e) {
    e.preventDefault();

    if (zhiwriteIfTestBusy) {
      showToast("info", t("testBusy", "已有测试任务进行中，请稍候…"), 2000);
      return;
    }
    setIfTestBusy(true);

    // Extra feedback for debugging (in case toast is blocked/hidden).
    try {
      window.console && console.log && console.log("[ZhiWriteAI] test api clicked");
    } catch (err) {}

    var $btn = $(this);
    var $row = $btn.closest("tr.zhiwrite-interface-row");
    if (!$row.length) return;

    var interfaceId = $row.data("interfaceId") || $row.attr("data-interface-id") || "";
    var apiBaseUrl = $row.find(".zhiwrite-if-base-url").val();
    var apiKey = $row.find(".zhiwrite-if-api-key").val();
    var model = $row.find(".zhiwrite-if-model").val();

    // Use the global timeout setting on the settings page (seconds).
    var timeoutSec = (function () {
      var $t = $('input[name="zhiwrite_ai_writer_options[timeout]"]');
      var n = $t.length ? parseInt($t.val(), 10) : 0;
      if (!n || isNaN(n)) n = 60;
      if (n < 5) n = 5;
      if (n > 300) n = 300;
      return n;
    })();

    var $result = $("#zhiwrite-if-test-result");
    var $toggleDbg = $("#zhiwrite-if-toggle-debug");
    var $clearBtn = $("#zhiwrite-if-clear-result");

    function applyDebugVisibility() {
      var hidden = !!$result.data("zhiwriteDebugHidden");
      if (hidden) {
        $result.find("details").css("display", "none");
        if ($toggleDbg && $toggleDbg.length) $toggleDbg.text(t("showDebug", "显示调试信息"));
      } else {
        $result.find("details").css("display", "");
        if ($toggleDbg && $toggleDbg.length) $toggleDbg.text(t("hideDebug", "隐藏调试信息"));
      }
    }

    if ($result.length) {
      $result
        .empty()
        .append(
          '<div class="notice notice-info is-dismissible" style="margin:10px 0 0;"><p>' +
            escHtml(t("testingOne", "正在测试接口连接...")) +
            '（' +
            escHtml(t("remaining", "剩余")) +
            ' <span class="zhiwrite-if-remaining">' +
            escHtml(String(timeoutSec)) +
            "</span>s）</p></div>"
        );
    }

    $btn.prop("disabled", true).data("zhiwriteOldText", $btn.text());
    $btn.text(t("testingRemaining", "测试中...（剩余 %ss）").replace("%s", String(timeoutSec)));
    showToast("info", t("testingOne", "正在测试接口连接..."), 2500);

    // Disable tools during run.
    if ($toggleDbg && $toggleDbg.length) $toggleDbg.prop("disabled", true);
    if ($clearBtn && $clearBtn.length) $clearBtn.prop("disabled", true);

    // Countdown UI.
    var remaining = timeoutSec;
    var timerId = window.setInterval(function () {
      remaining = remaining - 1;
      if (remaining < 0) remaining = 0;
      try {
        $btn.text(t("testingRemaining", "测试中...（剩余 %ss）").replace("%s", String(remaining)));
      } catch (err) {}
      if ($result && $result.length) {
        $result.find(".zhiwrite-if-remaining").text(String(remaining));
      }
      if (remaining <= 0) {
        window.clearInterval(timerId);
        timerId = null;
      }
    }, 1000);

    function renderTestReport(isOk, title, ms, dbg, advice) {
      var lines = [];
      if (dbg && typeof dbg === "object") {
        if (dbg.endpoint) lines.push("endpoint: " + String(dbg.endpoint));
        if (typeof dbg.http_code !== "undefined")
          lines.push("upstream_http: " + String(dbg.http_code));
        if (dbg.timeout) lines.push("timeout: " + String(dbg.timeout) + "s");
        if (typeof dbg.attempts !== "undefined")
          lines.push("attempts: " + String(dbg.attempts));
        if (dbg.error_code) lines.push("error_code: " + String(dbg.error_code));
        if (dbg.body_snip) lines.push("body_snip: " + String(dbg.body_snip));
      }

      var html =
        '<div class="notice ' +
        (isOk ? "notice-success" : "notice-error") +
        ' is-dismissible" style="margin:10px 0 0;">' +
        "<p><strong>" +
        escHtml(title) +
        "</strong>" +
        (ms ? "（" + escHtml(String(ms)) + "ms）" : "") +
        "</p>";

      if (advice && advice.length) {
        html += "<p style=\"margin:6px 0 0;\"><strong>建议：</strong></p><ul style=\"margin:6px 0 0 18px;\">";
        for (var i = 0; i < advice.length; i++) {
          html += "<li>" + escHtml(String(advice[i])) + "</li>";
        }
        html += "</ul>";
      }

      if (lines.length) {
        html +=
          '<details style="margin-top:8px;"><summary>调试信息</summary><pre style="white-space:pre-wrap;margin:8px 0 0;">' +
          escHtml(lines.join("\n")) +
          "</pre></details>";
      }
      html += "</div>";
      return html;
    }

    $.ajax({
      url: ZhiWriteAI.ajaxUrl,
      method: "POST",
      dataType: "json",
      // Keep slightly above PHP/wp_remote_request timeout to avoid premature client-side timeout.
      timeout: Math.max(5000, (timeoutSec + 5) * 1000),
      data: {
        action: "zhiwrite_ai_test_api",
        nonce: ZhiWriteAI.nonce,
        interface_id: interfaceId,
        api_base_url: apiBaseUrl,
        api_key: apiKey,
        model: model,
      },
    })
      .done(function (res) {
        if (!res || !res.success) {
          var msg = (res && res.data && res.data.message) || "测试失败。";
          var ms = (res && res.data && res.data.ms) || 0;
          var dbg = (res && res.data && res.data.debug) || null;
          var advice = (res && res.data && res.data.advice) || [];
          showToast("error", msg + (ms ? "（" + ms + "ms）" : ""), 6000);
          if ($result && $result.length) {
            $result.empty().append(renderTestReport(false, msg, ms, dbg, advice));
          }
          applyDebugVisibility();
          if ($toggleDbg && $toggleDbg.length) $toggleDbg.prop("disabled", false);
          if ($clearBtn && $clearBtn.length) $clearBtn.prop("disabled", false);
          return;
        }
        var d = res.data || {};
        showToast(
          "success",
          (d.message || "连接成功。") + (d.ms ? "（" + d.ms + "ms）" : ""),
          3000
        );
        if ($result && $result.length) {
          $result
            .empty()
            .append(
              renderTestReport(
                true,
                d.message || "连接成功。",
                d.ms || 0,
                d.debug || null,
                []
              )
            );
        }
        applyDebugVisibility();
        if ($toggleDbg && $toggleDbg.length) $toggleDbg.prop("disabled", false);
        if ($clearBtn && $clearBtn.length) $clearBtn.prop("disabled", false);
      })
      .fail(function (xhr, textStatus, errorThrown) {
        var msg =
          (xhr &&
            xhr.responseJSON &&
            xhr.responseJSON.data &&
            xhr.responseJSON.data.message) ||
          "";

        if (!msg) {
          if (textStatus === "timeout")
            msg =
              "请求超时（" +
              timeoutSec +
              "s）。请检查接口是否可访问、服务器是否能出网。";
          else if (textStatus === "parsererror") msg = "返回解析失败（非 JSON）。可能有 PHP 报错/警告输出，或接口返回了 HTML。";
          else msg = "请求失败。";
        }

        var extra = "";
        if (xhr && typeof xhr.status === "number" && xhr.status) {
          extra += "HTTP " + xhr.status;
        }
        if (errorThrown) {
          extra += (extra ? "，" : "") + String(errorThrown);
        }

        // If server returned non-JSON, include a short snippet to help debug.
        var snippet = "";
        if (xhr && typeof xhr.responseText === "string" && xhr.responseText) {
          snippet = xhr.responseText.replace(/\s+/g, " ").slice(0, 220);
        }

        var finalMsg = msg;
        if (extra) finalMsg += "（" + extra + "）";
        if (snippet && textStatus === "parsererror") finalMsg += " 返回片段：" + snippet;

        showToast("error", finalMsg, 8000);
        if ($result && $result.length) {
          $result
            .empty()
            .append(
              '<div class="notice notice-error is-dismissible" style="margin:10px 0 0;"><p>' +
                escHtml(finalMsg) +
                "</p></div>"
            );
        }
        applyDebugVisibility();
        if ($toggleDbg && $toggleDbg.length) $toggleDbg.prop("disabled", false);
        if ($clearBtn && $clearBtn.length) $clearBtn.prop("disabled", false);
      })
      .always(function () {
        if (timerId) {
          window.clearInterval(timerId);
          timerId = null;
        }
        setIfTestBusy(false);
        var oldText = $btn.data("zhiwriteOldText");
        $btn.prop("disabled", false);
        if (oldText) $btn.text(oldText);
      });
  });

  // Settings import/export.
  $(document).on("click", "#zhiwrite-export-settings", function (e) {
    e.preventDefault();
    var includeKeys = $("#zhiwrite-export-include-keys").is(":checked") ? 1 : 0;
    var $ta = $("#zhiwrite-settings-json");
    var $copy = $("#zhiwrite-copy-settings");
    $("#zhiwrite-import-hint").text("");
    showToast("info", "正在导出配置…", 1500);
    $.ajax({
      url: ZhiWriteAI.ajaxUrl,
      method: "POST",
      dataType: "json",
      data: {
        action: "zhiwrite_ai_export_settings",
        nonce: ZhiWriteAI.nonce,
        include_keys: includeKeys,
      },
    })
      .done(function (res) {
        if (!res || !res.success) {
          var msg = (res && res.data && res.data.message) || "导出失败。";
          showToast("error", msg, 6000);
          return;
        }
        var json = (res.data && res.data.json) || "";
        if ($ta.length) $ta.val(json);
        if ($copy.length) $copy.prop("disabled", !json);
        showToast("success", "已导出。", 2000);
      })
      .fail(function (xhr) {
        var msg =
          (xhr && xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message) ||
          "导出失败。";
        showToast("error", msg, 6000);
      });
  });

  $(document).on("click", "#zhiwrite-copy-settings", function (e) {
    e.preventDefault();
    var $ta = $("#zhiwrite-settings-json");
    if (!$ta.length) return;
    var txt = String($ta.val() || "");
    if (!txt) return;
    function ok() {
      showToast("success", "已复制到剪贴板。", 1800);
    }
    function fail() {
      showToast("error", "复制失败，请手动全选复制。", 4000);
    }
    if (navigator && navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(txt).then(ok).catch(fail);
    } else {
      try {
        $ta[0].focus();
        $ta[0].select();
        var r = document.execCommand("copy");
        if (r) ok();
        else fail();
      } catch (err) {
        fail();
      }
    }
  });

  $(document).on("click", "#zhiwrite-import-settings", function (e) {
    e.preventDefault();
    var $ta = $("#zhiwrite-settings-json");
    var $hint = $("#zhiwrite-import-hint");
    if (!$ta.length) return;
    var txt = String($ta.val() || "").trim();
    if (!txt) {
      showToast("error", "请先粘贴要导入的 JSON。", 4000);
      return;
    }
    zhiwriteConfirm("导入会覆盖当前插件配置，确定继续吗？", function () {
      $hint.text("");
      showToast("info", "正在导入配置…", 2000);
      $.ajax({
        url: ZhiWriteAI.ajaxUrl,
        method: "POST",
        dataType: "json",
        data: {
          action: "zhiwrite_ai_import_settings",
          nonce: ZhiWriteAI.nonce,
          json: txt,
        },
      })
        .done(function (res) {
          if (!res || !res.success) {
            var msg = (res && res.data && res.data.message) || "导入失败。";
            showToast("error", msg, 7000);
            return;
          }
          showToast("success", (res.data && res.data.message) || "导入成功。", 2500);
          $hint.text("导入成功，页面即将刷新以加载新配置…");
          window.setTimeout(function () {
            window.location.reload();
          }, 800);
        })
        .fail(function (xhr) {
          var msg =
            (xhr &&
              xhr.responseJSON &&
              xhr.responseJSON.data &&
              xhr.responseJSON.data.message) ||
            "导入失败。";
          showToast("error", msg, 7000);
        });
    });
  });

  // Cache clear tool.
  $(document).on("click", "#zhiwrite-clear-cache", function (e) {
    e.preventDefault();
    var $btn = $(this);
    zhiwriteConfirm("确定要清理本插件生成缓存吗？", function () {
      $btn.prop("disabled", true);
      showToast("info", "正在清理缓存…", 1500);
      $.post(ZhiWriteAI.ajaxUrl, {
        action: "zhiwrite_ai_clear_cache",
        nonce: ZhiWriteAI.nonce,
      })
        .done(function (res) {
          if (!res || !res.success) {
            var msg = (res && res.data && res.data.message) || "清理失败。";
            showToast("error", msg, 6000);
            return;
          }
          showToast("success", (res.data && res.data.message) || "已清理。", 3500);
        })
        .fail(function (xhr) {
          var msg =
            (xhr && xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message) ||
            "清理失败。";
          showToast("error", msg, 6000);
        })
        .always(function () {
          $btn.prop("disabled", false);
        });
    });
  });

  // Diagnostics export (sanitized JSON).
  $(document).on("click", "#zhiwrite-export-diagnostics", function (e) {
    e.preventDefault();
    showToast("info", "正在导出诊断包（脱敏）…", 2000);
    $.ajax({
      url: ZhiWriteAI.ajaxUrl,
      method: "POST",
      dataType: "json",
      data: {
        action: "zhiwrite_ai_export_diagnostics",
        nonce: ZhiWriteAI.nonce,
      },
    })
      .done(function (res) {
        if (!res || !res.success || !res.data) {
          var msg = (res && res.data && res.data.message) || "导出失败。";
          showToast("error", msg, 6000);
          return;
        }
        downloadTextFile(res.data.filename, res.data.content, res.data.mime);
        showToast("success", "已导出诊断包。", 2200);
      })
      .fail(function (xhr) {
        var msg =
          (xhr && xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message) ||
          "导出失败。";
        showToast("error", msg, 6000);
      });
  });

  // Test email (budget notify).
  $(document).on("click", "#zhiwrite-test-email", function (e) {
    e.preventDefault();
    var $btn = $(this);
    if (!$btn.length) return;
    $btn.prop("disabled", true);
    var oldText = $btn.text();
    $btn.text("发送中…");
    showToast("info", "正在发送测试邮件…", 1500);
    $.ajax({
      url: ZhiWriteAI.ajaxUrl,
      method: "POST",
      dataType: "json",
      data: {
        action: "zhiwrite_ai_test_email",
        nonce: ZhiWriteAI.nonce,
      },
    })
      .done(function (res) {
        if (!res || !res.success) {
          var msg = (res && res.data && res.data.message) || "发送失败。";
          showToast("error", msg, 6000);
          return;
        }
        showToast("success", (res.data && res.data.message) || "已发送。", 4000);
      })
      .fail(function (xhr) {
        var msg =
          (xhr &&
            xhr.responseJSON &&
            xhr.responseJSON.data &&
            xhr.responseJSON.data.message) ||
          "发送失败。";
        showToast("error", msg, 6000);
      })
      .always(function () {
        $btn.prop("disabled", false);
        $btn.text(oldText || "发送测试邮件");
      });
  });

  // Post list: generate tags and save.
  $(document).on("click", ".zhiwrite-generate-tags", function (e) {
    e.preventDefault();
    var $a = $(this);
    var postId = parseInt($a.data("postId") || $a.data("post-id") || "0", 10) || 0;
    if (!postId) return;

    function findTagsCell(pid) {
      var $row = $("#post-" + String(pid));
      if (!$row.length) return { $row: $(), $cell: $() };
      var $cell = $row.find("td.tags, td.column-tags, td.taxonomy-post_tag").first();
      return { $row: $row, $cell: $cell };
    }

    var existing = findTagsCell(postId).$cell;
    var existingText = existing && existing.length ? String(existing.text() || "").trim() : "";
    var hasExistingTags =
      !!existingText && existingText !== "—" && existingText !== "-" && existingText !== "无";

    openGenerateTagsModal(
      postId,
      function (payload) {
      payload = payload || {};
      var oldText = $a.text();
      $a.addClass("is-disabled");
      $a.css({ pointerEvents: "none", opacity: 0.65 });
      $a.text(t("generatingTags", "生成中…"));
      showToast("info", "正在生成标签…", 1500);

      var realPostId = payload.postId || postId;
      var cellInfo = findTagsCell(realPostId);
      var $tagsCell = cellInfo.$cell;
      var oldCellHtml = "";
      if ($tagsCell && $tagsCell.length) {
        oldCellHtml = $tagsCell.html();
        $tagsCell.data("zhiwriteOldHtml", oldCellHtml);
        $tagsCell.html(
          '<span class="zhiwrite-ai-inline-spinner" aria-hidden="true"></span>' +
            '<span class="zhiwrite-ai-cell-muted">生成中…</span>'
        );
      }

      $.ajax({
        url: ZhiWriteAI.ajaxUrl,
        method: "POST",
        dataType: "json",
        data: {
          action: "zhiwrite_ai_generate_tags",
          nonce: ZhiWriteAI.nonce,
          post_id: realPostId,
          interface_id: payload.interfaceId || "",
          model: payload.model || "",
          tag_count: payload.tagCount || 10,
          apply_mode: payload.applyMode || "replace",
        },
      })
        .done(function (res) {
          if (!res || !res.success) {
            var msg = (res && res.data && res.data.message) || "生成失败。";
            var detail = res && res.data && res.data.detail ? String(res.data.detail) : "";
            showToast("error", detail ? msg + " " + detail : msg, 7000);
            $a.text(oldText || t("generateTags", "生成标签"));
            $a.removeClass("is-disabled");
            $a.css({ pointerEvents: "", opacity: "" });
            if ($tagsCell && $tagsCell.length) {
              var back = $tagsCell.data("zhiwriteOldHtml");
              $tagsCell.html(typeof back === "string" ? back : oldCellHtml);
              $tagsCell.removeData("zhiwriteOldHtml");
            }
            return;
          }
          var tags = (res.data && res.data.tags) || [];
          var tip = tags && tags.length ? "标签：" + tags.join("、") : "";
          showToast("success", (res.data && res.data.message) || "已生成并写入标签。", 3500);
          $a.text("已生成");
          if (tip) $a.attr("title", tip);
          if ($tagsCell && $tagsCell.length) {
            // Prefer server-rendered HTML to match WP list output (links, separators, etc).
            if (res.data && typeof res.data.tagsHtml === "string" && String(res.data.tagsHtml).trim()) {
              $tagsCell.html(String(res.data.tagsHtml));
            } else if (tags && tags.length) {
              $tagsCell.html(escHtml(tags.join("、")));
            } else {
              var back2 = $tagsCell.data("zhiwriteOldHtml");
              $tagsCell.html(typeof back2 === "string" ? back2 : "");
            }
            $tagsCell.removeData("zhiwriteOldHtml");
          }
        })
        .fail(function (xhr) {
          var msg =
            (xhr &&
              xhr.responseJSON &&
              xhr.responseJSON.data &&
              xhr.responseJSON.data.message) ||
            "生成失败。";
          showToast("error", msg, 7000);
          $a.text(oldText || t("generateTags", "生成标签"));
          $a.removeClass("is-disabled");
          $a.css({ pointerEvents: "", opacity: "" });
          if ($tagsCell && $tagsCell.length) {
            var back3 = $tagsCell.data("zhiwriteOldHtml");
            $tagsCell.html(typeof back3 === "string" ? back3 : oldCellHtml);
            $tagsCell.removeData("zhiwriteOldHtml");
          }
        });
      },
      { hasExistingTags: hasExistingTags }
    );
  });

  $(document).on("click", ".zhiwrite-ai-delete-log", function (e) {
    e.preventDefault();
    var $btn = $(this);
    var id = $btn.data("log-id");
    if (!id) return;

    zhiwriteConfirm("确定要删除这条生成记录吗？删除后将影响“用量统计/预算阈值/缓存命中统计”等汇总结果。", function () {
      $btn.prop("disabled", true);
      showToast("info", "正在删除…", 1200);
      $.post(ZhiWriteAI.ajaxUrl, {
        action: "zhiwrite_ai_delete_log",
        nonce: ZhiWriteAI.nonce,
        id: id,
      })
        .done(function (res) {
          if (res && res.success) {
            $btn.closest("tr").fadeOut(150, function () {
              $(this).remove();
            });
            showToast("success", "已删除。", 2200);
          } else {
            $btn.prop("disabled", false);
            var msg = (res && res.data && res.data.message) ? String(res.data.message) : "删除失败。";
            showToast("error", msg, 6000);
          }
        })
        .fail(function () {
          $btn.prop("disabled", false);
          showToast("error", "删除失败。", 6000);
        });
    });
  });

  function downloadTextFile(filename, content, mime) {
    try {
      var blob = new Blob([String(content || "")], { type: mime || "text/plain;charset=utf-8" });
      var url = window.URL.createObjectURL(blob);
      var a = document.createElement("a");
      a.href = url;
      a.download = filename || "download.txt";
      document.body.appendChild(a);
      a.click();
      window.setTimeout(function () {
        document.body.removeChild(a);
        window.URL.revokeObjectURL(url);
      }, 0);
    } catch (e) {
      // Fallback: copy to clipboard maybe, but keep it simple.
      showToast("error", "下载失败：浏览器不支持 Blob。", 6000);
    }
  }

  function collectLogFilters() {
    // Use ids defined in logs page.
    return {
      log_action: $("#zhiwrite_log_action").val() || "",
      model: $("#zhiwrite_log_model").val() || "",
      user_id: $("#zhiwrite_log_user").val() || "",
      from: $("#zhiwrite_log_from").val() || "",
      to: $("#zhiwrite_log_to").val() || "",
      q: $("#zhiwrite_log_q").val() || "",
    };
  }

  $(document).on("click", "#zhiwrite-export-logs-json, #zhiwrite-export-logs-csv", function (e) {
    e.preventDefault();
    var isCsv = $(this).attr("id") === "zhiwrite-export-logs-csv";
    var fmt = isCsv ? "csv" : "json";
    var filters = collectLogFilters();

    showToast("info", isCsv ? "正在导出 CSV…" : "正在导出 JSON…", 2000);
    $.post(
      ZhiWriteAI.ajaxUrl,
      $.extend(
        {
          action: "zhiwrite_ai_export_logs",
          nonce: ZhiWriteAI.nonce,
          format: fmt,
        },
        filters
      )
    )
      .done(function (res) {
        if (!res || !res.success || !res.data) {
          var msg = (res && res.data && res.data.message) || "导出失败。";
          showToast("error", msg, 6000);
          return;
        }
        downloadTextFile(res.data.filename, res.data.content, res.data.mime);
        showToast("success", "已导出。", 2200);
      })
      .fail(function (xhr) {
        var msg =
          (xhr && xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message) ||
          "导出失败。";
        showToast("error", msg, 6000);
      });
  });

  // 用量统计：导出 CSV
  $(document).on("click", "#zhiwrite-export-usage-csv", function (e) {
    e.preventDefault();
    var days = parseInt($("#zhiwrite_usage_days").val() || "30", 10) || 30;
    if (days < 1) days = 1;
    if (days > 365) days = 365;

    showToast("info", "正在导出用量 CSV…", 2000);
    $.post(ZhiWriteAI.ajaxUrl, {
      action: "zhiwrite_ai_export_usage",
      nonce: ZhiWriteAI.nonce,
      days: days,
    })
      .done(function (res) {
        if (!res || !res.success || !res.data) {
          var msg = (res && res.data && res.data.message) || "导出失败。";
          showToast("error", msg, 6000);
          return;
        }
        downloadTextFile(res.data.filename, res.data.content, res.data.mime);
        showToast("success", "已导出。", 2200);
      })
      .fail(function (xhr) {
        var msg =
          (xhr && xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message) ||
          "导出失败。";
        showToast("error", msg, 6000);
      });
  });

  // 队列管理：取消任务
  $(document).on("click", ".zhiwrite-ai-cancel-task", function (e) {
    e.preventDefault();
    var id = parseInt($(this).data("taskId"), 10) || 0;
    if (!id) return;

    zhiwriteConfirm("确定要停止该队列任务吗？", function () {
      $.post(ZhiWriteAI.ajaxUrl, {
        action: "zhiwrite_ai_cancel_task",
        nonce: ZhiWriteAI.nonce,
        id: id,
      })
        .done(function (res) {
          if (!res || !res.success) {
            var msg = (res && res.data && res.data.message) || "取消失败。";
            showToast("error", msg, 6000);
            return;
          }
          showToast("success", "任务已停止。", 2200);
        })
        .fail(function (xhr) {
          var msg =
            (xhr && xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message) ||
            "取消失败。";
          showToast("error", msg, 6000);
        });
    });
  });

  // 队列管理：删除任务
  $(document).on("click", ".zhiwrite-ai-delete-task", function (e) {
    e.preventDefault();
    var id = parseInt($(this).data("taskId"), 10) || 0;
    if (!id) return;

    zhiwriteConfirm("确定要删除该队列任务吗？", function () {
      $.post(ZhiWriteAI.ajaxUrl, {
        action: "zhiwrite_ai_delete_task",
        nonce: ZhiWriteAI.nonce,
        id: id,
      })
        .done(function (res) {
          if (!res || !res.success) {
            var msg = (res && res.data && res.data.message) || "删除失败。";
            showToast("error", msg, 6000);
            return;
          }
          showToast("success", "任务已删除。", 2000);
        })
        .fail(function (xhr) {
          var msg =
            (xhr && xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message) ||
            "删除失败。";
          showToast("error", msg, 6000);
        });
    });
  });

  // 队列管理：实时刷新任务进度
  function initQueueLiveRefresh() {
    var $tbody = $("#zhiwrite-queue-tbody");
    var $total = $("#zhiwrite-queue-total");
    if (!$tbody.length || !$total.length) return;

    function clipText(text, maxLen) {
      var s = String(text || "");
      if (s.length <= maxLen) return s;
      return s.slice(0, maxLen) + "…";
    }

    function statusLabel(s) {
      var map = {
        pending: "未执行",
        running: "正在执行",
        succeeded: "已完成",
        failed: "失败",
        cancelled: "已取消",
      };
      return map[s] || (s || "-");
    }

    function statusBadgeHtml(status, label) {
      var s = String(status || "");
      var cls = "zhiwrite-status zhiwrite-status--" + s.toLowerCase().replace(/[^a-z0-9_\-]/g, "");
      var text = label || statusLabel(s);
      return '<span class="' + escHtml(cls) + '">' + escHtml(text) + "</span>";
    }

    function renderRows(tasks) {
      var html = "";
      tasks = Array.isArray(tasks) ? tasks : [];
      if (!tasks.length) {
        html = '<tr><td colspan="9">暂无队列任务。</td></tr>';
        $tbody.html(html);
        return;
      }

      for (var i = 0; i < tasks.length; i++) {
        var t = tasks[i] || {};
        var canCancel = parseInt(t.can_cancel || 0, 10) === 1;
        var canDelete = parseInt(t.can_delete || 0, 10) === 1;
        html += "<tr>";
        html += "<td>" + escHtml(String(t.id || 0)) + "</td>";
        html += "<td>" + escHtml(t.created_at || "") + "</td>";
        html += "<td>" + escHtml(t.updated_at || "") + "</td>";
        html += "<td>" + escHtml(t.user || "-") + "</td>";
        html += "<td>" + statusBadgeHtml(t.status, t.status_label) + "</td>";
        html += "<td>" + escHtml(String(parseInt(t.progress || 0, 10))) + "%</td>";
        html += "<td>" + escHtml(clipText(t.message || "", 80)) + "</td>";
        html += "<td>" + escHtml(t.locked_until || "-") + "</td>";
        html += "<td>";
        if (canCancel) {
          html +=
            '<button class="button button-small zhiwrite-ai-cancel-task" data-task-id="' +
            escHtml(String(t.id || 0)) +
            '">停止</button>';
        }
        if (canDelete) {
          html +=
            '<button class="button button-small zhiwrite-ai-delete-task" style="margin-left:6px;" data-task-id="' +
            escHtml(String(t.id || 0)) +
            '">删除</button>';
        }
        if (!canCancel && !canDelete) html += "-";
        html += "</td>";
        html += "</tr>";
      }
      $tbody.html(html);
    }

    function refreshQueueOnce() {
      var st = $("#zhiwrite-queue-filter-status").val() || "";
      var uid = parseInt($("#zhiwrite-queue-filter-user").val() || "0", 10) || 0;
      var payload = {
        action: "zhiwrite_ai_queue_status",
        nonce: ZhiWriteAI.nonce,
      };
      if (st) payload.status = st;
      if (uid > 0) payload.user_id = uid;

      $.post(ZhiWriteAI.ajaxUrl, payload)
        .done(function (res) {
          if (!res || !res.success || !res.data) return;
          var d = res.data || {};
          var total = parseInt(d.total || 0, 10) || 0;
          $total.text("最近 50 条队列任务（共 " + total + " 条）");
          renderRows(d.tasks || []);
        })
        .fail(function () {
          // ignore transient refresh errors
        });
    }

    refreshQueueOnce();
    window.setInterval(refreshQueueOnce, 3000);
  }

  $(function () {
    initQueueLiveRefresh();
    initWebhookQueuePage();
    initWebhookLogsPage();
  });
})(jQuery);


