<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class ZhiWrite_AI_Writer_DB {
	const TABLE_LOGS = 'zhiwrite_ai_logs';
	const TABLE_TASKS = 'zhiwrite_ai_tasks';

	const TASK_STATUS_PENDING   = 'pending';
	const TASK_STATUS_RUNNING   = 'running';
	const TASK_STATUS_SUCCEEDED = 'succeeded';
	const TASK_STATUS_FAILED    = 'failed';
	const TASK_STATUS_CANCELLED = 'cancelled';

	/**
	 * Normalize a datetime filter value into MySQL datetime string (Y-m-d H:i:s).
	 *
	 * Accepts:
	 * - datetime-local: 2026-03-18T09:30 or 2026-03-18T09:30:00
	 * - mysql-ish: 2026-03-18 09:30 or 2026-03-18 09:30:00
	 *
	 * Returns empty string when invalid.
	 *
	 * @param string $raw
	 * @return string
	 */
	private static function normalize_mysql_datetime( $raw ) {
		$raw = is_string( $raw ) ? trim( $raw ) : '';
		if ( '' === $raw ) {
			return '';
		}

		// Convert datetime-local "T" separator to space.
		$raw = str_replace( 'T', ' ', $raw );

		// If no seconds are provided, append ":00".
		if ( preg_match( '/^\d{4}-\d{2}-\d{2}\s\d{2}:\d{2}$/', $raw ) ) {
			$raw .= ':00';
		}

		// Only accept exact "Y-m-d H:i:s".
		if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}\s\d{2}:\d{2}:\d{2}$/', $raw ) ) {
			return '';
		}

		$dt = \DateTime::createFromFormat( 'Y-m-d H:i:s', $raw );
		if ( ! $dt ) {
			return '';
		}

		$errors = \DateTime::getLastErrors();
		if ( is_array( $errors ) && ( ! empty( $errors['warning_count'] ) || ! empty( $errors['error_count'] ) ) ) {
			return '';
		}

		return $dt->format( 'Y-m-d H:i:s' );
	}

	public static function logs_table() {
		global $wpdb;
		return $wpdb->prefix . self::TABLE_LOGS;
	}

	public static function tasks_table() {
		global $wpdb;
		return $wpdb->prefix . self::TABLE_TASKS;
	}

	public static function maybe_create_tables() {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$table   = self::logs_table();
		$charset = $wpdb->get_charset_collate();

		$sql = "CREATE TABLE {$table} (
			id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
			user_id BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
			created_at DATETIME NOT NULL,
			updated_at DATETIME NOT NULL,
			action VARCHAR(50) NOT NULL DEFAULT '',
			model VARCHAR(191) NOT NULL DEFAULT '',
			api_base_url VARCHAR(255) NOT NULL DEFAULT '',
			elapsed_ms INT(11) UNSIGNED NOT NULL DEFAULT 0,
			prompt_tokens INT(11) UNSIGNED NOT NULL DEFAULT 0,
			completion_tokens INT(11) UNSIGNED NOT NULL DEFAULT 0,
			total_tokens INT(11) UNSIGNED NOT NULL DEFAULT 0,
			input_title TEXT NULL,
			input_prompt LONGTEXT NULL,
			output_text LONGTEXT NULL,
			post_id BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
			meta LONGTEXT NULL,
			PRIMARY KEY  (id),
			KEY user_id (user_id),
			KEY post_id (post_id),
			KEY created_at (created_at),
			KEY action (action),
			KEY api_base_url (api_base_url)
		) {$charset};";

		dbDelta( $sql );

		$tasks = self::tasks_table();
		$sql2  = "CREATE TABLE {$tasks} (
			id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
			request_id VARCHAR(80) NOT NULL,
			user_id BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
			created_at DATETIME NOT NULL,
			updated_at DATETIME NOT NULL,
			status VARCHAR(20) NOT NULL DEFAULT 'pending',
			progress TINYINT(3) UNSIGNED NOT NULL DEFAULT 0,
			message TEXT NULL,
			payload LONGTEXT NULL,
			result LONGTEXT NULL,
			post_id BIGINT(20) UNSIGNED NOT NULL DEFAULT 0,
			attempts TINYINT(3) UNSIGNED NOT NULL DEFAULT 0,
			locked_until DATETIME NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY request_id (request_id),
			KEY status (status),
			KEY user_id (user_id),
			KEY created_at (created_at)
		) {$charset};";

		dbDelta( $sql2 );
	}

	public static function insert_task( array $data ) {
		global $wpdb;

		$defaults = array(
			'request_id'   => '',
			'user_id'      => get_current_user_id(),
			'created_at'   => current_time( 'mysql' ),
			'updated_at'   => current_time( 'mysql' ),
			'status'       => self::TASK_STATUS_PENDING,
			'progress'     => 0,
			'message'      => '',
			'payload'      => null,
			'result'       => null,
			'post_id'      => 0,
			'attempts'     => 0,
			'locked_until' => null,
		);
		$row = wp_parse_args( $data, $defaults );
		if ( '' === (string) $row['request_id'] ) {
			return 0;
		}

		$wpdb->insert(
			self::tasks_table(),
			$row,
			array(
				'%s',
				'%d',
				'%s',
				'%s',
				'%s',
				'%d',
				'%s',
				'%s',
				'%s',
				'%d',
				'%d',
				'%s',
			)
		);
		return (int) $wpdb->insert_id;
	}

	public static function get_task_by_request_id( $request_id ) {
		global $wpdb;
		$request_id = (string) $request_id;
		if ( '' === $request_id ) {
			return null;
		}
		$table = self::tasks_table();
		$sql   = "SELECT * FROM {$table} WHERE request_id = %s LIMIT 1";
		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		$row = $wpdb->get_row( $wpdb->prepare( $sql, $request_id ), ARRAY_A );
		return is_array( $row ) ? $row : null;
	}

	public static function update_task( $id, array $data ) {
		global $wpdb;
		$id = (int) $id;
		if ( $id <= 0 ) {
			return false;
		}
		$data['updated_at'] = current_time( 'mysql' );
		return (bool) $wpdb->update( self::tasks_table(), $data, array( 'id' => $id ) );
	}

	/**
	 * Best-effort claim one pending task.
	 *
	 * @param int $lock_ttl_seconds
	 * @return array|null task row
	 */
	public static function claim_next_pending_task( $lock_ttl_seconds = 300 ) {
		global $wpdb;
		$ttl = max( 30, (int) $lock_ttl_seconds );

		$table = self::tasks_table();
		$now   = current_time( 'mysql' );
		// Find a pending task which is not locked (or lock expired).
		$sql = "SELECT * FROM {$table}
			WHERE status = %s AND (locked_until IS NULL OR locked_until < %s)
			ORDER BY id ASC
			LIMIT 1";
		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		$row = $wpdb->get_row( $wpdb->prepare( $sql, self::TASK_STATUS_PENDING, $now ), ARRAY_A );
		if ( ! is_array( $row ) || empty( $row['id'] ) ) {
			return null;
		}

		$id         = (int) $row['id'];
		$lock_until = gmdate( 'Y-m-d H:i:s', time() + $ttl );

		// Try to atomically claim it (status still pending + unlocked).
		$updated = $wpdb->query(
			$wpdb->prepare(
				"UPDATE {$table}
				 SET status = %s, locked_until = %s, updated_at = %s
				 WHERE id = %d AND status = %s AND (locked_until IS NULL OR locked_until < %s)",
				self::TASK_STATUS_RUNNING,
				$lock_until,
				current_time( 'mysql' ),
				$id,
				self::TASK_STATUS_PENDING,
				$now
			)
		);
		if ( 1 !== (int) $updated ) {
			return null;
		}

		$row['status']       = self::TASK_STATUS_RUNNING;
		$row['locked_until'] = $lock_until;
		return $row;
	}

	public static function insert_log( array $data ) {
		global $wpdb;

		$defaults = array(
			'user_id'      => get_current_user_id(),
			'created_at'   => current_time( 'mysql' ),
			'updated_at'   => current_time( 'mysql' ),
			'action'       => '',
			'model'        => '',
			'api_base_url' => '',
			'elapsed_ms'   => 0,
			'prompt_tokens' => 0,
			'completion_tokens' => 0,
			'total_tokens' => 0,
			'input_title'  => null,
			'input_prompt' => null,
			'output_text'  => null,
			'post_id'      => 0,
			'meta'         => null,
		);
		$row = wp_parse_args( $data, $defaults );

		$wpdb->insert(
			self::logs_table(),
			$row,
			array(
				'%d',
				'%s',
				'%s',
				'%s',
				'%s',
				'%s',
				'%d',
				'%d',
				'%d',
				'%d',
				'%s',
				'%s',
				'%s',
				'%d',
				'%s',
			)
		);

		return (int) $wpdb->insert_id;
	}

	public static function delete_log( $id ) {
		global $wpdb;
		return (bool) $wpdb->delete( self::logs_table(), array( 'id' => (int) $id ), array( '%d' ) );
	}

	/**
	 * Get logs list with optional filters.
	 *
	 * @param int   $limit
	 * @param int   $offset
	 * @param array $filters { action, model, user_id, post_id, q, from, to }
	 * @return array
	 */
	public static function get_logs( $limit = 50, $offset = 0, array $filters = array() ) {
		global $wpdb;
		$limit  = max( 1, min( 200, (int) $limit ) );
		$offset = max( 0, (int) $offset );
		$table  = self::logs_table();

		list( $where_sql, $params ) = self::build_logs_where( $filters );

		$sql = "SELECT * FROM {$table} {$where_sql} ORDER BY id DESC LIMIT %d OFFSET %d";
		$params[] = $limit;
		$params[] = $offset;

		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		return $wpdb->get_results( $wpdb->prepare( $sql, $params ), ARRAY_A );
	}

	/**
	 * Count logs for pagination/summary.
	 *
	 * @param array $filters
	 * @return int
	 */
	public static function count_logs( array $filters = array() ) {
		global $wpdb;
		$table = self::logs_table();
		list( $where_sql, $params ) = self::build_logs_where( $filters );
		$sql = "SELECT COUNT(*) FROM {$table} {$where_sql}";
		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		return (int) $wpdb->get_var( $wpdb->prepare( $sql, $params ) );
	}

	/**
	 * Internal: build WHERE SQL for log filtering.
	 *
	 * @param array $filters
	 * @return array [where_sql, params]
	 */
	private static function build_logs_where( array $filters ) {
		global $wpdb;
		$where  = array();
		$params = array();

		$action = isset( $filters['action'] ) ? (string) $filters['action'] : '';
		if ( '' !== $action ) {
			$where[]  = 'action = %s';
			$params[] = $action;
		}

		$model = isset( $filters['model'] ) ? (string) $filters['model'] : '';
		if ( '' !== $model ) {
			$where[]  = 'model = %s';
			$params[] = $model;
		}

		$user_id = isset( $filters['user_id'] ) ? (int) $filters['user_id'] : 0;
		if ( $user_id > 0 ) {
			$where[]  = 'user_id = %d';
			$params[] = $user_id;
		}

		$post_id = isset( $filters['post_id'] ) ? (int) $filters['post_id'] : 0;
		if ( $post_id > 0 ) {
			$where[]  = 'post_id = %d';
			$params[] = $post_id;
		}

		$from = isset( $filters['from'] ) ? self::normalize_mysql_datetime( (string) $filters['from'] ) : '';
		if ( '' !== $from ) {
			$where[]  = 'created_at >= %s';
			$params[] = $from;
		}

		$to = isset( $filters['to'] ) ? self::normalize_mysql_datetime( (string) $filters['to'] ) : '';
		if ( '' !== $to ) {
			$where[]  = 'created_at <= %s';
			$params[] = $to;
		}

		$q = isset( $filters['q'] ) ? (string) $filters['q'] : '';
		if ( '' !== $q ) {
			$like      = '%' . $wpdb->esc_like( $q ) . '%';
			$where[]   = '(input_title LIKE %s OR input_prompt LIKE %s OR output_text LIKE %s OR meta LIKE %s)';
			$params[]  = $like;
			$params[]  = $like;
			$params[]  = $like;
			$params[]  = $like;
		}

		if ( empty( $where ) ) {
			return array( '', array() );
		}

		return array( 'WHERE ' . implode( ' AND ', $where ), $params );
	}

	/**
	 * 获取任务队列列表（用于后台队列监控页）。
	 *
	 * @param int   $limit
	 * @param int   $offset
	 * @param array $filters { status, user_id }
	 * @return array
	 */
	public static function get_tasks( $limit = 50, $offset = 0, array $filters = array() ) {
		global $wpdb;
		$limit  = max( 1, min( 200, (int) $limit ) );
		$offset = max( 0, (int) $offset );
		$table  = self::tasks_table();

		list( $where_sql, $params ) = self::build_tasks_where( $filters );

		// Put active queue items on top: running -> pending -> others, then newest first.
		$sql       = "SELECT * FROM {$table} {$where_sql}
			ORDER BY
				CASE status
					WHEN 'running' THEN 0
					WHEN 'pending' THEN 1
					ELSE 2
				END ASC,
				updated_at DESC,
				id DESC
			LIMIT %d OFFSET %d";
		$params[]  = $limit;
		$params[]  = $offset;
		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		return $wpdb->get_results( $wpdb->prepare( $sql, $params ), ARRAY_A );
	}

	/**
	 * 统计任务数量（用于分页/摘要）。
	 *
	 * @param array $filters
	 * @return int
	 */
	public static function count_tasks( array $filters = array() ) {
		global $wpdb;
		$table = self::tasks_table();
		list( $where_sql, $params ) = self::build_tasks_where( $filters );
		$sql = "SELECT COUNT(*) FROM {$table} {$where_sql}";
		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		return (int) $wpdb->get_var( $wpdb->prepare( $sql, $params ) );
	}

	/**
	 * 内部方法：构建任务查询 WHERE 语句。
	 *
	 * @param array $filters
	 * @return array [where_sql, params]
	 */
	private static function build_tasks_where( array $filters ) {
		$where  = array();
		$params = array();

		$status = isset( $filters['status'] ) ? (string) $filters['status'] : '';
		if ( '' !== $status ) {
			$where[]  = 'status = %s';
			$params[] = $status;
		}

		$user_id = isset( $filters['user_id'] ) ? (int) $filters['user_id'] : 0;
		if ( $user_id > 0 ) {
			$where[]  = 'user_id = %d';
			$params[] = $user_id;
		}

		if ( empty( $where ) ) {
			return array( '', array() );
		}

		return array( 'WHERE ' . implode( ' AND ', $where ), $params );
	}

	/**
	 * 取消队列任务：将状态置为 cancelled，清理锁定时间。
	 *
	 * @param int $id
	 * @return bool
	 */
	public static function cancel_task( $id ) {
		$id = (int) $id;
		if ( $id <= 0 ) {
			return false;
		}

		return self::update_task(
			$id,
			array(
				'status'       => self::TASK_STATUS_CANCELLED,
				'progress'     => 0,
				'message'      => __( '已手动取消。', 'zhiwrite-ai-writer' ),
				'locked_until' => null,
			)
		);
	}

	/**
	 * Delete a task row by id.
	 *
	 * @param int $id
	 * @return bool
	 */
	public static function delete_task( $id ) {
		global $wpdb;
		$id = (int) $id;
		if ( $id <= 0 ) {
			return false;
		}
		return (bool) $wpdb->delete( self::tasks_table(), array( 'id' => $id ), array( '%d' ) );
	}
}


