<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class ZhiWrite_AI_Writer_Settings {
	const OPTION_KEY = 'zhiwrite_ai_writer_options';
	const SCHEMA_VERSION_OPTION_KEY = 'zhiwrite_ai_writer_schema_version';
	const SCHEMA_VERSION            = 1;

	const CONTENT_FORMAT_WP_HTML   = 'wp_html';
	const CONTENT_FORMAT_MARKDOWN  = 'markdown';
	const CAPABILITY_MANAGE_OPTIONS = 'manage_options';
	const CAPABILITY_EDIT_POSTS     = 'edit_posts';

	public static function defaults() {
		return array(
			// Legacy single-interface fields (kept for backward compatibility/migration).
			'api_base_url'          => '',
			'api_key'               => '',
			'model'                 => '',
			// New multi-interface settings.
			'interfaces'            => array(),
			'default_interface_id'  => '',
			'timeout'               => 60,
			// Retry strategy for transient failures (wp_remote_post errors / 429 / 5xx).
			'retry_times'           => 1,
			'retry_backoff_ms'      => 800,
			// Concurrency control (best-effort via transients).
			// Per-user max concurrent generation tasks (recommended: 1).
			'concurrency_user_max'  => 1,
			// Global max concurrent generation tasks (recommended: 2-5 depending on server).
			'concurrency_global_max'=> 3,
			// Lock TTL seconds to auto-release in case of fatal errors/timeouts.
			'concurrency_lock_ttl'  => 900,
			// Queue mode (WP-Cron) to avoid long-running admin-ajax requests.
			'enable_queue'          => 0,
			'enable_editors'        => 0,
			// Capability controls (fine-grained). Defaults are safe.
			'cap_generate'          => self::CAPABILITY_MANAGE_OPTIONS,
			'cap_logs'              => self::CAPABILITY_MANAGE_OPTIONS,
			// draft|publish|manual (manual = only show result first; operator decides save/publish)
			'default_post_status'   => 'draft',
			'content_format'        => self::CONTENT_FORMAT_WP_HTML,
			'system_context'        => '',
			'save_logs'             => 1,
			'keep_data_on_uninstall'=> 1,
			// Budget/usage guardrails (Phase 3.1).
			'budget_enabled'        => 0,
			'budget_daily_requests' => 0, // 0 = unlimited
			'budget_daily_tokens'   => 0, // 0 = unlimited (requires upstream usage)
			'budget_notify_email'   => 1,
			// Privacy & PII handling.
			'privacy_pii_mask'      => 0,
			// Outbound field blocking (Phase 3.2).
			'privacy_block_enabled' => 0,
			// One keyword per line; matched lines will be redacted before sending to model/logs.
			'privacy_block_keywords'=> '',
			// Email delivery (system wp_mail vs plugin SMTP).
			'mail_mode'             => 'system', // system|smtp
			'mail_from_email'       => '',
			'mail_from_name'        => '',
			'smtp_host'             => '',
			'smtp_port'             => 587,
			'smtp_encryption'       => 'tls', // none|ssl|tls
			'smtp_username'         => '',
			'smtp_password'         => '',
			'smtp_timeout_test'     => 10,
			'smtp_timeout_send'     => 15,
			// Content safety (Phase 3.3).
			'content_safety_enabled'=> 0,
			'sensitive_words'       => '',
			'sensitive_action'      => 'warn', // block|replace|warn
			'sensitive_replace_with'=> '***',
			// Content safety external checker (optional).
			'safety_external_enabled' => 0,
			'safety_external_url'     => '',
			'safety_external_timeout' => 8,
			// fail_open = 1: if external check fails, allow but warn. fail_open = 0: block.
			'safety_external_fail_open' => 1,
			// SEO rules (Phase 4).
			'seo_rules_enabled'      => 1,
			'seo_title_min'          => 12,
			'seo_title_max'          => 60,
			'seo_excerpt_min'        => 50,
			'seo_excerpt_max'        => 160,
			'seo_h2_min'             => 2,
			// Keyword density per 1000 chars (rough, language-agnostic).
			'seo_kw_per_1000_min'    => 1,
			'seo_kw_per_1000_max'    => 20,
			// Internal links (Phase 4).
			'internal_links_enabled' => 0,
			'internal_links_max'     => 3,
			'internal_links_position'=> 'after_h2_1', // after_h2_1|end
			'internal_links_strategy'=> 'keyword', // keyword|recent
			// Excerpt / lead (Phase 4).
			'auto_excerpt_enabled'   => 1,
			'auto_excerpt_len'       => 120,
			'lead_enabled'           => 0,
			'lead_prefix'            => '导语：',
			// Terms apply (Phase 4).
			'terms_apply_enabled'    => 1,
			'terms_auto_create'      => 0,
			'terms_require_confirm'  => 1,
			// TOC (Phase 4).
			'toc_enabled'            => 0,
			'toc_include_h3'         => 1,
			'toc_min_headings'       => 3,
			'toc_position'           => 'after_lead', // after_lead|after_h2_1|start
			// FAQ (Phase 4).
			'faq_enabled'            => 0,
			'faq_count'              => 5,
			'faq_position'           => 'end', // end|before_end
			// Pre-publish checklist (Phase 4).
			'precheck_enabled'       => 1,
			'precheck_block_publish' => 0,
			'precheck_require_excerpt' => 1,
			'precheck_require_image'   => 0,
			'precheck_external_links_max' => 10,
			// Cache (Phase 5).
			'cache_enabled'          => 0,
			'cache_ttl_minutes'      => 60,
			// If enabled, cache key includes model+interface+format+opts. Always includes prompts.
			'cache_scope'            => 'strict', // strict|loose
			// Failover / circuit breaker (Phase 5).
			'failover_enabled'       => 0,
			'failover_fail_threshold'=> 2,
			'failover_cooldown_sec'  => 300,
			// Model router (Phase 5).
			'model_router_enabled'   => 0,
			'model_router_long_threshold' => 2500, // prompt length
			'model_router_long_model' => '',
			'model_router_seo_model'  => '',
			// Webhook (Phase 5).
			'webhook_enabled'        => 0,
			'webhook_url'            => '',
			'webhook_secret'         => '',
			'webhook_timeout'        => 3,
			// Webhook retry queue (Phase 6.2).
			'webhook_retry_enabled'  => 0,
			'webhook_retry_max'      => 6,
			'webhook_retry_base_sec' => 10,
			'webhook_retry_max_sec'  => 1800,
			'webhook_retry_dead_ttl_days' => 7,
			// Fact-check (Phase 5, limited).
			'fact_check_enabled'     => 0,
			// Tag generation for post list (Phase 6.1).
			'tag_gen_interface_id'   => '',
			'tag_gen_model'          => '',
			'tag_gen_count'          => 10,
			'tag_gen_apply_mode'     => 'append', // append|replace
			// Prompt builder (Phase 6.4).
			'prompt_builder'         => array(
				'version'            => 1,
				'default_template_id'=> 'default',
				'default_style_id'   => 'default',
				'vars'               => array(
					'site_name' => '',
					'language'  => 'zh-CN',
				),
				'templates'          => array(
					array(
						'id'      => 'default',
						'name'    => __( '默认模板', 'zhiwrite-ai-writer' ),
						'content' => "你将为 WordPress 站点撰写一篇可直接发布的文章。\n\n要求：\n- 结构清晰，至少包含 2 个小标题（H2）。\n- 语言自然、准确，避免口水话。\n- 不要编造无法核实的数据；需要数据时请用“可验证要点”表达。\n",
					),
				),
				'styles'             => array(
					array(
						'id'      => 'default',
						'name'    => __( '默认风格', 'zhiwrite-ai-writer' ),
						'content' => "风格偏好：专业、简洁、面向中文读者。\n长度：中等偏长。\n格式：优先输出适合 WordPress 的 HTML 结构。\n",
					),
				),
			),
			'prompt_builder_revisions' => array(),
		);
	}

	public static function get_options() {
		$opts = get_option( self::OPTION_KEY, array() );
		if ( ! is_array( $opts ) ) {
			$opts = array();
		}
		$opts = wp_parse_args( $opts, self::defaults() );

		// Backward-compatible migration: old single interface -> interfaces[0].
		if ( ( empty( $opts['interfaces'] ) || ! is_array( $opts['interfaces'] ) ) && ( ! empty( $opts['api_base_url'] ) || ! empty( $opts['api_key'] ) || ! empty( $opts['model'] ) ) ) {
			$id                 = function_exists( 'wp_generate_uuid4' ) ? wp_generate_uuid4() : (string) time();
			$opts['interfaces'] = array(
				array(
					'id'           => $id,
					'name'         => __( '默认接口', 'zhiwrite-ai-writer' ),
					'api_base_url' => (string) $opts['api_base_url'],
					'api_key'      => (string) $opts['api_key'],
					'model'        => (string) $opts['model'],
				),
			);
			if ( empty( $opts['default_interface_id'] ) ) {
				$opts['default_interface_id'] = $id;
			}
		}

		// Normalize interfaces.
		if ( empty( $opts['interfaces'] ) || ! is_array( $opts['interfaces'] ) ) {
			$opts['interfaces'] = array();
		}

		return $opts;
	}

	public static function maybe_init_defaults() {
		if ( false === get_option( self::OPTION_KEY, false ) ) {
			add_option( self::OPTION_KEY, self::defaults(), '', false );
		}
		if ( false === get_option( self::SCHEMA_VERSION_OPTION_KEY, false ) ) {
			add_option( self::SCHEMA_VERSION_OPTION_KEY, self::SCHEMA_VERSION, '', false );
		}
	}

	/**
	 * Options schema migration entrypoint.
	 *
	 * This runs lightweight migrations and only ever "adds" new fields with defaults.
	 * It will NOT overwrite user's existing configuration.
	 *
	 * @return void
	 */
	public static function maybe_migrate() {
		$ver = (int) get_option( self::SCHEMA_VERSION_OPTION_KEY, 0 );
		if ( $ver >= self::SCHEMA_VERSION ) {
			return;
		}

		$opts = get_option( self::OPTION_KEY, array() );
		$opts = is_array( $opts ) ? $opts : array();

		// v1: introduce fine-grained caps and other new defaults.
		if ( $ver < 1 ) {
			$opts = wp_parse_args( $opts, self::defaults() );
			update_option( self::OPTION_KEY, $opts, false );
			$ver = 1;
		}

		update_option( self::SCHEMA_VERSION_OPTION_KEY, $ver, false );
	}

	public static function capability() {
		$opts = self::get_options();
		if ( ! empty( $opts['enable_editors'] ) ) {
			return 'edit_posts';
		}
		return 'manage_options';
	}

	/**
	 * Capability required to use the generator (menu + ajax).
	 *
	 * @return string
	 */
	public static function capability_generate() {
		$opts = self::get_options();
		$cap  = isset( $opts['cap_generate'] ) ? (string) $opts['cap_generate'] : self::CAPABILITY_MANAGE_OPTIONS;
		return in_array( $cap, array( self::CAPABILITY_MANAGE_OPTIONS, self::CAPABILITY_EDIT_POSTS ), true ) ? $cap : self::CAPABILITY_MANAGE_OPTIONS;
	}

	/**
	 * Capability required to view/export/delete logs.
	 *
	 * @return string
	 */
	public static function capability_logs() {
		$opts = self::get_options();
		$cap  = isset( $opts['cap_logs'] ) ? (string) $opts['cap_logs'] : self::CAPABILITY_MANAGE_OPTIONS;
		return in_array( $cap, array( self::CAPABILITY_MANAGE_OPTIONS, self::CAPABILITY_EDIT_POSTS ), true ) ? $cap : self::CAPABILITY_MANAGE_OPTIONS;
	}

	public static function register() {
		register_setting(
			'zhiwrite_ai_writer_settings',
			self::OPTION_KEY,
			array(
				'type'              => 'array',
				'sanitize_callback' => array( __CLASS__, 'sanitize' ),
				'default'           => self::defaults(),
			)
		);

		add_settings_section(
			'zhiwrite_ai_writer_stability',
			__( '稳定性与性能', 'zhiwrite-ai-writer' ),
			'__return_null',
			'zhiwrite-ai-writer'
		);

		self::add_field( 'timeout', __( '请求超时（秒）', 'zhiwrite-ai-writer' ), array( __CLASS__, 'field_timeout' ), 'zhiwrite_ai_writer_stability' );
		self::add_field( 'retry_times', __( '失败重试次数', 'zhiwrite-ai-writer' ), array( __CLASS__, 'field_retry_times' ), 'zhiwrite_ai_writer_stability' );
		self::add_field( 'retry_backoff_ms', __( '重试退避（毫秒）', 'zhiwrite-ai-writer' ), array( __CLASS__, 'field_retry_backoff_ms' ), 'zhiwrite_ai_writer_stability' );
		self::add_field( 'concurrency_user_max', __( '同一用户并发上限', 'zhiwrite-ai-writer' ), array( __CLASS__, 'field_concurrency_user_max' ), 'zhiwrite_ai_writer_stability' );
		self::add_field( 'concurrency_global_max', __( '全局并发上限', 'zhiwrite-ai-writer' ), array( __CLASS__, 'field_concurrency_global_max' ), 'zhiwrite_ai_writer_stability' );
		self::add_field( 'concurrency_lock_ttl', __( '并发锁超时（秒）', 'zhiwrite-ai-writer' ), array( __CLASS__, 'field_concurrency_lock_ttl' ), 'zhiwrite_ai_writer_stability' );
		self::add_field( 'enable_queue', __( '后台队列（WP-Cron）', 'zhiwrite-ai-writer' ), array( __CLASS__, 'field_enable_queue' ), 'zhiwrite_ai_writer_stability' );

		add_settings_section(
			'zhiwrite_ai_writer_generation',
			__( '生成与内容', 'zhiwrite-ai-writer' ),
			'__return_null',
			'zhiwrite-ai-writer'
		);
		self::add_field( 'content_format', __( '文章格式', 'zhiwrite-ai-writer' ), array( __CLASS__, 'field_content_format' ), 'zhiwrite_ai_writer_generation' );
		self::add_field( 'system_context', __( '系统信息/业务背景（用于提示词）', 'zhiwrite-ai-writer' ), array( __CLASS__, 'field_system_context' ), 'zhiwrite_ai_writer_generation' );

		add_settings_section(
			'zhiwrite_ai_writer_publishing',
			__( '发布与权限', 'zhiwrite-ai-writer' ),
			'__return_null',
			'zhiwrite-ai-writer'
		);
		self::add_field( 'enable_editors', __( '允许编辑使用', 'zhiwrite-ai-writer' ), array( __CLASS__, 'field_enable_editors' ), 'zhiwrite_ai_writer_publishing' );
		self::add_field( 'cap_generate', __( '生成权限（Capability）', 'zhiwrite-ai-writer' ), array( __CLASS__, 'field_cap_generate' ), 'zhiwrite_ai_writer_publishing' );
		self::add_field( 'cap_logs', __( '日志权限（Capability）', 'zhiwrite-ai-writer' ), array( __CLASS__, 'field_cap_logs' ), 'zhiwrite_ai_writer_publishing' );
		self::add_field( 'default_post_status', __( '默认发布策略', 'zhiwrite-ai-writer' ), array( __CLASS__, 'field_default_post_status' ), 'zhiwrite_ai_writer_publishing' );

		add_settings_section(
			'zhiwrite_ai_writer_data',
			__( '日志与数据', 'zhiwrite-ai-writer' ),
			'__return_null',
			'zhiwrite-ai-writer'
		);
		self::add_field( 'save_logs', __( '保存生成记录', 'zhiwrite-ai-writer' ), array( __CLASS__, 'field_save_logs' ), 'zhiwrite_ai_writer_data' );
		self::add_field( 'keep_data_on_uninstall', __( '卸载时保留数据', 'zhiwrite-ai-writer' ), array( __CLASS__, 'field_keep_data_on_uninstall' ), 'zhiwrite_ai_writer_data' );

		add_settings_section(
			'zhiwrite_ai_writer_budget',
			__( '用量与预算', 'zhiwrite-ai-writer' ),
			'__return_null',
			'zhiwrite-ai-writer'
		);
		self::add_field( 'budget_enabled', __( '预算阈值', 'zhiwrite-ai-writer' ), array( __CLASS__, 'field_budget_enabled' ), 'zhiwrite_ai_writer_budget' );
		self::add_field( 'budget_daily_requests', __( '每日请求上限', 'zhiwrite-ai-writer' ), array( __CLASS__, 'field_budget_daily_requests' ), 'zhiwrite_ai_writer_budget' );
		self::add_field( 'budget_daily_tokens', __( '每日 tokens 上限', 'zhiwrite-ai-writer' ), array( __CLASS__, 'field_budget_daily_tokens' ), 'zhiwrite_ai_writer_budget' );
		self::add_field( 'budget_notify_email', __( '邮件通知', 'zhiwrite-ai-writer' ), array( __CLASS__, 'field_budget_notify_email' ), 'zhiwrite_ai_writer_budget' );

		add_settings_section(
			'zhiwrite_ai_writer_privacy',
			__( '隐私与脱敏', 'zhiwrite-ai-writer' ),
			'__return_null',
			'zhiwrite-ai-writer'
		);
		self::add_field( 'privacy_pii_mask', __( 'PII 脱敏后再发模型', 'zhiwrite-ai-writer' ), array( __CLASS__, 'field_privacy_pii_mask' ), 'zhiwrite_ai_writer_privacy' );
		self::add_field( 'privacy_block_enabled', __( '禁用外发字段', 'zhiwrite-ai-writer' ), array( __CLASS__, 'field_privacy_block_enabled' ), 'zhiwrite_ai_writer_privacy' );
		self::add_field( 'privacy_block_keywords', __( '禁用字段关键字（每行一个）', 'zhiwrite-ai-writer' ), array( __CLASS__, 'field_privacy_block_keywords' ), 'zhiwrite_ai_writer_privacy' );

		add_settings_section(
			'zhiwrite_ai_writer_interfaces',
			__( '接口设置', 'zhiwrite-ai-writer' ),
			'__return_null',
			'zhiwrite-ai-writer'
		);

		self::add_field( 'interfaces', __( '已添加的接口', 'zhiwrite-ai-writer' ), array( __CLASS__, 'field_interfaces' ), 'zhiwrite_ai_writer_interfaces' );

		add_settings_section(
			'zhiwrite_ai_writer_email',
			__( 'SMTP 邮件配置', 'zhiwrite-ai-writer' ),
			'__return_null',
			'zhiwrite-ai-writer'
		);
		self::add_field( 'mail_mode', __( '邮件发送方式', 'zhiwrite-ai-writer' ), array( __CLASS__, 'field_mail_mode' ), 'zhiwrite_ai_writer_email' );
		self::add_field( 'mail_from_email', __( '发件人邮箱（可选）', 'zhiwrite-ai-writer' ), array( __CLASS__, 'field_mail_from_email' ), 'zhiwrite_ai_writer_email' );
		self::add_field( 'mail_from_name', __( '发件人名称（可选）', 'zhiwrite-ai-writer' ), array( __CLASS__, 'field_mail_from_name' ), 'zhiwrite_ai_writer_email' );
		self::add_field( 'smtp_host', __( 'SMTP 主机', 'zhiwrite-ai-writer' ), array( __CLASS__, 'field_smtp_host' ), 'zhiwrite_ai_writer_email' );
		self::add_field( 'smtp_port', __( 'SMTP 端口', 'zhiwrite-ai-writer' ), array( __CLASS__, 'field_smtp_port' ), 'zhiwrite_ai_writer_email' );
		self::add_field( 'smtp_encryption', __( '加密方式', 'zhiwrite-ai-writer' ), array( __CLASS__, 'field_smtp_encryption' ), 'zhiwrite_ai_writer_email' );
		self::add_field( 'smtp_username', __( 'SMTP 用户名', 'zhiwrite-ai-writer' ), array( __CLASS__, 'field_smtp_username' ), 'zhiwrite_ai_writer_email' );
		self::add_field( 'smtp_password', __( 'SMTP 密码', 'zhiwrite-ai-writer' ), array( __CLASS__, 'field_smtp_password' ), 'zhiwrite_ai_writer_email' );
		self::add_field( 'smtp_timeout_test', __( '测试邮件超时（秒）', 'zhiwrite-ai-writer' ), array( __CLASS__, 'field_smtp_timeout_test' ), 'zhiwrite_ai_writer_email' );
		self::add_field( 'smtp_timeout_send', __( '正式邮件超时（秒）', 'zhiwrite-ai-writer' ), array( __CLASS__, 'field_smtp_timeout_send' ), 'zhiwrite_ai_writer_email' );

		add_settings_section(
			'zhiwrite_ai_writer_safety',
			__( '内容安全', 'zhiwrite-ai-writer' ),
			'__return_null',
			'zhiwrite-ai-writer'
		);
		self::add_field( 'content_safety_enabled', __( '启用内容安全', 'zhiwrite-ai-writer' ), array( __CLASS__, 'field_content_safety_enabled' ), 'zhiwrite_ai_writer_safety' );
		self::add_field( 'sensitive_action', __( '命中策略', 'zhiwrite-ai-writer' ), array( __CLASS__, 'field_sensitive_action' ), 'zhiwrite_ai_writer_safety' );
		self::add_field( 'sensitive_replace_with', __( '替换为（仅替换策略）', 'zhiwrite-ai-writer' ), array( __CLASS__, 'field_sensitive_replace_with' ), 'zhiwrite_ai_writer_safety' );
		self::add_field( 'sensitive_words', __( '敏感词库（每行一个）', 'zhiwrite-ai-writer' ), array( __CLASS__, 'field_sensitive_words' ), 'zhiwrite_ai_writer_safety' );
		self::add_field( 'safety_external_enabled', __( '外部内容安全检测（可选）', 'zhiwrite-ai-writer' ), array( __CLASS__, 'field_safety_external_enabled' ), 'zhiwrite_ai_writer_safety' );
		self::add_field( 'safety_external_url', __( '外部检测接口地址', 'zhiwrite-ai-writer' ), array( __CLASS__, 'field_safety_external_url' ), 'zhiwrite_ai_writer_safety' );
		self::add_field( 'safety_external_timeout', __( '外部检测超时（秒）', 'zhiwrite-ai-writer' ), array( __CLASS__, 'field_safety_external_timeout' ), 'zhiwrite_ai_writer_safety' );
		self::add_field( 'safety_external_fail_open', __( '外部检测失败降级', 'zhiwrite-ai-writer' ), array( __CLASS__, 'field_safety_external_fail_open' ), 'zhiwrite_ai_writer_safety' );

		add_settings_section(
			'zhiwrite_ai_writer_seo_rules',
			__( 'SEO 规则', 'zhiwrite-ai-writer' ),
			'__return_null',
			'zhiwrite-ai-writer'
		);
		self::add_field( 'seo_rules_enabled', __( '启用 SEO 提示', 'zhiwrite-ai-writer' ), array( __CLASS__, 'field_seo_rules_enabled' ), 'zhiwrite_ai_writer_seo_rules' );
		self::add_field( 'seo_title_min', __( '标题长度（最小）', 'zhiwrite-ai-writer' ), array( __CLASS__, 'field_seo_title_min' ), 'zhiwrite_ai_writer_seo_rules' );
		self::add_field( 'seo_title_max', __( '标题长度（最大）', 'zhiwrite-ai-writer' ), array( __CLASS__, 'field_seo_title_max' ), 'zhiwrite_ai_writer_seo_rules' );
		self::add_field( 'seo_excerpt_min', __( 'Meta 描述/摘要长度（最小）', 'zhiwrite-ai-writer' ), array( __CLASS__, 'field_seo_excerpt_min' ), 'zhiwrite_ai_writer_seo_rules' );
		self::add_field( 'seo_excerpt_max', __( 'Meta 描述/摘要长度（最大）', 'zhiwrite-ai-writer' ), array( __CLASS__, 'field_seo_excerpt_max' ), 'zhiwrite_ai_writer_seo_rules' );
		self::add_field( 'seo_h2_min', __( 'H2 最少数量', 'zhiwrite-ai-writer' ), array( __CLASS__, 'field_seo_h2_min' ), 'zhiwrite_ai_writer_seo_rules' );
		self::add_field( 'seo_kw_per_1000_min', __( '焦点关键词密度（每 1000 字符最少）', 'zhiwrite-ai-writer' ), array( __CLASS__, 'field_seo_kw_per_1000_min' ), 'zhiwrite_ai_writer_seo_rules' );
		self::add_field( 'seo_kw_per_1000_max', __( '焦点关键词密度（每 1000 字符最多）', 'zhiwrite-ai-writer' ), array( __CLASS__, 'field_seo_kw_per_1000_max' ), 'zhiwrite_ai_writer_seo_rules' );

		add_settings_section(
			'zhiwrite_ai_writer_internal_links',
			__( '内部链接策略', 'zhiwrite-ai-writer' ),
			'__return_null',
			'zhiwrite-ai-writer'
		);
		self::add_field( 'internal_links_enabled', __( '启用内部链接', 'zhiwrite-ai-writer' ), array( __CLASS__, 'field_internal_links_enabled' ), 'zhiwrite_ai_writer_internal_links' );
		self::add_field( 'internal_links_max', __( '最多插入数量', 'zhiwrite-ai-writer' ), array( __CLASS__, 'field_internal_links_max' ), 'zhiwrite_ai_writer_internal_links' );
		self::add_field( 'internal_links_position', __( '插入位置', 'zhiwrite-ai-writer' ), array( __CLASS__, 'field_internal_links_position' ), 'zhiwrite_ai_writer_internal_links' );
		self::add_field( 'internal_links_strategy', __( '推荐策略', 'zhiwrite-ai-writer' ), array( __CLASS__, 'field_internal_links_strategy' ), 'zhiwrite_ai_writer_internal_links' );

		add_settings_section(
			'zhiwrite_ai_writer_lead',
			__( '自动摘要/导语', 'zhiwrite-ai-writer' ),
			'__return_null',
			'zhiwrite-ai-writer'
		);
		self::add_field( 'auto_excerpt_enabled', __( '自动摘要', 'zhiwrite-ai-writer' ), array( __CLASS__, 'field_auto_excerpt_enabled' ), 'zhiwrite_ai_writer_lead' );
		self::add_field( 'auto_excerpt_len', __( '摘要长度（字符）', 'zhiwrite-ai-writer' ), array( __CLASS__, 'field_auto_excerpt_len' ), 'zhiwrite_ai_writer_lead' );
		self::add_field( 'lead_enabled', __( '自动导语写入正文开头', 'zhiwrite-ai-writer' ), array( __CLASS__, 'field_lead_enabled' ), 'zhiwrite_ai_writer_lead' );
		self::add_field( 'lead_prefix', __( '导语前缀（可选）', 'zhiwrite-ai-writer' ), array( __CLASS__, 'field_lead_prefix' ), 'zhiwrite_ai_writer_lead' );

		add_settings_section(
			'zhiwrite_ai_writer_terms',
			__( '分类/标签写入', 'zhiwrite-ai-writer' ),
			'__return_null',
			'zhiwrite-ai-writer'
		);
		self::add_field( 'terms_apply_enabled', __( '自动写入分类/标签', 'zhiwrite-ai-writer' ), array( __CLASS__, 'field_terms_apply_enabled' ), 'zhiwrite_ai_writer_terms' );
		self::add_field( 'terms_auto_create', __( '自动创建不存在的分类/标签（谨慎）', 'zhiwrite-ai-writer' ), array( __CLASS__, 'field_terms_auto_create' ), 'zhiwrite_ai_writer_terms' );
		self::add_field( 'terms_require_confirm', __( '保存前需人工确认（默认）', 'zhiwrite-ai-writer' ), array( __CLASS__, 'field_terms_require_confirm' ), 'zhiwrite_ai_writer_terms' );

		add_settings_section(
			'zhiwrite_ai_writer_tag_gen',
			__( '标签生成（文章列表）', 'zhiwrite-ai-writer' ),
			'__return_null',
			'zhiwrite-ai-writer'
		);
		self::add_field( 'tag_gen_interface_id', __( '默认接口', 'zhiwrite-ai-writer' ), array( __CLASS__, 'field_tag_gen_interface_id' ), 'zhiwrite_ai_writer_tag_gen' );
		self::add_field( 'tag_gen_model', __( '默认模型（可选）', 'zhiwrite-ai-writer' ), array( __CLASS__, 'field_tag_gen_model' ), 'zhiwrite_ai_writer_tag_gen' );
		self::add_field( 'tag_gen_count', __( '默认标签数量', 'zhiwrite-ai-writer' ), array( __CLASS__, 'field_tag_gen_count' ), 'zhiwrite_ai_writer_tag_gen' );
		self::add_field( 'tag_gen_apply_mode', __( '默认写入方式', 'zhiwrite-ai-writer' ), array( __CLASS__, 'field_tag_gen_apply_mode' ), 'zhiwrite_ai_writer_tag_gen' );

		add_settings_section(
			'zhiwrite_ai_writer_toc',
			__( '自动目录（TOC）', 'zhiwrite-ai-writer' ),
			'__return_null',
			'zhiwrite-ai-writer'
		);
		self::add_field( 'toc_enabled', __( '启用自动目录', 'zhiwrite-ai-writer' ), array( __CLASS__, 'field_toc_enabled' ), 'zhiwrite_ai_writer_toc' );
		self::add_field( 'toc_include_h3', __( '包含 H3', 'zhiwrite-ai-writer' ), array( __CLASS__, 'field_toc_include_h3' ), 'zhiwrite_ai_writer_toc' );
		self::add_field( 'toc_min_headings', __( '最少标题数才插入', 'zhiwrite-ai-writer' ), array( __CLASS__, 'field_toc_min_headings' ), 'zhiwrite_ai_writer_toc' );
		self::add_field( 'toc_position', __( '插入位置', 'zhiwrite-ai-writer' ), array( __CLASS__, 'field_toc_position' ), 'zhiwrite_ai_writer_toc' );

		add_settings_section(
			'zhiwrite_ai_writer_faq',
			__( '自动 FAQ', 'zhiwrite-ai-writer' ),
			'__return_null',
			'zhiwrite-ai-writer'
		);
		self::add_field( 'faq_enabled', __( '启用自动 FAQ', 'zhiwrite-ai-writer' ), array( __CLASS__, 'field_faq_enabled' ), 'zhiwrite_ai_writer_faq' );
		self::add_field( 'faq_count', __( 'FAQ 条数', 'zhiwrite-ai-writer' ), array( __CLASS__, 'field_faq_count' ), 'zhiwrite_ai_writer_faq' );
		self::add_field( 'faq_position', __( 'FAQ 位置', 'zhiwrite-ai-writer' ), array( __CLASS__, 'field_faq_position' ), 'zhiwrite_ai_writer_faq' );

		add_settings_section(
			'zhiwrite_ai_writer_precheck',
			__( '发布前校验清单', 'zhiwrite-ai-writer' ),
			'__return_null',
			'zhiwrite-ai-writer'
		);
		self::add_field( 'precheck_enabled', __( '启用校验清单', 'zhiwrite-ai-writer' ), array( __CLASS__, 'field_precheck_enabled' ), 'zhiwrite_ai_writer_precheck' );
		self::add_field( 'precheck_block_publish', __( '发布时强制拦截（谨慎）', 'zhiwrite-ai-writer' ), array( __CLASS__, 'field_precheck_block_publish' ), 'zhiwrite_ai_writer_precheck' );
		self::add_field( 'precheck_require_excerpt', __( '必须有摘要', 'zhiwrite-ai-writer' ), array( __CLASS__, 'field_precheck_require_excerpt' ), 'zhiwrite_ai_writer_precheck' );
		self::add_field( 'precheck_require_image', __( '必须包含图片', 'zhiwrite-ai-writer' ), array( __CLASS__, 'field_precheck_require_image' ), 'zhiwrite_ai_writer_precheck' );
		self::add_field( 'precheck_external_links_max', __( '外链数量上限', 'zhiwrite-ai-writer' ), array( __CLASS__, 'field_precheck_external_links_max' ), 'zhiwrite_ai_writer_precheck' );

		add_settings_section(
			'zhiwrite_ai_writer_cache',
			__( '缓存策略', 'zhiwrite-ai-writer' ),
			'__return_null',
			'zhiwrite-ai-writer'
		);
		self::add_field( 'cache_enabled', __( '启用缓存', 'zhiwrite-ai-writer' ), array( __CLASS__, 'field_cache_enabled' ), 'zhiwrite_ai_writer_cache' );
		self::add_field( 'cache_ttl_minutes', __( '缓存有效期（分钟）', 'zhiwrite-ai-writer' ), array( __CLASS__, 'field_cache_ttl_minutes' ), 'zhiwrite_ai_writer_cache' );
		self::add_field( 'cache_scope', __( '缓存范围', 'zhiwrite-ai-writer' ), array( __CLASS__, 'field_cache_scope' ), 'zhiwrite_ai_writer_cache' );
		self::add_field( 'cache_clear', __( '缓存清理工具', 'zhiwrite-ai-writer' ), array( __CLASS__, 'field_cache_clear' ), 'zhiwrite_ai_writer_cache' );

		add_settings_section(
			'zhiwrite_ai_writer_failover',
			__( '主备接口切换', 'zhiwrite-ai-writer' ),
			'__return_null',
			'zhiwrite-ai-writer'
		);
		self::add_field( 'failover_enabled', __( '启用失败自动切换', 'zhiwrite-ai-writer' ), array( __CLASS__, 'field_failover_enabled' ), 'zhiwrite_ai_writer_failover' );
		self::add_field( 'failover_fail_threshold', __( '熔断失败阈值', 'zhiwrite-ai-writer' ), array( __CLASS__, 'field_failover_fail_threshold' ), 'zhiwrite_ai_writer_failover' );
		self::add_field( 'failover_cooldown_sec', __( '熔断冷却时间（秒）', 'zhiwrite-ai-writer' ), array( __CLASS__, 'field_failover_cooldown_sec' ), 'zhiwrite_ai_writer_failover' );

		add_settings_section(
			'zhiwrite_ai_writer_model_router',
			__( '模型路由规则', 'zhiwrite-ai-writer' ),
			'__return_null',
			'zhiwrite-ai-writer'
		);
		self::add_field( 'model_router_enabled', __( '启用模型路由', 'zhiwrite-ai-writer' ), array( __CLASS__, 'field_model_router_enabled' ), 'zhiwrite_ai_writer_model_router' );
		self::add_field( 'model_router_long_threshold', __( '长需求阈值（字符）', 'zhiwrite-ai-writer' ), array( __CLASS__, 'field_model_router_long_threshold' ), 'zhiwrite_ai_writer_model_router' );
		self::add_field( 'model_router_long_model', __( '长需求模型（可选）', 'zhiwrite-ai-writer' ), array( __CLASS__, 'field_model_router_long_model' ), 'zhiwrite_ai_writer_model_router' );
		self::add_field( 'model_router_seo_model', __( 'SEO/结构化任务模型（可选）', 'zhiwrite-ai-writer' ), array( __CLASS__, 'field_model_router_seo_model' ), 'zhiwrite_ai_writer_model_router' );

		add_settings_section(
			'zhiwrite_ai_writer_webhook',
			__( 'Webhook 回调', 'zhiwrite-ai-writer' ),
			'__return_null',
			'zhiwrite-ai-writer'
		);
		self::add_field( 'webhook_enabled', __( '启用 Webhook', 'zhiwrite-ai-writer' ), array( __CLASS__, 'field_webhook_enabled' ), 'zhiwrite_ai_writer_webhook' );
		self::add_field( 'webhook_url', __( 'Webhook URL', 'zhiwrite-ai-writer' ), array( __CLASS__, 'field_webhook_url' ), 'zhiwrite_ai_writer_webhook' );
		self::add_field( 'webhook_secret', __( '签名密钥（可选）', 'zhiwrite-ai-writer' ), array( __CLASS__, 'field_webhook_secret' ), 'zhiwrite_ai_writer_webhook' );
		self::add_field( 'webhook_timeout', __( '回调超时（秒）', 'zhiwrite-ai-writer' ), array( __CLASS__, 'field_webhook_timeout' ), 'zhiwrite_ai_writer_webhook' );
		self::add_field( 'webhook_retry_enabled', __( '失败进入队列重试', 'zhiwrite-ai-writer' ), array( __CLASS__, 'field_webhook_retry_enabled' ), 'zhiwrite_ai_writer_webhook' );
		self::add_field( 'webhook_retry_max', __( '最大重试次数', 'zhiwrite-ai-writer' ), array( __CLASS__, 'field_webhook_retry_max' ), 'zhiwrite_ai_writer_webhook' );
		self::add_field( 'webhook_retry_base_sec', __( '重试基准延迟（秒）', 'zhiwrite-ai-writer' ), array( __CLASS__, 'field_webhook_retry_base_sec' ), 'zhiwrite_ai_writer_webhook' );
		self::add_field( 'webhook_retry_max_sec', __( '最大延迟上限（秒）', 'zhiwrite-ai-writer' ), array( __CLASS__, 'field_webhook_retry_max_sec' ), 'zhiwrite_ai_writer_webhook' );
		self::add_field( 'webhook_retry_dead_ttl_days', __( '死信保留天数', 'zhiwrite-ai-writer' ), array( __CLASS__, 'field_webhook_retry_dead_ttl_days' ), 'zhiwrite_ai_writer_webhook' );

		add_settings_section(
			'zhiwrite_ai_writer_prompt_builder',
			__( '提示词构建器', 'zhiwrite-ai-writer' ),
			'__return_null',
			'zhiwrite-ai-writer'
		);
		self::add_field( 'prompt_builder', __( '模板 / 变量 / 风格预设（JSON）', 'zhiwrite-ai-writer' ), array( __CLASS__, 'field_prompt_builder' ), 'zhiwrite_ai_writer_prompt_builder' );

		add_settings_section(
			'zhiwrite_ai_writer_fact_check',
			__( '事实核查（有限）', 'zhiwrite-ai-writer' ),
			'__return_null',
			'zhiwrite-ai-writer'
		);
		self::add_field( 'fact_check_enabled', __( '启用事实核查模式', 'zhiwrite-ai-writer' ), array( __CLASS__, 'field_fact_check_enabled' ), 'zhiwrite_ai_writer_fact_check' );
	}

	private static function add_field( $key, $label, $render_cb, $section_id = 'zhiwrite_ai_writer_general' ) {
		add_settings_field(
			'field_' . $key,
			$label,
			$render_cb,
			'zhiwrite-ai-writer',
			$section_id,
			array( 'key' => $key )
		);
	}

	public static function sanitize( $input ) {
		$defaults = self::defaults();
		$input    = is_array( $input ) ? $input : array();
		$existing = get_option( self::OPTION_KEY, array() );
		$existing = is_array( $existing ) ? wp_parse_args( $existing, self::defaults() ) : self::defaults();
		$existing_interfaces = isset( $existing['interfaces'] ) && is_array( $existing['interfaces'] ) ? $existing['interfaces'] : array();

		// Important: settings page is tabbed and only submits fields of current tab.
		// Therefore, we must merge updates into existing options, NOT reset missing fields to defaults.
		$out = $existing;
		if ( ! is_array( $out ) ) {
			$out = $defaults;
		}
		$out = wp_parse_args( $out, $defaults );

		// Keep legacy fields (not used in generation anymore, but keep for safety).
		if ( array_key_exists( 'api_base_url', $input ) ) {
			$out['api_base_url'] = esc_url_raw( trim( (string) $input['api_base_url'] ) );
		}
		if ( array_key_exists( 'api_key', $input ) ) {
			$out['api_key'] = sanitize_text_field( (string) $input['api_key'] );
		}
		if ( array_key_exists( 'model', $input ) ) {
			$out['model'] = sanitize_text_field( (string) $input['model'] );
		}

		// Interfaces list.
		if ( array_key_exists( 'interfaces', $input ) ) {
			$interfaces_in = isset( $input['interfaces'] ) && is_array( $input['interfaces'] ) ? $input['interfaces'] : array();
			$interfaces    = array();
			$max           = 20;
			$i             = 0;
			foreach ( $interfaces_in as $row ) {
				if ( $i >= $max ) {
					break;
				}
				$row = is_array( $row ) ? $row : array();

				$id = isset( $row['id'] ) ? sanitize_text_field( (string) $row['id'] ) : '';
				if ( '' === $id ) {
					$id = function_exists( 'wp_generate_uuid4' ) ? wp_generate_uuid4() : (string) ( time() . '_' . $i );
				}

				$name         = isset( $row['name'] ) ? sanitize_text_field( (string) $row['name'] ) : '';
				$api_base_url = isset( $row['api_base_url'] ) ? esc_url_raw( trim( (string) $row['api_base_url'] ) ) : '';
				$api_key      = isset( $row['api_key'] ) ? sanitize_text_field( (string) $row['api_key'] ) : '';
				$model        = isset( $row['model'] ) ? sanitize_text_field( (string) $row['model'] ) : '';
				$clear_key    = ! empty( $row['clear_key'] );

				// Skip completely empty rows.
				if ( '' === $name && '' === $api_base_url && '' === $api_key && '' === $model ) {
					continue;
				}

				if ( '' === $name ) {
					$name = __( '未命名接口', 'zhiwrite-ai-writer' );
				}

				// Sensitive config protection:
				// - Do NOT require API key to be echoed back into the settings HTML.
				// - If input key is empty, keep existing stored key (unless explicitly cleared).
				if ( $clear_key ) {
					$api_key = '';
				} elseif ( '' === $api_key && '' !== $id && ! empty( $existing_interfaces ) ) {
					foreach ( $existing_interfaces as $ex ) {
						if ( ! is_array( $ex ) ) {
							continue;
						}
						if ( isset( $ex['id'] ) && (string) $ex['id'] === (string) $id && ! empty( $ex['api_key'] ) ) {
							$api_key = sanitize_text_field( (string) $ex['api_key'] );
							break;
						}
					}
				}

				$interfaces[] = array(
					'id'           => $id,
					'name'         => $name,
					'api_base_url' => $api_base_url,
					'api_key'      => $api_key,
					'model'        => $model,
				);
				$i++;
			}

			$out['interfaces'] = $interfaces;

			$default_id = isset( $input['default_interface_id'] ) ? sanitize_text_field( (string) $input['default_interface_id'] ) : '';
			if ( '' === $default_id && ! empty( $interfaces ) ) {
				$default_id = (string) $interfaces[0]['id'];
			}
			if ( '' !== $default_id && ! empty( $interfaces ) ) {
				$found = false;
				foreach ( $interfaces as $row ) {
					if ( (string) $row['id'] === (string) $default_id ) {
						$found = true;
						break;
					}
				}
				if ( ! $found ) {
					$default_id = (string) $interfaces[0]['id'];
				}
			}
			$out['default_interface_id'] = $default_id;
		} elseif ( array_key_exists( 'default_interface_id', $input ) ) {
			// Only update default id when explicitly submitted (should typically come with interfaces tab).
			$out['default_interface_id'] = sanitize_text_field( (string) $input['default_interface_id'] );
		}

		if ( array_key_exists( 'timeout', $input ) ) {
			$out['timeout'] = max( 5, min( 300, (int) $input['timeout'] ) );
		}
		if ( array_key_exists( 'retry_times', $input ) ) {
			$out['retry_times'] = max( 0, min( 5, (int) $input['retry_times'] ) );
		}
		if ( array_key_exists( 'retry_backoff_ms', $input ) ) {
			$out['retry_backoff_ms'] = max( 0, min( 10000, (int) $input['retry_backoff_ms'] ) );
		}
		if ( array_key_exists( 'concurrency_user_max', $input ) ) {
			$out['concurrency_user_max'] = max( 1, min( 3, (int) $input['concurrency_user_max'] ) );
		}
		if ( array_key_exists( 'concurrency_global_max', $input ) ) {
			$out['concurrency_global_max'] = max( 1, min( 20, (int) $input['concurrency_global_max'] ) );
		}
		if ( array_key_exists( 'concurrency_lock_ttl', $input ) ) {
			$out['concurrency_lock_ttl'] = max( 60, min( 3600, (int) $input['concurrency_lock_ttl'] ) );
		}
		// Checkbox: enable_queue（后台队列）
		// 该字段只在“稳定性与性能”Tab 中显示。
		// 取消勾选时浏览器不会提交 enable_queue，如果仅用 array_key_exists 判断，就永远无法从 1 变回 0。
		//
		// 这里通过检测本 Tab 其他字段是否出现来判断当前是否在“稳定性与性能”Tab 保存：
		// 一旦确认是这个 Tab，就按“存在=1，缺失=0”的规则写回 enable_queue。
		$on_stability_tab = array_key_exists( 'timeout', $input )
			|| array_key_exists( 'retry_times', $input )
			|| array_key_exists( 'retry_backoff_ms', $input )
			|| array_key_exists( 'concurrency_user_max', $input )
			|| array_key_exists( 'concurrency_global_max', $input )
			|| array_key_exists( 'concurrency_lock_ttl', $input );
		if ( $on_stability_tab ) {
			$out['enable_queue'] = ! empty( $input['enable_queue'] ) ? 1 : 0;
		}

		if ( array_key_exists( 'enable_editors', $input ) ) {
			$out['enable_editors'] = ! empty( $input['enable_editors'] ) ? 1 : 0;
		}
		// Fine-grained capabilities.
		$allowed_caps = array( self::CAPABILITY_MANAGE_OPTIONS, self::CAPABILITY_EDIT_POSTS );
		if ( array_key_exists( 'cap_generate', $input ) ) {
			$cap_generate       = sanitize_text_field( (string) $input['cap_generate'] );
			$out['cap_generate'] = in_array( $cap_generate, $allowed_caps, true ) ? $cap_generate : self::CAPABILITY_MANAGE_OPTIONS;
		}
		if ( array_key_exists( 'cap_logs', $input ) ) {
			$cap_logs       = sanitize_text_field( (string) $input['cap_logs'] );
			$out['cap_logs'] = in_array( $cap_logs, $allowed_caps, true ) ? $cap_logs : self::CAPABILITY_MANAGE_OPTIONS;
		}
		if ( array_key_exists( 'save_logs', $input ) ) {
			$out['save_logs'] = ! empty( $input['save_logs'] ) ? 1 : 0;
		}
		if ( array_key_exists( 'keep_data_on_uninstall', $input ) ) {
			$out['keep_data_on_uninstall'] = ! empty( $input['keep_data_on_uninstall'] ) ? 1 : 0;
		}
		if ( array_key_exists( 'budget_enabled', $input ) ) {
			$out['budget_enabled'] = ! empty( $input['budget_enabled'] ) ? 1 : 0;
		}
		if ( array_key_exists( 'budget_daily_requests', $input ) ) {
			$out['budget_daily_requests'] = max( 0, (int) $input['budget_daily_requests'] );
		}
		if ( array_key_exists( 'budget_daily_tokens', $input ) ) {
			$out['budget_daily_tokens'] = max( 0, (int) $input['budget_daily_tokens'] );
		}
		if ( array_key_exists( 'budget_notify_email', $input ) ) {
			$out['budget_notify_email'] = ! empty( $input['budget_notify_email'] ) ? 1 : 0;
		}

		if ( array_key_exists( 'privacy_pii_mask', $input ) ) {
			$out['privacy_pii_mask'] = ! empty( $input['privacy_pii_mask'] ) ? 1 : 0;
		}
		if ( array_key_exists( 'privacy_block_enabled', $input ) ) {
			$out['privacy_block_enabled'] = ! empty( $input['privacy_block_enabled'] ) ? 1 : 0;
		}
		if ( array_key_exists( 'privacy_block_keywords', $input ) ) {
			$out['privacy_block_keywords'] = sanitize_textarea_field( (string) $input['privacy_block_keywords'] );
		}

		if ( array_key_exists( 'default_post_status', $input ) ) {
			$status = (string) $input['default_post_status'];
			$out['default_post_status'] = in_array( $status, array( 'draft', 'publish', 'manual' ), true ) ? $status : 'draft';
		}

		if ( array_key_exists( 'content_format', $input ) ) {
			$fmt = (string) $input['content_format'];
			$allowed = array( self::CONTENT_FORMAT_WP_HTML, self::CONTENT_FORMAT_MARKDOWN );
			$out['content_format'] = in_array( $fmt, $allowed, true ) ? $fmt : self::CONTENT_FORMAT_WP_HTML;
		}

		if ( array_key_exists( 'system_context', $input ) ) {
			// Keep this flexible but safe for storage. We only ever send it to the model, not render as HTML.
			$out['system_context'] = sanitize_textarea_field( (string) $input['system_context'] );
		}

		// Email config.
		if ( array_key_exists( 'mail_mode', $input ) ) {
			$mode = sanitize_key( (string) $input['mail_mode'] );
			$out['mail_mode'] = in_array( $mode, array( 'system', 'smtp' ), true ) ? $mode : 'system';
		}
		if ( array_key_exists( 'mail_from_email', $input ) ) {
			$out['mail_from_email'] = sanitize_email( (string) $input['mail_from_email'] );
		}
		if ( array_key_exists( 'mail_from_name', $input ) ) {
			$out['mail_from_name'] = sanitize_text_field( (string) $input['mail_from_name'] );
		}
		if ( array_key_exists( 'smtp_host', $input ) ) {
			$out['smtp_host'] = sanitize_text_field( (string) $input['smtp_host'] );
		}
		if ( array_key_exists( 'smtp_port', $input ) ) {
			$out['smtp_port'] = max( 1, min( 65535, (int) $input['smtp_port'] ) );
		}
		if ( array_key_exists( 'smtp_encryption', $input ) ) {
			$enc = sanitize_key( (string) $input['smtp_encryption'] );
			$out['smtp_encryption'] = in_array( $enc, array( 'none', 'ssl', 'tls' ), true ) ? $enc : 'tls';
		}
		if ( array_key_exists( 'smtp_username', $input ) ) {
			$out['smtp_username'] = sanitize_text_field( (string) $input['smtp_username'] );
		}
		if ( array_key_exists( 'smtp_password', $input ) ) {
			// Sensitive: do not require echo back; empty input keeps existing password.
			$pwd = (string) $input['smtp_password'];
			$pwd = sanitize_text_field( $pwd );
			if ( '' === $pwd ) {
				$out['smtp_password'] = isset( $existing['smtp_password'] ) ? sanitize_text_field( (string) $existing['smtp_password'] ) : '';
			} else {
				$out['smtp_password'] = $pwd;
			}
		}
		if ( array_key_exists( 'smtp_clear_password', $input ) ) {
			if ( ! empty( $input['smtp_clear_password'] ) ) {
				$out['smtp_password'] = '';
			}
		}
		if ( array_key_exists( 'smtp_timeout_test', $input ) ) {
			$out['smtp_timeout_test'] = max( 3, min( 60, (int) $input['smtp_timeout_test'] ) );
		}
		if ( array_key_exists( 'smtp_timeout_send', $input ) ) {
			$out['smtp_timeout_send'] = max( 3, min( 120, (int) $input['smtp_timeout_send'] ) );
		}

		// Content safety.
		if ( array_key_exists( 'content_safety_enabled', $input ) ) {
			$out['content_safety_enabled'] = ! empty( $input['content_safety_enabled'] ) ? 1 : 0;
		}
		if ( array_key_exists( 'sensitive_action', $input ) ) {
			$a = sanitize_key( (string) $input['sensitive_action'] );
			$out['sensitive_action'] = in_array( $a, array( 'block', 'replace', 'warn' ), true ) ? $a : 'warn';
		}
		if ( array_key_exists( 'sensitive_replace_with', $input ) ) {
			$out['sensitive_replace_with'] = sanitize_text_field( (string) $input['sensitive_replace_with'] );
		}
		if ( array_key_exists( 'sensitive_words', $input ) ) {
			$out['sensitive_words'] = sanitize_textarea_field( (string) $input['sensitive_words'] );
		}
		if ( array_key_exists( 'safety_external_enabled', $input ) ) {
			$out['safety_external_enabled'] = ! empty( $input['safety_external_enabled'] ) ? 1 : 0;
		}
		if ( array_key_exists( 'safety_external_url', $input ) ) {
			$out['safety_external_url'] = esc_url_raw( trim( (string) $input['safety_external_url'] ) );
		}
		if ( array_key_exists( 'safety_external_timeout', $input ) ) {
			$out['safety_external_timeout'] = max( 3, min( 30, (int) $input['safety_external_timeout'] ) );
		}
		if ( array_key_exists( 'safety_external_fail_open', $input ) ) {
			$out['safety_external_fail_open'] = ! empty( $input['safety_external_fail_open'] ) ? 1 : 0;
		}
		if ( array_key_exists( 'seo_rules_enabled', $input ) ) {
			$out['seo_rules_enabled'] = ! empty( $input['seo_rules_enabled'] ) ? 1 : 0;
		}
		if ( array_key_exists( 'seo_title_min', $input ) ) {
			$out['seo_title_min'] = max( 0, min( 200, (int) $input['seo_title_min'] ) );
		}
		if ( array_key_exists( 'seo_title_max', $input ) ) {
			$out['seo_title_max'] = max( 0, min( 300, (int) $input['seo_title_max'] ) );
		}
		if ( array_key_exists( 'seo_excerpt_min', $input ) ) {
			$out['seo_excerpt_min'] = max( 0, min( 500, (int) $input['seo_excerpt_min'] ) );
		}
		if ( array_key_exists( 'seo_excerpt_max', $input ) ) {
			$out['seo_excerpt_max'] = max( 0, min( 800, (int) $input['seo_excerpt_max'] ) );
		}
		if ( array_key_exists( 'seo_h2_min', $input ) ) {
			$out['seo_h2_min'] = max( 0, min( 50, (int) $input['seo_h2_min'] ) );
		}
		if ( array_key_exists( 'seo_kw_per_1000_min', $input ) ) {
			$out['seo_kw_per_1000_min'] = max( 0, min( 200, (int) $input['seo_kw_per_1000_min'] ) );
		}
		if ( array_key_exists( 'seo_kw_per_1000_max', $input ) ) {
			$out['seo_kw_per_1000_max'] = max( 0, min( 500, (int) $input['seo_kw_per_1000_max'] ) );
		}
		if ( array_key_exists( 'internal_links_enabled', $input ) ) {
			$out['internal_links_enabled'] = ! empty( $input['internal_links_enabled'] ) ? 1 : 0;
		}
		if ( array_key_exists( 'internal_links_max', $input ) ) {
			$out['internal_links_max'] = max( 0, min( 20, (int) $input['internal_links_max'] ) );
		}
		if ( array_key_exists( 'internal_links_position', $input ) ) {
			$p = sanitize_key( (string) $input['internal_links_position'] );
			$out['internal_links_position'] = in_array( $p, array( 'after_h2_1', 'end' ), true ) ? $p : 'after_h2_1';
		}
		if ( array_key_exists( 'internal_links_strategy', $input ) ) {
			$s = sanitize_key( (string) $input['internal_links_strategy'] );
			$out['internal_links_strategy'] = in_array( $s, array( 'keyword', 'recent' ), true ) ? $s : 'keyword';
		}
		if ( array_key_exists( 'auto_excerpt_enabled', $input ) ) {
			$out['auto_excerpt_enabled'] = ! empty( $input['auto_excerpt_enabled'] ) ? 1 : 0;
		}
		if ( array_key_exists( 'auto_excerpt_len', $input ) ) {
			$out['auto_excerpt_len'] = max( 20, min( 400, (int) $input['auto_excerpt_len'] ) );
		}
		if ( array_key_exists( 'lead_enabled', $input ) ) {
			$out['lead_enabled'] = ! empty( $input['lead_enabled'] ) ? 1 : 0;
		}
		if ( array_key_exists( 'lead_prefix', $input ) ) {
			$out['lead_prefix'] = sanitize_text_field( (string) $input['lead_prefix'] );
		}
		if ( array_key_exists( 'terms_apply_enabled', $input ) ) {
			$out['terms_apply_enabled'] = ! empty( $input['terms_apply_enabled'] ) ? 1 : 0;
		}
		if ( array_key_exists( 'terms_auto_create', $input ) ) {
			$out['terms_auto_create'] = ! empty( $input['terms_auto_create'] ) ? 1 : 0;
		}
		if ( array_key_exists( 'terms_require_confirm', $input ) ) {
			$out['terms_require_confirm'] = ! empty( $input['terms_require_confirm'] ) ? 1 : 0;
		}

		// Tag generation defaults (post list).
		if ( array_key_exists( 'tag_gen_interface_id', $input ) ) {
			$out['tag_gen_interface_id'] = sanitize_text_field( (string) $input['tag_gen_interface_id'] );
		}
		if ( array_key_exists( 'tag_gen_model', $input ) ) {
			$out['tag_gen_model'] = sanitize_text_field( (string) $input['tag_gen_model'] );
		}
		if ( array_key_exists( 'tag_gen_count', $input ) ) {
			$out['tag_gen_count'] = max( 3, min( 20, (int) $input['tag_gen_count'] ) );
		}
		if ( array_key_exists( 'tag_gen_apply_mode', $input ) ) {
			$m = sanitize_key( (string) $input['tag_gen_apply_mode'] );
			$out['tag_gen_apply_mode'] = in_array( $m, array( 'append', 'replace' ), true ) ? $m : 'append';
		}
		if ( array_key_exists( 'toc_enabled', $input ) ) {
			$out['toc_enabled'] = ! empty( $input['toc_enabled'] ) ? 1 : 0;
		}
		if ( array_key_exists( 'toc_include_h3', $input ) ) {
			$out['toc_include_h3'] = ! empty( $input['toc_include_h3'] ) ? 1 : 0;
		}
		if ( array_key_exists( 'toc_min_headings', $input ) ) {
			$out['toc_min_headings'] = max( 0, min( 50, (int) $input['toc_min_headings'] ) );
		}
		if ( array_key_exists( 'toc_position', $input ) ) {
			$p = sanitize_key( (string) $input['toc_position'] );
			$out['toc_position'] = in_array( $p, array( 'after_lead', 'after_h2_1', 'start' ), true ) ? $p : 'after_lead';
		}
		if ( array_key_exists( 'faq_enabled', $input ) ) {
			$out['faq_enabled'] = ! empty( $input['faq_enabled'] ) ? 1 : 0;
		}
		if ( array_key_exists( 'faq_count', $input ) ) {
			$out['faq_count'] = max( 1, min( 15, (int) $input['faq_count'] ) );
		}
		if ( array_key_exists( 'faq_position', $input ) ) {
			$p = sanitize_key( (string) $input['faq_position'] );
			$out['faq_position'] = in_array( $p, array( 'end', 'before_end' ), true ) ? $p : 'end';
		}
		if ( array_key_exists( 'precheck_enabled', $input ) ) {
			$out['precheck_enabled'] = ! empty( $input['precheck_enabled'] ) ? 1 : 0;
		}
		if ( array_key_exists( 'precheck_block_publish', $input ) ) {
			$out['precheck_block_publish'] = ! empty( $input['precheck_block_publish'] ) ? 1 : 0;
		}
		if ( array_key_exists( 'precheck_require_excerpt', $input ) ) {
			$out['precheck_require_excerpt'] = ! empty( $input['precheck_require_excerpt'] ) ? 1 : 0;
		}
		if ( array_key_exists( 'precheck_require_image', $input ) ) {
			$out['precheck_require_image'] = ! empty( $input['precheck_require_image'] ) ? 1 : 0;
		}
		if ( array_key_exists( 'precheck_external_links_max', $input ) ) {
			$out['precheck_external_links_max'] = max( 0, min( 200, (int) $input['precheck_external_links_max'] ) );
		}
		if ( array_key_exists( 'cache_enabled', $input ) ) {
			$out['cache_enabled'] = ! empty( $input['cache_enabled'] ) ? 1 : 0;
		}
		if ( array_key_exists( 'cache_ttl_minutes', $input ) ) {
			$out['cache_ttl_minutes'] = max( 1, min( 10080, (int) $input['cache_ttl_minutes'] ) );
		}
		if ( array_key_exists( 'cache_scope', $input ) ) {
			$s = sanitize_key( (string) $input['cache_scope'] );
			$out['cache_scope'] = in_array( $s, array( 'strict', 'loose' ), true ) ? $s : 'strict';
		}
		if ( array_key_exists( 'failover_enabled', $input ) ) {
			$out['failover_enabled'] = ! empty( $input['failover_enabled'] ) ? 1 : 0;
		}
		if ( array_key_exists( 'failover_fail_threshold', $input ) ) {
			$out['failover_fail_threshold'] = max( 1, min( 10, (int) $input['failover_fail_threshold'] ) );
		}
		if ( array_key_exists( 'failover_cooldown_sec', $input ) ) {
			$out['failover_cooldown_sec'] = max( 30, min( 86400, (int) $input['failover_cooldown_sec'] ) );
		}
		if ( array_key_exists( 'model_router_enabled', $input ) ) {
			$out['model_router_enabled'] = ! empty( $input['model_router_enabled'] ) ? 1 : 0;
		}
		if ( array_key_exists( 'model_router_long_threshold', $input ) ) {
			$out['model_router_long_threshold'] = max( 0, min( 20000, (int) $input['model_router_long_threshold'] ) );
		}
		if ( array_key_exists( 'model_router_long_model', $input ) ) {
			$out['model_router_long_model'] = sanitize_text_field( (string) $input['model_router_long_model'] );
		}
		if ( array_key_exists( 'model_router_seo_model', $input ) ) {
			$out['model_router_seo_model'] = sanitize_text_field( (string) $input['model_router_seo_model'] );
		}
		if ( array_key_exists( 'webhook_enabled', $input ) ) {
			$out['webhook_enabled'] = ! empty( $input['webhook_enabled'] ) ? 1 : 0;
		}
		if ( array_key_exists( 'webhook_url', $input ) ) {
			$out['webhook_url'] = esc_url_raw( trim( (string) $input['webhook_url'] ) );
		}
		if ( array_key_exists( 'webhook_secret', $input ) ) {
			$sec = sanitize_text_field( (string) $input['webhook_secret'] );
			if ( '' === $sec && isset( $existing['webhook_secret'] ) ) {
				$sec = sanitize_text_field( (string) $existing['webhook_secret'] );
			}
			$out['webhook_secret'] = $sec;
		}
		if ( array_key_exists( 'webhook_clear_secret', $input ) ) {
			if ( ! empty( $input['webhook_clear_secret'] ) ) {
				$out['webhook_secret'] = '';
			}
		}
		if ( array_key_exists( 'webhook_timeout', $input ) ) {
			$out['webhook_timeout'] = max( 1, min( 20, (int) $input['webhook_timeout'] ) );
		}
		if ( array_key_exists( 'webhook_retry_enabled', $input ) ) {
			$out['webhook_retry_enabled'] = ! empty( $input['webhook_retry_enabled'] ) ? 1 : 0;
		}
		if ( array_key_exists( 'webhook_retry_max', $input ) ) {
			$out['webhook_retry_max'] = max( 0, min( 20, (int) $input['webhook_retry_max'] ) );
		}
		if ( array_key_exists( 'webhook_retry_base_sec', $input ) ) {
			$out['webhook_retry_base_sec'] = max( 1, min( 600, (int) $input['webhook_retry_base_sec'] ) );
		}
		if ( array_key_exists( 'webhook_retry_max_sec', $input ) ) {
			$out['webhook_retry_max_sec'] = max( 10, min( 86400, (int) $input['webhook_retry_max_sec'] ) );
		}
		if ( array_key_exists( 'webhook_retry_dead_ttl_days', $input ) ) {
			$out['webhook_retry_dead_ttl_days'] = max( 1, min( 365, (int) $input['webhook_retry_dead_ttl_days'] ) );
		}
		if ( array_key_exists( 'fact_check_enabled', $input ) ) {
			$out['fact_check_enabled'] = ! empty( $input['fact_check_enabled'] ) ? 1 : 0;
		}

		// Prompt builder JSON (Phase 6.4).
		if ( array_key_exists( 'prompt_builder', $input ) ) {
			$raw = (string) $input['prompt_builder'];
			$raw = trim( $raw );
			$decoded = '' !== $raw ? json_decode( $raw, true ) : null;
			if ( is_array( $decoded ) ) {
				$normalized = self::normalize_prompt_builder( $decoded, isset( $out['prompt_builder'] ) ? $out['prompt_builder'] : array() );
				$old_json = wp_json_encode( isset( $out['prompt_builder'] ) ? $out['prompt_builder'] : array(), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );
				$new_json = wp_json_encode( $normalized, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );
				if ( $old_json !== $new_json ) {
					$revs = isset( $out['prompt_builder_revisions'] ) && is_array( $out['prompt_builder_revisions'] ) ? $out['prompt_builder_revisions'] : array();
					array_unshift(
						$revs,
						array(
							'ts'   => time(),
							'data' => isset( $out['prompt_builder'] ) ? $out['prompt_builder'] : array(),
						)
					);
					$out['prompt_builder_revisions'] = array_slice( $revs, 0, 10 );
				}
				$out['prompt_builder'] = $normalized;
			}
		}

		return $out;
	}

	private static function normalize_prompt_builder( array $in, $existing ) {
		$existing = is_array( $existing ) ? $existing : array();
		$out = array();
		$out['version'] = 1;

		$vars = isset( $in['vars'] ) && is_array( $in['vars'] ) ? $in['vars'] : array();
		$vars_out = array();
		foreach ( $vars as $k => $v ) {
			$k = sanitize_key( (string) $k );
			if ( '' === $k ) {
				continue;
			}
			$vars_out[ $k ] = is_scalar( $v ) ? sanitize_text_field( (string) $v ) : '';
		}
		$out['vars'] = $vars_out;

		$templates_in = isset( $in['templates'] ) && is_array( $in['templates'] ) ? $in['templates'] : array();
		$templates = array();
		foreach ( $templates_in as $row ) {
			$row = is_array( $row ) ? $row : array();
			$id = isset( $row['id'] ) ? sanitize_key( (string) $row['id'] ) : '';
			$name = isset( $row['name'] ) ? sanitize_text_field( (string) $row['name'] ) : '';
			$content = isset( $row['content'] ) ? (string) $row['content'] : '';
			$content = wp_kses_post( $content ); // stored only; not rendered to frontend
			if ( '' === $id || '' === $name ) {
				continue;
			}
			$templates[] = array(
				'id'      => $id,
				'name'    => $name,
				'content' => $content,
			);
		}
		if ( empty( $templates ) ) {
			$templates = isset( $existing['templates'] ) && is_array( $existing['templates'] ) ? $existing['templates'] : array();
		}
		$out['templates'] = $templates;

		$styles_in = isset( $in['styles'] ) && is_array( $in['styles'] ) ? $in['styles'] : array();
		$styles = array();
		foreach ( $styles_in as $row ) {
			$row = is_array( $row ) ? $row : array();
			$id = isset( $row['id'] ) ? sanitize_key( (string) $row['id'] ) : '';
			$name = isset( $row['name'] ) ? sanitize_text_field( (string) $row['name'] ) : '';
			$content = isset( $row['content'] ) ? (string) $row['content'] : '';
			$content = wp_kses_post( $content );
			if ( '' === $id || '' === $name ) {
				continue;
			}
			$styles[] = array(
				'id'      => $id,
				'name'    => $name,
				'content' => $content,
			);
		}
		if ( empty( $styles ) ) {
			$styles = isset( $existing['styles'] ) && is_array( $existing['styles'] ) ? $existing['styles'] : array();
		}
		$out['styles'] = $styles;

		$out['default_template_id'] = isset( $in['default_template_id'] ) ? sanitize_key( (string) $in['default_template_id'] ) : '';
		$out['default_style_id'] = isset( $in['default_style_id'] ) ? sanitize_key( (string) $in['default_style_id'] ) : '';
		if ( '' === $out['default_template_id'] && ! empty( $templates[0]['id'] ) ) {
			$out['default_template_id'] = (string) $templates[0]['id'];
		}
		if ( '' === $out['default_style_id'] && ! empty( $styles[0]['id'] ) ) {
			$out['default_style_id'] = (string) $styles[0]['id'];
		}

		return $out;
	}

	public static function field_prompt_builder() {
		$opts = self::get_options();
		$pb   = isset( $opts['prompt_builder'] ) && is_array( $opts['prompt_builder'] ) ? $opts['prompt_builder'] : array();
		$revs = isset( $opts['prompt_builder_revisions'] ) && is_array( $opts['prompt_builder_revisions'] ) ? $opts['prompt_builder_revisions'] : array();
		$json = wp_json_encode( $pb, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );
		if ( ! is_string( $json ) ) {
			$json = '{}';
		}

		echo '<p class="description" style="margin:0 0 10px;">' . esc_html__( '该 JSON 会注入生成提示词（system 侧），支持模板/风格/变量。占位符格式：{{site_name}}、{{date}}、{{title}}、{{prompt}}。', 'zhiwrite-ai-writer' ) . '</p>';
		printf(
			'<textarea id="zhiwrite_prompt_builder" name="%1$s[prompt_builder]" rows="16" class="large-text code" placeholder="%2$s">%3$s</textarea>',
			esc_attr( self::OPTION_KEY ),
			esc_attr__( '请输入 JSON…', 'zhiwrite-ai-writer' ),
			esc_textarea( $json )
		);
		echo '<p class="description" style="margin:8px 0 0;">' . esc_html__( '提示：修改后保存会自动保留最近 10 个历史版本，便于回滚。', 'zhiwrite-ai-writer' ) . '</p>';
		if ( ! empty( $revs ) ) {
			echo '<div style="margin-top:10px;">';
			echo '<label for="zhiwrite_prompt_builder_rev" class="description" style="display:block;margin-bottom:6px;">' . esc_html__( '历史版本（回滚）', 'zhiwrite-ai-writer' ) . '</label>';
			echo '<select id="zhiwrite_prompt_builder_rev" style="max-width:520px;width:100%;">';
			echo '<option value="">' . esc_html__( '选择要回滚的版本…', 'zhiwrite-ai-writer' ) . '</option>';
			foreach ( $revs as $idx => $r ) {
				$ts = isset( $r['ts'] ) ? (int) $r['ts'] : 0;
				$label = $ts > 0 ? gmdate( 'Y-m-d H:i:s', $ts ) : (string) $idx;
				printf( '<option value="%1$s">%2$s</option>', esc_attr( (string) $idx ), esc_html( $label ) );
			}
			echo '</select> ';
			echo '<button type="button" class="button" id="zhiwrite-prompt-builder-rollback" style="margin-top:8px;">' . esc_html__( '回滚到所选版本', 'zhiwrite-ai-writer' ) . '</button>';
			echo '</div>';
		}
	}

	public static function field_content_format() {
		$opts = self::get_options();
		$val  = isset( $opts['content_format'] ) ? (string) $opts['content_format'] : self::CONTENT_FORMAT_WP_HTML;

		printf(
			'<select name="%1$s[content_format]">
				<option value="%2$s" %4$s>%5$s</option>
				<option value="%3$s" %6$s>%7$s</option>
			</select>',
			esc_attr( self::OPTION_KEY ),
			esc_attr( self::CONTENT_FORMAT_WP_HTML ),
			esc_attr( self::CONTENT_FORMAT_MARKDOWN ),
			selected( $val, self::CONTENT_FORMAT_WP_HTML, false ),
			esc_html__( 'WordPress（HTML/区块编辑器兼容，推荐）', 'zhiwrite-ai-writer' ),
			selected( $val, self::CONTENT_FORMAT_MARKDOWN, false ),
			esc_html__( 'Markdown（原样保存；需主题/插件支持渲染）', 'zhiwrite-ai-writer' )
		);
		echo '<p class="description">' .
			esc_html__( '说明：WordPress 核心正文存储为 HTML。若选择 Markdown，插件会原样保存到正文，并额外写入文章 meta 以便后续转换/渲染。', 'zhiwrite-ai-writer' ) .
			'</p>';
	}

	public static function field_system_context() {
		$opts = self::get_options();
		$val  = isset( $opts['system_context'] ) ? (string) $opts['system_context'] : '';

		printf(
			'<textarea name="%1$s[system_context]" rows="6" cols="60" class="large-text" placeholder="%2$s">%3$s</textarea>',
			esc_attr( self::OPTION_KEY ),
			esc_attr__( "例如：\n- 站点定位：…\n- 目标人群：…\n- 口吻风格：…\n- 禁用词/合规要求：…\n- 默认 CTA：…", 'zhiwrite-ai-writer' ),
			esc_textarea( $val )
		);
		echo '<p class="description">' .
			esc_html__( '会追加到 AI system 提示词中，用于统一口径与风格。这里不要填写敏感密钥（API Key 等）。', 'zhiwrite-ai-writer' ) .
			'</p>';
	}

	public static function field_interfaces() {
		$opts       = self::get_options();
		$interfaces = isset( $opts['interfaces'] ) && is_array( $opts['interfaces'] ) ? $opts['interfaces'] : array();
		$default_id = isset( $opts['default_interface_id'] ) ? (string) $opts['default_interface_id'] : '';

		echo '<div id="zhiwrite-interfaces-wrap">';
		echo '<table class="widefat striped" id="zhiwrite-interfaces-table">';
		echo '<thead><tr>';
		echo '<th style="width:90px;">' . esc_html__( '默认', 'zhiwrite-ai-writer' ) . '</th>';
		echo '<th>' . esc_html__( '名称', 'zhiwrite-ai-writer' ) . '</th>';
		echo '<th>' . esc_html__( 'API 接口地址', 'zhiwrite-ai-writer' ) . '</th>';
		echo '<th>' . esc_html__( 'API Key', 'zhiwrite-ai-writer' ) . '</th>';
		echo '<th>' . esc_html__( '默认模型', 'zhiwrite-ai-writer' ) . '</th>';
		echo '<th style="width:90px;">' . esc_html__( '操作', 'zhiwrite-ai-writer' ) . '</th>';
		echo '</tr></thead>';
		echo '<tbody>';

		if ( empty( $interfaces ) ) {
			$interfaces = array(
				array(
					'id'           => function_exists( 'wp_generate_uuid4' ) ? wp_generate_uuid4() : (string) time(),
					'name'         => __( '默认接口', 'zhiwrite-ai-writer' ),
					'api_base_url' => '',
					'api_key'      => '',
					'model'        => '',
				),
			);
			if ( '' === $default_id ) {
				$default_id = (string) $interfaces[0]['id'];
			}
		}

		foreach ( $interfaces as $idx => $row ) {
			$id           = isset( $row['id'] ) ? (string) $row['id'] : '';
			$name         = isset( $row['name'] ) ? (string) $row['name'] : '';
			$api_base_url = isset( $row['api_base_url'] ) ? (string) $row['api_base_url'] : '';
			$api_key      = isset( $row['api_key'] ) ? (string) $row['api_key'] : '';
			$model        = isset( $row['model'] ) ? (string) $row['model'] : '';
			$has_key      = '' !== trim( (string) $api_key );

			echo '<tr class="zhiwrite-interface-row" data-interface-id="' . esc_attr( $id ) . '">';

			echo '<td>';
			printf(
				'<label><input type="radio" name="%1$s[default_interface_id]" value="%2$s" %3$s /> %4$s</label>',
				esc_attr( self::OPTION_KEY ),
				esc_attr( $id ),
				checked( $default_id, $id, false ),
				esc_html__( '默认', 'zhiwrite-ai-writer' )
			);
			echo '</td>';

			printf(
				'<td><input type="hidden" name="%1$s[interfaces][%2$d][id]" value="%3$s" />' .
				'<input type="text" class="regular-text" name="%1$s[interfaces][%2$d][name]" value="%4$s" placeholder="%5$s" /></td>',
				esc_attr( self::OPTION_KEY ),
				(int) $idx,
				esc_attr( $id ),
				esc_attr( $name ),
				esc_attr__( '例如：OpenAI / 中转A / 备用', 'zhiwrite-ai-writer' )
			);

			printf(
				'<td><input type="url" class="regular-text zhiwrite-if-base-url" name="%1$s[interfaces][%2$d][api_base_url]" value="%3$s" placeholder="https://api.example.com/v1" /></td>',
				esc_attr( self::OPTION_KEY ),
				(int) $idx,
				esc_attr( $api_base_url )
			);

			printf(
				'<td>' .
				'<input type="password" class="regular-text zhiwrite-if-api-key" name="%1$s[interfaces][%2$d][api_key]" value="" autocomplete="new-password" placeholder="%4$s" />' .
				'<div style="margin-top:6px;line-height:1.2;">' .
				'<label class="description"><input type="checkbox" class="zhiwrite-if-clear-key" name="%1$s[interfaces][%2$d][clear_key]" value="1" /> %5$s</label>' .
				'</div>' .
				'</td>',
				esc_attr( self::OPTION_KEY ),
				(int) $idx,
				esc_attr( $api_key ),
				$has_key ? esc_attr__( '已保存（不显示）', 'zhiwrite-ai-writer' ) : esc_attr__( '请输入 API Key', 'zhiwrite-ai-writer' ),
				esc_html__( '清空 Key（谨慎）', 'zhiwrite-ai-writer' )
			);

			printf(
				'<td><input type="text" class="regular-text zhiwrite-if-model" name="%1$s[interfaces][%2$d][model]" value="%3$s" placeholder="gpt-4o-mini" /></td>',
				esc_attr( self::OPTION_KEY ),
				(int) $idx,
				esc_attr( $model )
			);

			echo '<td>';
			echo '<button type="button" class="button zhiwrite-if-test">' . esc_html__( '测试', 'zhiwrite-ai-writer' ) . '</button> ';
			echo '<button type="button" class="button link-delete zhiwrite-if-remove">' . esc_html__( '删除', 'zhiwrite-ai-writer' ) . '</button>';
			echo '</td>';

			echo '</tr>';
		}

		echo '</tbody></table>';
		echo '<p style="margin-top:10px;">';
		echo '<button type="button" class="button button-secondary" id="zhiwrite-if-add">' . esc_html__( '添加接口', 'zhiwrite-ai-writer' ) . '</button>';
		echo ' <button type="button" class="button button-secondary" id="zhiwrite-if-test-all">' . esc_html__( '一键测试全部接口', 'zhiwrite-ai-writer' ) . '</button>';
		echo ' <button type="button" class="button" id="zhiwrite-if-toggle-debug" disabled>' . esc_html__( '隐藏调试信息', 'zhiwrite-ai-writer' ) . '</button>';
		echo ' <button type="button" class="button" id="zhiwrite-if-clear-result" disabled>' . esc_html__( '清空结果', 'zhiwrite-ai-writer' ) . '</button>';
		echo '</p>';
		echo '<p class="description">' . esc_html__( '可添加多个 OpenAI 兼容接口。生成时可选择要使用的接口；未选择时使用“默认”。', 'zhiwrite-ai-writer' ) . '</p>';
		echo '<div id="zhiwrite-if-test-result"></div>';

		// Import / Export.
		echo '<hr style="margin:16px 0;" />';
		echo '<h3 style="margin:0 0 8px;">' . esc_html__( '配置导入/导出（JSON）', 'zhiwrite-ai-writer' ) . '</h3>';
		echo '<p class="description" style="margin:0 0 10px;">' . esc_html__( '用于在不同站点间迁移配置。默认导出会脱敏（不包含 API Key）。导入会覆盖当前插件配置，请谨慎操作。', 'zhiwrite-ai-writer' ) . '</p>';
		echo '<p style="margin:0 0 8px;">';
		echo '<label style="margin-right:10px;"><input type="checkbox" id="zhiwrite-export-include-keys" value="1" /> ' . esc_html__( '导出包含 API Key（有泄露风险）', 'zhiwrite-ai-writer' ) . '</label>';
		echo '<button type="button" class="button button-secondary" id="zhiwrite-export-settings">' . esc_html__( '导出 JSON', 'zhiwrite-ai-writer' ) . '</button> ';
		echo '<button type="button" class="button button-secondary" id="zhiwrite-copy-settings" disabled>' . esc_html__( '复制到剪贴板', 'zhiwrite-ai-writer' ) . '</button>';
		echo '</p>';
		echo '<textarea id="zhiwrite-settings-json" class="large-text code" rows="8" placeholder="' . esc_attr__( '点击“导出 JSON”生成，或粘贴要导入的 JSON…', 'zhiwrite-ai-writer' ) . '"></textarea>';
		echo '<p style="margin:8px 0 0;">';
		echo '<button type="button" class="button button-primary" id="zhiwrite-import-settings">' . esc_html__( '导入并覆盖当前配置', 'zhiwrite-ai-writer' ) . '</button>';
		echo ' <span id="zhiwrite-import-hint" class="description"></span>';
		echo '</p>';

		// Diagnostics export (sanitized).
		echo '<hr style="margin:16px 0;" />';
		echo '<h3 style="margin:0 0 8px;">' . esc_html__( '诊断导出（脱敏）', 'zhiwrite-ai-writer' ) . '</h3>';
		echo '<p class="description" style="margin:0 0 10px;">' .
			esc_html__( '用于排查“无法连接/生成失败/超时”等问题。导出的诊断包会自动脱敏（不包含 API Key/敏感内容正文）。', 'zhiwrite-ai-writer' ) .
			'</p>';
		echo '<p style="margin:0 0 8px;">';
		echo '<button type="button" class="button button-secondary" id="zhiwrite-export-diagnostics">' . esc_html__( '导出诊断包（JSON）', 'zhiwrite-ai-writer' ) . '</button>';
		echo '</p>';

		echo '</div>';
	}

	/**
	 * Pick an interface config by id (or default) with fallback to legacy fields.
	 *
	 * @param string $interface_id
	 * @return array { id,name,api_base_url,api_key,model }
	 */
	public static function get_interface( $interface_id = '' ) {
		$opts       = self::get_options();
		$interfaces = isset( $opts['interfaces'] ) && is_array( $opts['interfaces'] ) ? $opts['interfaces'] : array();

		$want = '' !== (string) $interface_id ? (string) $interface_id : (string) $opts['default_interface_id'];
		if ( '' !== $want && ! empty( $interfaces ) ) {
			foreach ( $interfaces as $row ) {
				if ( isset( $row['id'] ) && (string) $row['id'] === $want ) {
					return wp_parse_args(
						$row,
						array(
							'id'           => $want,
							'name'         => '',
							'api_base_url' => '',
							'api_key'      => '',
							'model'        => '',
						)
					);
				}
			}
		}

		// Fallback: first interface.
		if ( ! empty( $interfaces ) ) {
			return wp_parse_args(
				$interfaces[0],
				array(
					'id'           => isset( $interfaces[0]['id'] ) ? (string) $interfaces[0]['id'] : '',
					'name'         => '',
					'api_base_url' => '',
					'api_key'      => '',
					'model'        => '',
				)
			);
		}

		// Fallback: legacy fields.
		return array(
			'id'           => '',
			'name'         => '',
			'api_base_url' => (string) $opts['api_base_url'],
			'api_key'      => (string) $opts['api_key'],
			'model'        => (string) $opts['model'],
		);
	}

	public static function field_timeout() {
		$opts = self::get_options();
		printf(
			'<input type="number" min="5" max="300" name="%1$s[timeout]" value="%2$d" />',
			esc_attr( self::OPTION_KEY ),
			(int) $opts['timeout']
		);
	}

	public static function field_retry_times() {
		$opts = self::get_options();
		printf(
			'<input type="number" min="0" max="5" name="%1$s[retry_times]" value="%2$d" />',
			esc_attr( self::OPTION_KEY ),
			isset( $opts['retry_times'] ) ? (int) $opts['retry_times'] : 0
		);
		echo '<p class="description">' . esc_html__( '仅用于临时错误（网络抖动、429、5xx）。建议 0-2 次，次数过多会拖慢生成。', 'zhiwrite-ai-writer' ) . '</p>';
	}

	public static function field_retry_backoff_ms() {
		$opts = self::get_options();
		printf(
			'<input type="number" min="0" max="10000" step="100" name="%1$s[retry_backoff_ms]" value="%2$d" />',
			esc_attr( self::OPTION_KEY ),
			isset( $opts['retry_backoff_ms'] ) ? (int) $opts['retry_backoff_ms'] : 0
		);
		echo '<p class="description">' . esc_html__( '每次重试前等待的毫秒数（简单退避）。例如 800ms。', 'zhiwrite-ai-writer' ) . '</p>';
	}

	public static function field_concurrency_user_max() {
		$opts = self::get_options();
		printf(
			'<input type="number" min="1" max="3" name="%1$s[concurrency_user_max]" value="%2$d" />',
			esc_attr( self::OPTION_KEY ),
			isset( $opts['concurrency_user_max'] ) ? (int) $opts['concurrency_user_max'] : 1
		);
		echo '<p class="description">' . esc_html__( '建议 1。用于避免同一用户重复点击导致后台并发请求过多。', 'zhiwrite-ai-writer' ) . '</p>';
	}

	public static function field_concurrency_global_max() {
		$opts = self::get_options();
		printf(
			'<input type="number" min="1" max="20" name="%1$s[concurrency_global_max]" value="%2$d" />',
			esc_attr( self::OPTION_KEY ),
			isset( $opts['concurrency_global_max'] ) ? (int) $opts['concurrency_global_max'] : 3
		);
		echo '<p class="description">' . esc_html__( '全站同时运行的“生成任务”数量上限（最佳努力限制）。服务器性能一般建议 2-5。', 'zhiwrite-ai-writer' ) . '</p>';
	}

	public static function field_concurrency_lock_ttl() {
		$opts = self::get_options();
		printf(
			'<input type="number" min="60" max="3600" step="30" name="%1$s[concurrency_lock_ttl]" value="%2$d" />',
			esc_attr( self::OPTION_KEY ),
			isset( $opts['concurrency_lock_ttl'] ) ? (int) $opts['concurrency_lock_ttl'] : 900
		);
		echo '<p class="description">' . esc_html__( '锁超时用于异常情况下自动释放（例如 PHP 致命错误/进程被杀）。一般设置为略大于“请求超时 + 预期生成耗时”。', 'zhiwrite-ai-writer' ) . '</p>';
	}

	public static function field_enable_queue() {
		$opts = self::get_options();
		printf(
			'<label><input type="checkbox" name="%1$s[enable_queue]" value="1" %2$s /> %3$s</label>',
			esc_attr( self::OPTION_KEY ),
			checked( 1, isset( $opts['enable_queue'] ) ? (int) $opts['enable_queue'] : 0, false ),
			esc_html__( '启用后台队列执行（推荐：避免长请求导致后台卡顿/超时；依赖 WP-Cron）', 'zhiwrite-ai-writer' )
		);
		echo '<p class="description">' .
			esc_html__( '开启后，点击“生成”会先提交任务并显示进度，实际生成在后台队列中执行。若站点禁用 WP-Cron，请确保有真实 Cron 触发 wp-cron.php。', 'zhiwrite-ai-writer' ) .
			'</p>';
	}

	public static function field_enable_editors() {
		$opts = self::get_options();
		printf(
			'<label><input type="checkbox" name="%1$s[enable_editors]" value="1" %2$s /> %3$s</label>',
			esc_attr( self::OPTION_KEY ),
			checked( 1, (int) $opts['enable_editors'], false ),
			esc_html__( '开启后，Editor（编辑）也可使用智写AI。', 'zhiwrite-ai-writer' )
		);
	}

	private static function field_cap_select( $name, $current, $desc ) {
		$name = (string) $name;
		$cur  = (string) $current;
		printf(
			'<select name="%1$s[%2$s]">' .
			'<option value="%3$s" %5$s>%6$s</option>' .
			'<option value="%4$s" %7$s>%8$s</option>' .
			'</select>',
			esc_attr( self::OPTION_KEY ),
			esc_attr( $name ),
			esc_attr( self::CAPABILITY_MANAGE_OPTIONS ),
			esc_attr( self::CAPABILITY_EDIT_POSTS ),
			selected( $cur, self::CAPABILITY_MANAGE_OPTIONS, false ),
			esc_html__( '仅管理员（manage_options）', 'zhiwrite-ai-writer' ),
			selected( $cur, self::CAPABILITY_EDIT_POSTS, false ),
			esc_html__( '编辑及以上（edit_posts）', 'zhiwrite-ai-writer' )
		);
		if ( '' !== (string) $desc ) {
			echo '<p class="description">' . esc_html( (string) $desc ) . '</p>';
		}
	}

	public static function field_cap_generate() {
		$opts = self::get_options();
		$cur  = isset( $opts['cap_generate'] ) ? (string) $opts['cap_generate'] : self::CAPABILITY_MANAGE_OPTIONS;
		self::field_cap_select( 'cap_generate', $cur, __( '控制哪些角色可以使用“生成内容”页面与生成相关 AJAX。', 'zhiwrite-ai-writer' ) );
	}

	public static function field_cap_logs() {
		$opts = self::get_options();
		$cur  = isset( $opts['cap_logs'] ) ? (string) $opts['cap_logs'] : self::CAPABILITY_MANAGE_OPTIONS;
		self::field_cap_select( 'cap_logs', $cur, __( '控制哪些角色可以查看/导出/删除“生成记录”。', 'zhiwrite-ai-writer' ) );
	}

	public static function field_default_post_status() {
		$opts = self::get_options();
		?>
		<select name="<?php echo esc_attr( self::OPTION_KEY ); ?>[default_post_status]">
			<option value="draft" <?php selected( $opts['default_post_status'], 'draft' ); ?>><?php echo esc_html__( '草稿', 'zhiwrite-ai-writer' ); ?></option>
			<option value="publish" <?php selected( $opts['default_post_status'], 'publish' ); ?>><?php echo esc_html__( '直接发布', 'zhiwrite-ai-writer' ); ?></option>
			<option value="manual" <?php selected( $opts['default_post_status'], 'manual' ); ?>><?php echo esc_html__( '仅展示结果（操作者决定保存/发布）', 'zhiwrite-ai-writer' ); ?></option>
		</select>
		<p class="description">
			<?php echo esc_html__( '选择“仅展示结果”后，生成时不会自动创建文章，而是在右侧展示结果并提供“保存为草稿 / 直接发布”按钮。', 'zhiwrite-ai-writer' ); ?>
		</p>
		<?php
	}

	public static function field_save_logs() {
		$opts = self::get_options();
		printf(
			'<label><input type="checkbox" name="%1$s[save_logs]" value="1" %2$s /> %3$s</label>',
			esc_attr( self::OPTION_KEY ),
			checked( 1, (int) $opts['save_logs'], false ),
			esc_html__( '保存生成记录（可在“生成记录”里删除）。', 'zhiwrite-ai-writer' )
		);
	}

	public static function field_keep_data_on_uninstall() {
		$opts = self::get_options();
		printf(
			'<label><input type="checkbox" name="%1$s[keep_data_on_uninstall]" value="1" %2$s /> %3$s</label>',
			esc_attr( self::OPTION_KEY ),
			checked( 1, (int) $opts['keep_data_on_uninstall'], false ),
			esc_html__( '卸载插件时保留设置与生成记录（默认勾选）。', 'zhiwrite-ai-writer' )
		);
	}

	public static function field_budget_enabled() {
		$opts = self::get_options();
		printf(
			'<label><input type="checkbox" name="%1$s[budget_enabled]" value="1" %2$s /> %3$s</label>',
			esc_attr( self::OPTION_KEY ),
			checked( 1, isset( $opts['budget_enabled'] ) ? (int) $opts['budget_enabled'] : 0, false ),
			esc_html__( '启用预算阈值（超额后拦截生成）', 'zhiwrite-ai-writer' )
		);
		echo '<p class="description">' .
			esc_html__( 'tokens 统计依赖上游接口是否返回 usage；若不可得，会退化为仅按请求数限制。', 'zhiwrite-ai-writer' ) .
			'</p>';
	}

	public static function field_budget_daily_requests() {
		$opts = self::get_options();
		printf(
			'<input type="number" min="0" step="1" name="%1$s[budget_daily_requests]" value="%2$d" />',
			esc_attr( self::OPTION_KEY ),
			isset( $opts['budget_daily_requests'] ) ? (int) $opts['budget_daily_requests'] : 0
		);
		echo '<p class="description">' . esc_html__( '0 表示不限制。', 'zhiwrite-ai-writer' ) . '</p>';
	}

	public static function field_budget_daily_tokens() {
		$opts = self::get_options();
		printf(
			'<input type="number" min="0" step="1" name="%1$s[budget_daily_tokens]" value="%2$d" />',
			esc_attr( self::OPTION_KEY ),
			isset( $opts['budget_daily_tokens'] ) ? (int) $opts['budget_daily_tokens'] : 0
		);
		echo '<p class="description">' . esc_html__( '0 表示不限制；仅在上游返回 usage 时生效。', 'zhiwrite-ai-writer' ) . '</p>';
	}

	public static function field_budget_notify_email() {
		$opts = self::get_options();
		printf(
			'<label style="margin-right:10px;"><input type="checkbox" name="%1$s[budget_notify_email]" value="1" %2$s /> %3$s</label>',
			esc_attr( self::OPTION_KEY ),
			checked( 1, isset( $opts['budget_notify_email'] ) ? (int) $opts['budget_notify_email'] : 1, false ),
			esc_html__( '超额时发送邮件到站点管理员邮箱', 'zhiwrite-ai-writer' )
		);
		echo ' <button type="button" class="button button-secondary" id="zhiwrite-test-email">' . esc_html__( '发送测试邮件', 'zhiwrite-ai-writer' ) . '</button>';
		echo '<p class="description" style="margin-top:8px;">' .
			esc_html__( '测试邮件会发送到“设置 -> 常规 -> 管理员邮箱地址”。若未收到，请检查站点 SMTP/邮件投递插件配置与垃圾箱。', 'zhiwrite-ai-writer' ) .
			'</p>';
	}

	public static function field_privacy_pii_mask() {
		$opts = self::get_options();
		printf(
			'<label><input type="checkbox" name="%1$s[privacy_pii_mask]" value="1" %2$s /> %3$s</label>',
			esc_attr( self::OPTION_KEY ),
			checked( 1, isset( $opts['privacy_pii_mask'] ) ? (int) $opts['privacy_pii_mask'] : 0, false ),
			esc_html__( '在发送到模型前，对常见 PII（邮箱、手机号等）做基础脱敏，同时日志中也保存脱敏后的内容。', 'zhiwrite-ai-writer' )
		);
		echo '<p class="description">' .
			esc_html__( '说明：该选项不会修改站点数据库中已有的文章，仅对“写作需求”等请求内容进行正则脱敏处理。', 'zhiwrite-ai-writer' ) .
			'</p>';
	}

	public static function field_privacy_block_enabled() {
		$opts = self::get_options();
		printf(
			'<label><input type="checkbox" name="%1$s[privacy_block_enabled]" value="1" %2$s /> %3$s</label>',
			esc_attr( self::OPTION_KEY ),
			checked( 1, isset( $opts['privacy_block_enabled'] ) ? (int) $opts['privacy_block_enabled'] : 0, false ),
			esc_html__( '在发送到模型前，将包含指定关键字的行进行脱敏/替换（用于屏蔽作者邮箱、订单号等“明确字段”）。', 'zhiwrite-ai-writer' )
		);
	}

	public static function field_privacy_block_keywords() {
		$opts = self::get_options();
		$val  = isset( $opts['privacy_block_keywords'] ) ? (string) $opts['privacy_block_keywords'] : '';
		printf(
			'<textarea name="%1$s[privacy_block_keywords]" rows="5" cols="60" class="large-text code" placeholder="%2$s">%3$s</textarea>',
			esc_attr( self::OPTION_KEY ),
			esc_attr__( "示例（每行一个关键字）：\n作者邮箱\n订单号\n手机\n身份证\nemail\norder_id", 'zhiwrite-ai-writer' ),
			esc_textarea( $val )
		);
		echo '<p class="description">' .
			esc_html__( '匹配规则：按“行”匹配（不区分大小写）。命中行会将冒号/等号后的值替换为 ***removed*** 再发送给模型与写入日志。', 'zhiwrite-ai-writer' ) .
			'</p>';
	}

	public static function field_mail_mode() {
		$opts = self::get_options();
		$val  = isset( $opts['mail_mode'] ) ? (string) $opts['mail_mode'] : 'system';
		if ( ! in_array( $val, array( 'system', 'smtp' ), true ) ) {
			$val = 'system';
		}

		printf(
			'<select name="%1$s[mail_mode]">
				<option value="system" %2$s>%3$s</option>
				<option value="smtp" %4$s>%5$s</option>
			</select>',
			esc_attr( self::OPTION_KEY ),
			selected( $val, 'system', false ),
			esc_html__( '使用系统邮件（wp_mail/站点邮件插件）', 'zhiwrite-ai-writer' ),
			selected( $val, 'smtp', false ),
			esc_html__( '使用插件 SMTP（仅影响智写AI发送的邮件）', 'zhiwrite-ai-writer' )
		);
		echo '<p class="description">' .
			esc_html__( '默认不干预系统邮件配置；当选择“插件 SMTP”时，智写AI 会在发送邮件时临时注入 SMTP 参数。', 'zhiwrite-ai-writer' ) .
			'</p>';
	}

	public static function field_mail_from_email() {
		$opts = self::get_options();
		$val  = isset( $opts['mail_from_email'] ) ? (string) $opts['mail_from_email'] : '';
		printf(
			'<input type="email" class="regular-text" name="%1$s[mail_from_email]" value="%2$s" placeholder="%3$s" />',
			esc_attr( self::OPTION_KEY ),
			esc_attr( $val ),
			esc_attr__( '例如：no-reply@yourdomain.com', 'zhiwrite-ai-writer' )
		);
	}

	public static function field_mail_from_name() {
		$opts = self::get_options();
		$val  = isset( $opts['mail_from_name'] ) ? (string) $opts['mail_from_name'] : '';
		printf(
			'<input type="text" class="regular-text" name="%1$s[mail_from_name]" value="%2$s" placeholder="%3$s" />',
			esc_attr( self::OPTION_KEY ),
			esc_attr( $val ),
			esc_attr__( '例如：智写AI', 'zhiwrite-ai-writer' )
		);
	}

	public static function field_smtp_host() {
		$opts = self::get_options();
		$val  = isset( $opts['smtp_host'] ) ? (string) $opts['smtp_host'] : '';
		printf(
			'<input type="text" class="regular-text" name="%1$s[smtp_host]" value="%2$s" placeholder="%3$s" />',
			esc_attr( self::OPTION_KEY ),
			esc_attr( $val ),
			esc_attr__( '例如：smtp.gmail.com', 'zhiwrite-ai-writer' )
		);
	}

	public static function field_smtp_port() {
		$opts = self::get_options();
		$val  = isset( $opts['smtp_port'] ) ? (int) $opts['smtp_port'] : 587;
		printf(
			'<input type="number" min="1" max="65535" name="%1$s[smtp_port]" value="%2$d" />',
			esc_attr( self::OPTION_KEY ),
			(int) $val
		);
	}

	public static function field_smtp_encryption() {
		$opts = self::get_options();
		$val  = isset( $opts['smtp_encryption'] ) ? (string) $opts['smtp_encryption'] : 'tls';
		if ( ! in_array( $val, array( 'none', 'ssl', 'tls' ), true ) ) {
			$val = 'tls';
		}
		printf(
			'<select name="%1$s[smtp_encryption]">
				<option value="none" %2$s>%3$s</option>
				<option value="ssl" %4$s>%5$s</option>
				<option value="tls" %6$s>%7$s</option>
			</select>',
			esc_attr( self::OPTION_KEY ),
			selected( $val, 'none', false ),
			esc_html__( '不加密', 'zhiwrite-ai-writer' ),
			selected( $val, 'ssl', false ),
			esc_html__( 'SSL', 'zhiwrite-ai-writer' ),
			selected( $val, 'tls', false ),
			esc_html__( 'TLS', 'zhiwrite-ai-writer' )
		);
	}

	public static function field_smtp_username() {
		$opts = self::get_options();
		$val  = isset( $opts['smtp_username'] ) ? (string) $opts['smtp_username'] : '';
		printf(
			'<input type="text" class="regular-text" name="%1$s[smtp_username]" value="%2$s" autocomplete="username" />',
			esc_attr( self::OPTION_KEY ),
			esc_attr( $val )
		);
	}

	public static function field_smtp_password() {
		$opts    = self::get_options();
		$has_pwd = ! empty( $opts['smtp_password'] );
		printf(
			'<input type="password" class="regular-text" name="%1$s[smtp_password]" value="" autocomplete="new-password" placeholder="%2$s" />',
			esc_attr( self::OPTION_KEY ),
			$has_pwd ? esc_attr__( '已保存（不显示）', 'zhiwrite-ai-writer' ) : esc_attr__( '请输入 SMTP 密码', 'zhiwrite-ai-writer' )
		);
		echo '<div style="margin-top:6px;line-height:1.2;">' .
			'<label class="description"><input type="checkbox" name="' . esc_attr( self::OPTION_KEY ) . '[smtp_clear_password]" value="1" /> ' .
			esc_html__( '清空密码（谨慎）', 'zhiwrite-ai-writer' ) .
			'</label>' .
			'</div>';
	}

	public static function field_smtp_timeout_test() {
		$opts = self::get_options();
		$val  = isset( $opts['smtp_timeout_test'] ) ? (int) $opts['smtp_timeout_test'] : 10;
		printf(
			'<input type="number" min="3" max="60" step="1" name="%1$s[smtp_timeout_test]" value="%2$d" />',
			esc_attr( self::OPTION_KEY ),
			(int) $val
		);
		echo '<p class="description">' .
			esc_html__( '用于“发送测试邮件”按钮的 SMTP 连接/发送超时。', 'zhiwrite-ai-writer' ) .
			'</p>';
	}

	public static function field_smtp_timeout_send() {
		$opts = self::get_options();
		$val  = isset( $opts['smtp_timeout_send'] ) ? (int) $opts['smtp_timeout_send'] : 15;
		printf(
			'<input type="number" min="3" max="120" step="1" name="%1$s[smtp_timeout_send]" value="%2$d" />',
			esc_attr( self::OPTION_KEY ),
			(int) $val
		);
		echo '<p class="description">' .
			esc_html__( '用于预算阈值等正式通知邮件的 SMTP 连接/发送超时。', 'zhiwrite-ai-writer' ) .
			'</p>';
	}

	public static function field_content_safety_enabled() {
		$opts = self::get_options();
		printf(
			'<label><input type="checkbox" name="%1$s[content_safety_enabled]" value="1" %2$s /> %3$s</label>',
			esc_attr( self::OPTION_KEY ),
			checked( 1, isset( $opts['content_safety_enabled'] ) ? (int) $opts['content_safety_enabled'] : 0, false ),
			esc_html__( '对生成结果/保存内容进行敏感词检测（本地词库）', 'zhiwrite-ai-writer' )
		);
	}

	public static function field_sensitive_action() {
		$opts = self::get_options();
		$val  = isset( $opts['sensitive_action'] ) ? (string) $opts['sensitive_action'] : 'warn';
		if ( ! in_array( $val, array( 'block', 'replace', 'warn' ), true ) ) {
			$val = 'warn';
		}
		printf(
			'<select name="%1$s[sensitive_action]">
				<option value="warn" %2$s>%3$s</option>
				<option value="replace" %4$s>%5$s</option>
				<option value="block" %6$s>%7$s</option>
			</select>',
			esc_attr( self::OPTION_KEY ),
			selected( $val, 'warn', false ),
			esc_html__( '提示（不拦截）', 'zhiwrite-ai-writer' ),
			selected( $val, 'replace', false ),
			esc_html__( '替换后继续', 'zhiwrite-ai-writer' ),
			selected( $val, 'block', false ),
			esc_html__( '拦截（不允许保存/发布）', 'zhiwrite-ai-writer' )
		);
	}

	public static function field_sensitive_replace_with() {
		$opts = self::get_options();
		$val  = isset( $opts['sensitive_replace_with'] ) ? (string) $opts['sensitive_replace_with'] : '***';
		printf(
			'<input type="text" class="regular-text" name="%1$s[sensitive_replace_with]" value="%2$s" placeholder="***" />',
			esc_attr( self::OPTION_KEY ),
			esc_attr( $val )
		);
	}

	public static function field_sensitive_words() {
		$opts = self::get_options();
		$val  = isset( $opts['sensitive_words'] ) ? (string) $opts['sensitive_words'] : '';
		printf(
			'<textarea name="%1$s[sensitive_words]" rows="8" cols="60" class="large-text code" placeholder="%2$s">%3$s</textarea>',
			esc_attr( self::OPTION_KEY ),
			esc_attr__( "每行一个敏感词/短语，例如：\n违禁词A\n违禁词B", 'zhiwrite-ai-writer' ),
			esc_textarea( $val )
		);
		echo '<p class="description">' .
			esc_html__( '说明：为避免误伤，当前采用“包含匹配”（不区分大小写）。建议先用“提示”策略观察命中情况，再决定是否开启拦截/替换。', 'zhiwrite-ai-writer' ) .
			'</p>';
	}

	public static function field_safety_external_enabled() {
		$opts = self::get_options();
		printf(
			'<label><input type="checkbox" name="%1$s[safety_external_enabled]" value="1" %2$s /> %3$s</label>',
			esc_attr( self::OPTION_KEY ),
			checked( 1, isset( $opts['safety_external_enabled'] ) ? (int) $opts['safety_external_enabled'] : 0, false ),
			esc_html__( '启用外部内容安全检测接口（失败可降级）', 'zhiwrite-ai-writer' )
		);
	}

	public static function field_safety_external_url() {
		$opts = self::get_options();
		$val  = isset( $opts['safety_external_url'] ) ? (string) $opts['safety_external_url'] : '';
		printf(
			'<input type="url" class="large-text" name="%1$s[safety_external_url]" value="%2$s" placeholder="%3$s" />',
			esc_attr( self::OPTION_KEY ),
			esc_attr( $val ),
			esc_attr__( '例如：https://safety.example.com/check', 'zhiwrite-ai-writer' )
		);
		echo '<p class="description">' .
			esc_html__( '接口需返回 JSON：{ ok: true/false, action: "allow|replace|block", text?: "...", hits?: [], message?: "..." }。', 'zhiwrite-ai-writer' ) .
			'</p>';
	}

	public static function field_safety_external_timeout() {
		$opts = self::get_options();
		$val  = isset( $opts['safety_external_timeout'] ) ? (int) $opts['safety_external_timeout'] : 8;
		printf(
			'<input type="number" min="3" max="30" step="1" name="%1$s[safety_external_timeout]" value="%2$d" />',
			esc_attr( self::OPTION_KEY ),
			(int) $val
		);
	}

	public static function field_safety_external_fail_open() {
		$opts = self::get_options();
		$val  = isset( $opts['safety_external_fail_open'] ) ? (int) $opts['safety_external_fail_open'] : 1;
		printf(
			'<select name="%1$s[safety_external_fail_open]">
				<option value="1" %2$s>%3$s</option>
				<option value="0" %4$s>%5$s</option>
			</select>',
			esc_attr( self::OPTION_KEY ),
			selected( $val, 1, false ),
			esc_html__( '失败放行（提示外部检测不可用）', 'zhiwrite-ai-writer' ),
			selected( $val, 0, false ),
			esc_html__( '失败拦截（更严格）', 'zhiwrite-ai-writer' )
		);
	}

	public static function field_seo_rules_enabled() {
		$opts = self::get_options();
		printf(
			'<label><input type="checkbox" name="%1$s[seo_rules_enabled]" value="1" %2$s /> %3$s</label>',
			esc_attr( self::OPTION_KEY ),
			checked( 1, isset( $opts['seo_rules_enabled'] ) ? (int) $opts['seo_rules_enabled'] : 1, false ),
			esc_html__( '生成后给出 SEO 规则提示（不拦截保存/发布）', 'zhiwrite-ai-writer' )
		);
	}

	private static function field_num( $key, $min, $max ) {
		$opts = self::get_options();
		$val  = isset( $opts[ $key ] ) ? (int) $opts[ $key ] : 0;
		printf(
			'<input type="number" min="%2$d" max="%3$d" step="1" name="%1$s[%4$s]" value="%5$d" />',
			esc_attr( self::OPTION_KEY ),
			(int) $min,
			(int) $max,
			esc_attr( (string) $key ),
			(int) $val
		);
	}

	public static function field_seo_title_min() { self::field_num( 'seo_title_min', 0, 200 ); }
	public static function field_seo_title_max() { self::field_num( 'seo_title_max', 0, 300 ); }
	public static function field_seo_excerpt_min() { self::field_num( 'seo_excerpt_min', 0, 500 ); }
	public static function field_seo_excerpt_max() { self::field_num( 'seo_excerpt_max', 0, 800 ); }
	public static function field_seo_h2_min() { self::field_num( 'seo_h2_min', 0, 50 ); }
	public static function field_seo_kw_per_1000_min() { self::field_num( 'seo_kw_per_1000_min', 0, 200 ); }
	public static function field_seo_kw_per_1000_max() { self::field_num( 'seo_kw_per_1000_max', 0, 500 ); }

	public static function field_internal_links_enabled() {
		$opts = self::get_options();
		printf(
			'<label><input type="checkbox" name="%1$s[internal_links_enabled]" value="1" %2$s /> %3$s</label>',
			esc_attr( self::OPTION_KEY ),
			checked( 1, isset( $opts['internal_links_enabled'] ) ? (int) $opts['internal_links_enabled'] : 0, false ),
			esc_html__( '生成后自动插入站内相关文章链接（仅使用公开文章）', 'zhiwrite-ai-writer' )
		);
	}

	public static function field_internal_links_max() { self::field_num( 'internal_links_max', 0, 20 ); }

	public static function field_internal_links_position() {
		$opts = self::get_options();
		$val  = isset( $opts['internal_links_position'] ) ? (string) $opts['internal_links_position'] : 'after_h2_1';
		printf(
			'<select name="%1$s[internal_links_position]">
				<option value="after_h2_1" %2$s>%3$s</option>
				<option value="end" %4$s>%5$s</option>
			</select>',
			esc_attr( self::OPTION_KEY ),
			selected( $val, 'after_h2_1', false ),
			esc_html__( '第一个 H2 后', 'zhiwrite-ai-writer' ),
			selected( $val, 'end', false ),
			esc_html__( '正文末尾', 'zhiwrite-ai-writer' )
		);
	}

	public static function field_internal_links_strategy() {
		$opts = self::get_options();
		$val  = isset( $opts['internal_links_strategy'] ) ? (string) $opts['internal_links_strategy'] : 'keyword';
		printf(
			'<select name="%1$s[internal_links_strategy]">
				<option value="keyword" %2$s>%3$s</option>
				<option value="recent" %4$s>%5$s</option>
			</select>',
			esc_attr( self::OPTION_KEY ),
			selected( $val, 'keyword', false ),
			esc_html__( '按焦点关键词/标题匹配', 'zhiwrite-ai-writer' ),
			selected( $val, 'recent', false ),
			esc_html__( '最近文章（兜底）', 'zhiwrite-ai-writer' )
		);
	}

	public static function field_auto_excerpt_enabled() {
		$opts = self::get_options();
		printf(
			'<label><input type="checkbox" name="%1$s[auto_excerpt_enabled]" value="1" %2$s /> %3$s</label>',
			esc_attr( self::OPTION_KEY ),
			checked( 1, isset( $opts['auto_excerpt_enabled'] ) ? (int) $opts['auto_excerpt_enabled'] : 1, false ),
			esc_html__( '当 AI 未返回摘要时，从正文自动生成摘要并写入 excerpt/meta 描述。', 'zhiwrite-ai-writer' )
		);
	}

	public static function field_auto_excerpt_len() { self::field_num( 'auto_excerpt_len', 20, 400 ); }

	public static function field_lead_enabled() {
		$opts = self::get_options();
		printf(
			'<label><input type="checkbox" name="%1$s[lead_enabled]" value="1" %2$s /> %3$s</label>',
			esc_attr( self::OPTION_KEY ),
			checked( 1, isset( $opts['lead_enabled'] ) ? (int) $opts['lead_enabled'] : 0, false ),
			esc_html__( '将摘要作为“导语”插入正文开头（不影响 excerpt 字段）。', 'zhiwrite-ai-writer' )
		);
	}

	public static function field_lead_prefix() {
		$opts = self::get_options();
		$val  = isset( $opts['lead_prefix'] ) ? (string) $opts['lead_prefix'] : '';
		printf(
			'<input type="text" class="regular-text" name="%1$s[lead_prefix]" value="%2$s" placeholder="%3$s" />',
			esc_attr( self::OPTION_KEY ),
			esc_attr( $val ),
			esc_attr__( '例如：导语：', 'zhiwrite-ai-writer' )
		);
	}

	public static function field_terms_apply_enabled() {
		$opts = self::get_options();
		printf(
			'<label><input type="checkbox" name="%1$s[terms_apply_enabled]" value="1" %2$s /> %3$s</label>',
			esc_attr( self::OPTION_KEY ),
			checked( 1, isset( $opts['terms_apply_enabled'] ) ? (int) $opts['terms_apply_enabled'] : 1, false ),
			esc_html__( '在保存文章时，将 AI 建议的分类/标签写入文章术语。', 'zhiwrite-ai-writer' )
		);
		echo '<p class="description">' .
			esc_html__( '说明：仅在你勾选“建议分类/标签”且生成结果返回 categories/tags 时生效。', 'zhiwrite-ai-writer' ) .
			'</p>';
	}

	public static function field_terms_auto_create() {
		$opts = self::get_options();
		printf(
			'<label><input type="checkbox" name="%1$s[terms_auto_create]" value="1" %2$s /> %3$s</label>',
			esc_attr( self::OPTION_KEY ),
			checked( 1, isset( $opts['terms_auto_create'] ) ? (int) $opts['terms_auto_create'] : 0, false ),
			esc_html__( '若站内不存在对应分类/标签，则自动创建再写入（可能造成分类体系污染）。', 'zhiwrite-ai-writer' )
		);
	}

	public static function field_terms_require_confirm() {
		$opts = self::get_options();
		printf(
			'<label><input type="checkbox" name="%1$s[terms_require_confirm]" value="1" %2$s /> %3$s</label>',
			esc_attr( self::OPTION_KEY ),
			checked( 1, isset( $opts['terms_require_confirm'] ) ? (int) $opts['terms_require_confirm'] : 1, false ),
			esc_html__( '在“仅展示结果”模式下，保存/发布前需要在结果区勾选确认要写入的分类/标签。', 'zhiwrite-ai-writer' )
		);
		echo '<p class="description">' .
			esc_html__( '关闭该选项时，预览保存会直接按 AI 建议写入分类/标签。', 'zhiwrite-ai-writer' ) .
			'</p>';
	}

	public static function field_tag_gen_interface_id() {
		$opts       = self::get_options();
		$interfaces = isset( $opts['interfaces'] ) && is_array( $opts['interfaces'] ) ? $opts['interfaces'] : array();
		$val        = isset( $opts['tag_gen_interface_id'] ) ? (string) $opts['tag_gen_interface_id'] : '';

		echo '<select name="' . esc_attr( self::OPTION_KEY ) . '[tag_gen_interface_id]">';
		echo '<option value="">' . esc_html__( '（默认：使用接口设置里的“默认接口”）', 'zhiwrite-ai-writer' ) . '</option>';
		foreach ( $interfaces as $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}
			$id   = isset( $row['id'] ) ? (string) $row['id'] : '';
			$name = isset( $row['name'] ) && '' !== (string) $row['name'] ? (string) $row['name'] : __( '未命名接口', 'zhiwrite-ai-writer' );
			if ( '' === $id ) {
				continue;
			}
			printf(
				'<option value="%1$s" %2$s>%3$s</option>',
				esc_attr( $id ),
				selected( $val, $id, false ),
				esc_html( $name )
			);
		}
		echo '</select>';
		echo '<p class="description">' . esc_html__( '用于“文章列表 -> 生成标签”弹窗的默认接口。留空则使用“接口设置”中的默认接口。', 'zhiwrite-ai-writer' ) . '</p>';
	}

	public static function field_tag_gen_model() {
		$opts = self::get_options();
		$val  = isset( $opts['tag_gen_model'] ) ? (string) $opts['tag_gen_model'] : '';
		printf(
			'<input type="text" class="regular-text" name="%1$s[tag_gen_model]" value="%2$s" placeholder="%3$s" />',
			esc_attr( self::OPTION_KEY ),
			esc_attr( $val ),
			esc_attr__( '留空则使用接口默认/全局默认（并可能被模型路由覆盖）', 'zhiwrite-ai-writer' )
		);
	}

	public static function field_tag_gen_count() {
		$opts = self::get_options();
		$val  = isset( $opts['tag_gen_count'] ) ? (int) $opts['tag_gen_count'] : 10;
		printf(
			'<input type="number" min="3" max="20" step="1" name="%1$s[tag_gen_count]" value="%2$d" />',
			esc_attr( self::OPTION_KEY ),
			(int) $val
		);
		echo '<p class="description">' . esc_html__( '用于“文章列表 -> 生成标签”默认生成数量（建议 5-12）。', 'zhiwrite-ai-writer' ) . '</p>';
	}

	public static function field_tag_gen_apply_mode() {
		$opts = self::get_options();
		$val  = isset( $opts['tag_gen_apply_mode'] ) ? (string) $opts['tag_gen_apply_mode'] : 'append';
		if ( ! in_array( $val, array( 'append', 'replace' ), true ) ) {
			$val = 'append';
		}
		printf(
			'<select name="%1$s[tag_gen_apply_mode]">
				<option value="append" %2$s>%3$s</option>
				<option value="replace" %4$s>%5$s</option>
			</select>',
			esc_attr( self::OPTION_KEY ),
			selected( $val, 'append', false ),
			esc_html__( '增量添加（保留原有）', 'zhiwrite-ai-writer' ),
			selected( $val, 'replace', false ),
			esc_html__( '覆盖原有标签', 'zhiwrite-ai-writer' )
		);
		echo '<p class="description">' . esc_html__( '当文章已有标签时，弹窗默认选项会优先使用这里的配置。', 'zhiwrite-ai-writer' ) . '</p>';
	}

	public static function field_toc_enabled() {
		$opts = self::get_options();
		printf(
			'<label><input type="checkbox" name="%1$s[toc_enabled]" value="1" %2$s /> %3$s</label>',
			esc_attr( self::OPTION_KEY ),
			checked( 1, isset( $opts['toc_enabled'] ) ? (int) $opts['toc_enabled'] : 0, false ),
			esc_html__( '根据正文 H2/H3 自动生成目录并插入正文。', 'zhiwrite-ai-writer' )
		);
	}

	public static function field_toc_include_h3() {
		$opts = self::get_options();
		printf(
			'<label><input type="checkbox" name="%1$s[toc_include_h3]" value="1" %2$s /> %3$s</label>',
			esc_attr( self::OPTION_KEY ),
			checked( 1, isset( $opts['toc_include_h3'] ) ? (int) $opts['toc_include_h3'] : 1, false ),
			esc_html__( '目录包含 H3（不勾选则只包含 H2）', 'zhiwrite-ai-writer' )
		);
	}

	public static function field_toc_min_headings() { self::field_num( 'toc_min_headings', 0, 50 ); }

	public static function field_toc_position() {
		$opts = self::get_options();
		$val  = isset( $opts['toc_position'] ) ? (string) $opts['toc_position'] : 'after_lead';
		printf(
			'<select name="%1$s[toc_position]">
				<option value="start" %2$s>%3$s</option>
				<option value="after_lead" %4$s>%5$s</option>
				<option value="after_h2_1" %6$s>%7$s</option>
			</select>',
			esc_attr( self::OPTION_KEY ),
			selected( $val, 'start', false ),
			esc_html__( '正文开头', 'zhiwrite-ai-writer' ),
			selected( $val, 'after_lead', false ),
			esc_html__( '导语之后（若启用导语）', 'zhiwrite-ai-writer' ),
			selected( $val, 'after_h2_1', false ),
			esc_html__( '第一个 H2 后', 'zhiwrite-ai-writer' )
		);
	}

	public static function field_faq_enabled() {
		$opts = self::get_options();
		printf(
			'<label><input type="checkbox" name="%1$s[faq_enabled]" value="1" %2$s /> %3$s</label>',
			esc_attr( self::OPTION_KEY ),
			checked( 1, isset( $opts['faq_enabled'] ) ? (int) $opts['faq_enabled'] : 0, false ),
			esc_html__( '让模型输出 FAQ（问答数组）并自动插入正文。', 'zhiwrite-ai-writer' )
		);
	}

	public static function field_faq_count() { self::field_num( 'faq_count', 1, 15 ); }

	public static function field_faq_position() {
		$opts = self::get_options();
		$val  = isset( $opts['faq_position'] ) ? (string) $opts['faq_position'] : 'end';
		printf(
			'<select name="%1$s[faq_position]">
				<option value="end" %2$s>%3$s</option>
				<option value="before_end" %4$s>%5$s</option>
			</select>',
			esc_attr( self::OPTION_KEY ),
			selected( $val, 'end', false ),
			esc_html__( '正文末尾', 'zhiwrite-ai-writer' ),
			selected( $val, 'before_end', false ),
			esc_html__( '免责声明/结尾之前（若存在）', 'zhiwrite-ai-writer' )
		);
	}

	public static function field_precheck_enabled() {
		$opts = self::get_options();
		printf(
			'<label><input type="checkbox" name="%1$s[precheck_enabled]" value="1" %2$s /> %3$s</label>',
			esc_attr( self::OPTION_KEY ),
			checked( 1, isset( $opts['precheck_enabled'] ) ? (int) $opts['precheck_enabled'] : 1, false ),
			esc_html__( '生成后显示校验清单；保存/发布时可按配置拦截。', 'zhiwrite-ai-writer' )
		);
	}

	public static function field_precheck_block_publish() {
		$opts = self::get_options();
		printf(
			'<label><input type="checkbox" name="%1$s[precheck_block_publish]" value="1" %2$s /> %3$s</label>',
			esc_attr( self::OPTION_KEY ),
			checked( 1, isset( $opts['precheck_block_publish'] ) ? (int) $opts['precheck_block_publish'] : 0, false ),
			esc_html__( '当选择“发布”时，命中失败项则阻止发布（保存为草稿不拦截）。', 'zhiwrite-ai-writer' )
		);
	}

	public static function field_precheck_require_excerpt() {
		$opts = self::get_options();
		printf(
			'<label><input type="checkbox" name="%1$s[precheck_require_excerpt]" value="1" %2$s /> %3$s</label>',
			esc_attr( self::OPTION_KEY ),
			checked( 1, isset( $opts['precheck_require_excerpt'] ) ? (int) $opts['precheck_require_excerpt'] : 1, false ),
			esc_html__( '摘要（excerpt/meta 描述）不能为空。', 'zhiwrite-ai-writer' )
		);
	}

	public static function field_precheck_require_image() {
		$opts = self::get_options();
		printf(
			'<label><input type="checkbox" name="%1$s[precheck_require_image]" value="1" %2$s /> %3$s</label>',
			esc_attr( self::OPTION_KEY ),
			checked( 1, isset( $opts['precheck_require_image'] ) ? (int) $opts['precheck_require_image'] : 0, false ),
			esc_html__( '正文中必须包含至少一张图片（<img> 或 Markdown 图片）。', 'zhiwrite-ai-writer' )
		);
	}

	public static function field_precheck_external_links_max() { self::field_num( 'precheck_external_links_max', 0, 200 ); }

	public static function field_cache_enabled() {
		$opts = self::get_options();
		printf(
			'<label><input type="checkbox" name="%1$s[cache_enabled]" value="1" %2$s /> %3$s</label>',
			esc_attr( self::OPTION_KEY ),
			checked( 1, isset( $opts['cache_enabled'] ) ? (int) $opts['cache_enabled'] : 0, false ),
			esc_html__( '对相同输入的生成结果做短期缓存（减少重复扣费）。', 'zhiwrite-ai-writer' )
		);
		echo '<p class="description">' .
			esc_html__( '提示：缓存仅用于重复输入场景；内容会存储在 WordPress transient 中，建议不要缓存包含敏感信息的提示词。', 'zhiwrite-ai-writer' ) .
			'</p>';
	}

	public static function field_cache_ttl_minutes() { self::field_num( 'cache_ttl_minutes', 1, 10080 ); }

	public static function field_cache_scope() {
		$opts = self::get_options();
		$val  = isset( $opts['cache_scope'] ) ? (string) $opts['cache_scope'] : 'strict';
		printf(
			'<select name="%1$s[cache_scope]">
				<option value="strict" %2$s>%3$s</option>
				<option value="loose" %4$s>%5$s</option>
			</select>',
			esc_attr( self::OPTION_KEY ),
			selected( $val, 'strict', false ),
			esc_html__( '严格（按接口/模型/格式/选项区分）', 'zhiwrite-ai-writer' ),
			selected( $val, 'loose', false ),
			esc_html__( '宽松（仅按提示词区分，可能复用到不同模型）', 'zhiwrite-ai-writer' )
		);
	}

	public static function field_cache_clear() {
		echo '<button type="button" class="button button-secondary" id="zhiwrite-clear-cache">' . esc_html__( '一键清理缓存', 'zhiwrite-ai-writer' ) . '</button>';
		echo '<p class="description" style="margin-top:8px;">' .
			esc_html__( '仅清理本插件生成缓存（transient），不影响其他插件。', 'zhiwrite-ai-writer' ) .
			'</p>';
	}

	public static function field_failover_enabled() {
		$opts = self::get_options();
		printf(
			'<label><input type="checkbox" name="%1$s[failover_enabled]" value="1" %2$s /> %3$s</label>',
			esc_attr( self::OPTION_KEY ),
			checked( 1, isset( $opts['failover_enabled'] ) ? (int) $opts['failover_enabled'] : 0, false ),
			esc_html__( '当当前接口请求失败时，自动尝试其他已配置接口。', 'zhiwrite-ai-writer' )
		);
	}

	public static function field_failover_fail_threshold() { self::field_num( 'failover_fail_threshold', 1, 10 ); }
	public static function field_failover_cooldown_sec() { self::field_num( 'failover_cooldown_sec', 30, 86400 ); }

	public static function field_model_router_enabled() {
		$opts = self::get_options();
		printf(
			'<label><input type="checkbox" name="%1$s[model_router_enabled]" value="1" %2$s /> %3$s</label>',
			esc_attr( self::OPTION_KEY ),
			checked( 1, isset( $opts['model_router_enabled'] ) ? (int) $opts['model_router_enabled'] : 0, false ),
			esc_html__( '按任务类型/输入长度自动选择模型（不覆盖你在生成页手动填写的模型）。', 'zhiwrite-ai-writer' )
		);
	}

	public static function field_model_router_long_threshold() { self::field_num( 'model_router_long_threshold', 0, 20000 ); }

	public static function field_model_router_long_model() {
		$opts = self::get_options();
		$val  = isset( $opts['model_router_long_model'] ) ? (string) $opts['model_router_long_model'] : '';
		printf(
			'<input type="text" class="regular-text" name="%1$s[model_router_long_model]" value="%2$s" placeholder="%3$s" />',
			esc_attr( self::OPTION_KEY ),
			esc_attr( $val ),
			esc_attr__( '例如：gpt-4o-mini / 其他', 'zhiwrite-ai-writer' )
		);
	}

	public static function field_model_router_seo_model() {
		$opts = self::get_options();
		$val  = isset( $opts['model_router_seo_model'] ) ? (string) $opts['model_router_seo_model'] : '';
		printf(
			'<input type="text" class="regular-text" name="%1$s[model_router_seo_model]" value="%2$s" placeholder="%3$s" />',
			esc_attr( self::OPTION_KEY ),
			esc_attr( $val ),
			esc_attr__( '例如：gpt-4o / 其他', 'zhiwrite-ai-writer' )
		);
		echo '<p class="description">' .
			esc_html__( '当启用 SEO/分类/结构化选项时可优先使用该模型。留空则不改变默认模型。', 'zhiwrite-ai-writer' ) .
			'</p>';
	}

	public static function field_webhook_enabled() {
		$opts = self::get_options();
		printf(
			'<label><input type="checkbox" name="%1$s[webhook_enabled]" value="1" %2$s /> %3$s</label>',
			esc_attr( self::OPTION_KEY ),
			checked( 1, isset( $opts['webhook_enabled'] ) ? (int) $opts['webhook_enabled'] : 0, false ),
			esc_html__( '生成成功/失败后回调外部系统（异步、低超时）。', 'zhiwrite-ai-writer' )
		);
	}

	public static function field_webhook_url() {
		$opts = self::get_options();
		$val  = isset( $opts['webhook_url'] ) ? (string) $opts['webhook_url'] : '';
		printf(
			'<input type="url" class="large-text" name="%1$s[webhook_url]" value="%2$s" placeholder="%3$s" />',
			esc_attr( self::OPTION_KEY ),
			esc_attr( $val ),
			esc_attr__( '例如：https://example.com/webhook/zhiwrite', 'zhiwrite-ai-writer' )
		);
	}

	public static function field_webhook_secret() {
		$opts = self::get_options();
		$has = ! empty( $opts['webhook_secret'] );
		printf(
			'<input type="password" class="regular-text" name="%1$s[webhook_secret]" value="" autocomplete="new-password" placeholder="%2$s" />',
			esc_attr( self::OPTION_KEY ),
			$has ? esc_attr__( '已保存（不显示）', 'zhiwrite-ai-writer' ) : esc_attr__( '可留空', 'zhiwrite-ai-writer' )
		);
		echo '<div style="margin-top:6px;line-height:1.2;">' .
			'<label class="description"><input type="checkbox" name="' . esc_attr( self::OPTION_KEY ) . '[webhook_clear_secret]" value="1" /> ' .
			esc_html__( '清空密钥', 'zhiwrite-ai-writer' ) .
			'</label>' .
			'</div>';
		echo '<p class="description">' .
			esc_html__( '签名算法：X-ZhiWrite-Signature = sha256 HMAC(body, secret)。', 'zhiwrite-ai-writer' ) .
			'</p>';
	}

	public static function field_webhook_timeout() { self::field_num( 'webhook_timeout', 1, 20 ); }

	public static function field_webhook_retry_enabled() {
		$opts = self::get_options();
		printf(
			'<label><input type="checkbox" name="%1$s[webhook_retry_enabled]" value="1" %2$s /> %3$s</label>',
			esc_attr( self::OPTION_KEY ),
			checked( 1, isset( $opts['webhook_retry_enabled'] ) ? (int) $opts['webhook_retry_enabled'] : 0, false ),
			esc_html__( '当回调失败时，写入队列并按指数退避重试（依赖后台队列/WP-Cron）。', 'zhiwrite-ai-writer' )
		);
		echo '<p class="description">' .
			esc_html__( '提示：建议同时开启“稳定性与性能 -> 后台队列（WP-Cron）”。', 'zhiwrite-ai-writer' ) .
			'</p>';
	}

	public static function field_webhook_retry_max() { self::field_num( 'webhook_retry_max', 0, 20 ); }
	public static function field_webhook_retry_base_sec() { self::field_num( 'webhook_retry_base_sec', 1, 600 ); }
	public static function field_webhook_retry_max_sec() { self::field_num( 'webhook_retry_max_sec', 10, 86400 ); }
	public static function field_webhook_retry_dead_ttl_days() { self::field_num( 'webhook_retry_dead_ttl_days', 1, 365 ); }

	public static function field_fact_check_enabled() {
		$opts = self::get_options();
		printf(
			'<label><input type="checkbox" name="%1$s[fact_check_enabled]" value="1" %2$s /> %3$s</label>',
			esc_attr( self::OPTION_KEY ),
			checked( 1, isset( $opts['fact_check_enabled'] ) ? (int) $opts['fact_check_enabled'] : 0, false ),
			esc_html__( '让模型额外输出“可验证要点清单/引用来源建议”（不保证真实性，仅用于人工核查）。', 'zhiwrite-ai-writer' )
		);
	}
}


