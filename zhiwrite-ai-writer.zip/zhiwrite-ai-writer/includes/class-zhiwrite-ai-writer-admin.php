<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class ZhiWrite_AI_Writer_Admin {
	/** @var int|null */
	private static $smtp_timeout_override = null;

	public static function post_row_actions( $actions, $post ) {
		if ( ! is_array( $actions ) ) {
			return $actions;
		}
		if ( ! $post || ! isset( $post->ID ) ) {
			return $actions;
		}
		if ( 'post' !== (string) $post->post_type ) {
			return $actions;
		}
		if ( ! current_user_can( ZhiWrite_AI_Writer_Settings::capability_generate() ) ) {
			return $actions;
		}
		$post_id = (int) $post->ID;
		if ( $post_id <= 0 || ! current_user_can( 'edit_post', $post_id ) ) {
			return $actions;
		}

		$actions['zhiwrite_generate_tags'] = '<a href="#" class="zhiwrite-generate-tags" data-post-id="' . esc_attr( (string) $post_id ) . '">' . esc_html__( '生成标签', 'zhiwrite-ai-writer' ) . '</a>';
		return $actions;
	}

	private static function task_status_label( $status ) {
		$status = (string) $status;
		$map = array(
			ZhiWrite_AI_Writer_DB::TASK_STATUS_PENDING   => __( '未执行', 'zhiwrite-ai-writer' ),
			ZhiWrite_AI_Writer_DB::TASK_STATUS_RUNNING   => __( '正在执行', 'zhiwrite-ai-writer' ),
			ZhiWrite_AI_Writer_DB::TASK_STATUS_SUCCEEDED => __( '已完成', 'zhiwrite-ai-writer' ),
			ZhiWrite_AI_Writer_DB::TASK_STATUS_FAILED    => __( '失败', 'zhiwrite-ai-writer' ),
			ZhiWrite_AI_Writer_DB::TASK_STATUS_CANCELLED => __( '已取消', 'zhiwrite-ai-writer' ),
		);
		return isset( $map[ $status ] ) ? (string) $map[ $status ] : ( '' !== $status ? $status : __( '未知', 'zhiwrite-ai-writer' ) );
	}

	private static function task_status_badge_html( $status ) {
		$status = (string) $status;
		$label  = self::task_status_label( $status );
		$cls    = 'zhiwrite-status zhiwrite-status--' . preg_replace( '/[^a-z0-9_\-]/', '', strtolower( $status ) );
		return '<span class="' . esc_attr( $cls ) . '">' . esc_html( $label ) . '</span>';
	}

	private static function content_safety_apply( $text, $context = 'content' ) {
		$opts = ZhiWrite_AI_Writer_Settings::get_options();
		if ( empty( $opts['content_safety_enabled'] ) ) {
			return array(
				'ok'      => true,
				'action'  => 'off',
				'text'    => (string) $text,
				'hits'    => array(),
				'message' => '',
			);
		}

		$text = (string) $text;
		$action = isset( $opts['sensitive_action'] ) ? (string) $opts['sensitive_action'] : 'warn';
		$action = in_array( $action, array( 'block', 'replace', 'warn' ), true ) ? $action : 'warn';
		$replace_with = isset( $opts['sensitive_replace_with'] ) ? (string) $opts['sensitive_replace_with'] : '***';
		if ( '' === $replace_with ) {
			$replace_with = '***';
		}

		$list = isset( $opts['sensitive_words'] ) ? (string) $opts['sensitive_words'] : '';
		$list = trim( $list );
		$words = '' !== $list ? preg_split( "/\r\n|\n|\r/", $list ) : array();
		$words = is_array( $words ) ? $words : array();
		$words = array_values(
			array_filter(
				array_map(
					static function ( $w ) {
						return trim( (string) $w );
					},
					$words
				),
				static function ( $w ) {
					return '' !== (string) $w;
				}
			)
		);
		if ( empty( $words ) ) {
			return array(
				'ok'      => true,
				'action'  => 'empty',
				'text'    => $text,
				'hits'    => array(),
				'message' => '',
			);
		}

		$hits = array();
		$out  = $text;
		$max  = 200;
		$i    = 0;
		foreach ( $words as $w ) {
			if ( $i >= $max ) {
				break;
			}
			if ( '' === $w ) {
				continue;
			}
			if ( false !== stripos( $text, $w ) ) {
				$hits[] = $w;
				if ( 'replace' === $action ) {
					$out = str_ireplace( $w, $replace_with, $out );
				}
			}
			$i++;
		}

		$res = array(
			'ok'      => empty( $hits ) || 'block' !== $action,
			'action'  => $action,
			'text'    => ( 'replace' === $action ) ? $out : $text,
			'hits'    => $hits,
			'message' => empty( $hits ) ? '' : sprintf(
				__( '内容安全命中敏感词（%1$s）：%2$s', 'zhiwrite-ai-writer' ),
				(string) $context,
				implode( ', ', array_slice( $hits, 0, 10 ) )
			),
		);

		// Optional external safety checker (fail-open by default).
		if ( ! empty( $opts['safety_external_enabled'] ) ) {
			$ext = self::content_safety_external_check( (string) $res['text'], (string) $context, $opts );
			if ( is_array( $ext ) && isset( $ext['ok'] ) ) {
				// Merge/override decision.
				if ( empty( $ext['ok'] ) ) {
					// external checker says block
					$res['ok']     = false;
					$res['action'] = 'block';
				}
				if ( isset( $ext['action'] ) ) {
					$res['action'] = (string) $ext['action'];
				}
				if ( isset( $ext['text'] ) && is_string( $ext['text'] ) && '' !== $ext['text'] ) {
					$res['text'] = (string) $ext['text'];
				}
				if ( isset( $ext['hits'] ) && is_array( $ext['hits'] ) ) {
					$res['hits'] = array_values( array_unique( array_merge( $res['hits'], $ext['hits'] ) ) );
				}
				if ( isset( $ext['message'] ) && is_string( $ext['message'] ) && '' !== $ext['message'] ) {
					$res['message'] = '' !== (string) $res['message'] ? ( (string) $res['message'] . '；' . (string) $ext['message'] ) : (string) $ext['message'];
				}
			}
		}

		/**
		 * Allow 3rd-party to override/extend content safety decision.
		 *
		 * Return array with keys: ok, action, text, hits, message.
		 */
		$filtered = apply_filters( 'zhiwrite_ai_content_safety_apply', $res, $text, (string) $context, $opts );
		return is_array( $filtered ) ? wp_parse_args( $filtered, $res ) : $res;
	}

	private static function content_safety_external_check( $text, $context, array $opts ) {
		$url = isset( $opts['safety_external_url'] ) ? trim( (string) $opts['safety_external_url'] ) : '';
		if ( '' === $url ) {
			return array();
		}
		$timeout  = isset( $opts['safety_external_timeout'] ) ? (int) $opts['safety_external_timeout'] : 8;
		$timeout  = max( 3, min( 30, $timeout ) );
		$fail_open = ! empty( $opts['safety_external_fail_open'] );

		$payload = array(
			'text'    => (string) $text,
			'context' => (string) $context,
			'site'    => home_url(),
		);

		$resp = wp_remote_post(
			$url,
			array(
				'timeout' => $timeout,
				'headers' => array(
					'Content-Type' => 'application/json',
				),
				'body'    => wp_json_encode( $payload ),
			)
		);

		if ( is_wp_error( $resp ) ) {
			return $fail_open
				? array( 'ok' => true, 'action' => 'warn', 'message' => __( '外部内容安全检测不可用（已降级放行）。', 'zhiwrite-ai-writer' ) )
				: array( 'ok' => false, 'action' => 'block', 'message' => __( '外部内容安全检测不可用（已按严格策略拦截）。', 'zhiwrite-ai-writer' ) );
		}
		$code = (int) wp_remote_retrieve_response_code( $resp );
		$body = (string) wp_remote_retrieve_body( $resp );
		$json = json_decode( $body, true );
		if ( $code < 200 || $code >= 300 || ! is_array( $json ) ) {
			return $fail_open
				? array( 'ok' => true, 'action' => 'warn', 'message' => __( '外部内容安全检测返回异常（已降级放行）。', 'zhiwrite-ai-writer' ) )
				: array( 'ok' => false, 'action' => 'block', 'message' => __( '外部内容安全检测返回异常（已按严格策略拦截）。', 'zhiwrite-ai-writer' ) );
		}

		$ok = isset( $json['ok'] ) ? (bool) $json['ok'] : true;
		$action = isset( $json['action'] ) ? sanitize_key( (string) $json['action'] ) : 'allow';
		$action = in_array( $action, array( 'allow', 'replace', 'block', 'warn' ), true ) ? $action : 'allow';
		$out_action = ( 'allow' === $action ) ? 'warn' : $action; // align with our internal naming
		return array(
			'ok'      => $ok && 'block' !== $action,
			'action'  => $out_action,
			'text'    => isset( $json['text'] ) && is_string( $json['text'] ) ? (string) $json['text'] : '',
			'hits'    => isset( $json['hits'] ) && is_array( $json['hits'] ) ? array_values( $json['hits'] ) : array(),
			'message' => isset( $json['message'] ) ? (string) $json['message'] : '',
		);
	}

	private static function seo_hints( $title, $excerpt, $content, $focus_keyword, $content_format ) {
		$opts = ZhiWrite_AI_Writer_Settings::get_options();
		if ( empty( $opts['seo_rules_enabled'] ) ) {
			return array();
		}
		$title   = trim( (string) $title );
		$excerpt = trim( (string) $excerpt );
		$content = (string) $content;
		$kw      = trim( (string) $focus_keyword );
		$fmt     = (string) $content_format;

		$title_len   = function_exists( 'mb_strlen' ) ? mb_strlen( $title ) : strlen( $title );
		$excerpt_len = function_exists( 'mb_strlen' ) ? mb_strlen( $excerpt ) : strlen( $excerpt );

		$min_t = isset( $opts['seo_title_min'] ) ? (int) $opts['seo_title_min'] : 12;
		$max_t = isset( $opts['seo_title_max'] ) ? (int) $opts['seo_title_max'] : 60;
		$min_e = isset( $opts['seo_excerpt_min'] ) ? (int) $opts['seo_excerpt_min'] : 50;
		$max_e = isset( $opts['seo_excerpt_max'] ) ? (int) $opts['seo_excerpt_max'] : 160;
		$h2min = isset( $opts['seo_h2_min'] ) ? (int) $opts['seo_h2_min'] : 2;
		$kw_min = isset( $opts['seo_kw_per_1000_min'] ) ? (int) $opts['seo_kw_per_1000_min'] : 1;
		$kw_max = isset( $opts['seo_kw_per_1000_max'] ) ? (int) $opts['seo_kw_per_1000_max'] : 20;

		$hints = array();
		if ( $min_t > 0 && $title_len > 0 && $title_len < $min_t ) {
			$hints[] = sprintf( __( '标题偏短：当前 %1$d 字，建议 ≥ %2$d 字。', 'zhiwrite-ai-writer' ), $title_len, $min_t );
		}
		if ( $max_t > 0 && $title_len > $max_t ) {
			$hints[] = sprintf( __( '标题偏长：当前 %1$d 字，建议 ≤ %2$d 字。', 'zhiwrite-ai-writer' ), $title_len, $max_t );
		}
		if ( $min_e > 0 && $excerpt_len > 0 && $excerpt_len < $min_e ) {
			$hints[] = sprintf( __( '摘要（meta 描述）偏短：当前 %1$d 字，建议 ≥ %2$d 字。', 'zhiwrite-ai-writer' ), $excerpt_len, $min_e );
		}
		if ( $max_e > 0 && $excerpt_len > $max_e ) {
			$hints[] = sprintf( __( '摘要（meta 描述）偏长：当前 %1$d 字，建议 ≤ %2$d 字。', 'zhiwrite-ai-writer' ), $excerpt_len, $max_e );
		}

		$h2 = 0;
		$h3 = 0;
		if ( ZhiWrite_AI_Writer_Settings::CONTENT_FORMAT_MARKDOWN === $fmt ) {
			$h2 = preg_match_all( '/^##\s+/m', $content );
			$h3 = preg_match_all( '/^###\s+/m', $content );
		} else {
			$h2 = preg_match_all( '/<h2\b/i', $content );
			$h3 = preg_match_all( '/<h3\b/i', $content );
		}
		if ( $h2min > 0 && $h2 < $h2min ) {
			$hints[] = sprintf( __( '小标题偏少：H2 当前 %1$d 个，建议 ≥ %2$d 个。', 'zhiwrite-ai-writer' ), (int) $h2, (int) $h2min );
		}
		if ( $h2 > 0 && $h3 > 0 && $h3 > ( $h2 * 6 ) ) {
			$hints[] = __( 'H3 数量明显多于 H2：建议检查层级结构，避免过深。', 'zhiwrite-ai-writer' );
		}

		$plain = wp_strip_all_tags( (string) $content );
		$plain = preg_replace( '/\s+/', ' ', (string) $plain );
		$plain_len = function_exists( 'mb_strlen' ) ? mb_strlen( $plain ) : strlen( $plain );
		if ( '' !== $kw && $plain_len > 0 ) {
			$count = substr_count( mb_strtolower( $plain ), mb_strtolower( $kw ) );
			$per1000 = (int) round( ( $count * 1000 ) / max( 1, $plain_len ) );
			if ( $kw_min > 0 && $per1000 < $kw_min ) {
				$hints[] = sprintf( __( '焦点关键词密度偏低：约 %1$d 次/1000 字符（命中 %2$d 次），建议 ≥ %3$d。', 'zhiwrite-ai-writer' ), $per1000, $count, $kw_min );
			}
			if ( $kw_max > 0 && $per1000 > $kw_max ) {
				$hints[] = sprintf( __( '焦点关键词密度偏高：约 %1$d 次/1000 字符（命中 %2$d 次），建议 ≤ %3$d。', 'zhiwrite-ai-writer' ), $per1000, $count, $kw_max );
			}
		} elseif ( '' === $kw ) {
			$hints[] = __( '未提供焦点关键词：建议填写一个核心关键词用于 SEO。', 'zhiwrite-ai-writer' );
		}

		return $hints;
	}

	private static function internal_links_suggest( $title, $focus_keyword, $max ) {
		$max = max( 0, min( 20, (int) $max ) );
		if ( $max <= 0 ) {
			return array();
		}

		$kw = trim( (string) $focus_keyword );
		$q  = $kw;
		if ( '' === $q ) {
			$q = trim( (string) $title );
		}

		$args = array(
			'post_type'           => 'post',
			'post_status'         => 'publish',
			'posts_per_page'      => $max,
			'ignore_sticky_posts' => true,
			'no_found_rows'       => true,
		);
		if ( '' !== $q ) {
			$args['s'] = $q;
		} else {
			$args['orderby'] = 'date';
			$args['order']   = 'DESC';
		}

		$posts = get_posts( $args );
		$out   = array();
		foreach ( $posts as $p ) {
			if ( ! $p || empty( $p->ID ) ) {
				continue;
			}
			$out[] = array(
				'id'    => (int) $p->ID,
				'title' => (string) get_the_title( (int) $p->ID ),
				'url'   => (string) get_permalink( (int) $p->ID ),
			);
		}
		return $out;
	}

	private static function internal_links_apply( $content, $content_format, array $links, $position ) {
		$content  = (string) $content;
		$fmt      = (string) $content_format;
		$position = (string) $position;
		$links    = is_array( $links ) ? $links : array();
		if ( empty( $links ) ) {
			return array( 'content' => $content, 'inserted' => 0 );
		}

		$items = array();
		foreach ( $links as $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}
			$t = isset( $row['title'] ) ? trim( (string) $row['title'] ) : '';
			$u = isset( $row['url'] ) ? trim( (string) $row['url'] ) : '';
			if ( '' === $t || '' === $u ) {
				continue;
			}
			if ( ZhiWrite_AI_Writer_Settings::CONTENT_FORMAT_MARKDOWN === $fmt ) {
				$items[] = '- [' . $t . '](' . $u . ')';
			} else {
				$items[] = '<li><a href="' . esc_url( $u ) . '" target="_blank" rel="noopener">' . esc_html( $t ) . '</a></li>';
			}
		}
		if ( empty( $items ) ) {
			return array( 'content' => $content, 'inserted' => 0 );
		}

		if ( ZhiWrite_AI_Writer_Settings::CONTENT_FORMAT_MARKDOWN === $fmt ) {
			$block  = "\n\n## 相关文章推荐\n\n";
			$block .= implode( "\n", $items ) . "\n";
			if ( 'after_h2_1' === $position ) {
				// Insert after first H2 section header.
				if ( preg_match( '/^##\s.+$/m', $content, $m, PREG_OFFSET_CAPTURE ) ) {
					$off = (int) $m[0][1];
					$eol = strpos( $content, "\n", $off );
					if ( false !== $eol ) {
						$eol += 1;
						$new = substr( $content, 0, $eol ) . $block . substr( $content, $eol );
						return array( 'content' => $new, 'inserted' => count( $items ) );
					}
				}
			}
			return array( 'content' => rtrim( $content ) . $block, 'inserted' => count( $items ) );
		}

		// HTML/WP format.
		$block  = '<div class="zhiwrite-related"><p><strong>' . esc_html__( '相关文章推荐', 'zhiwrite-ai-writer' ) . '</strong></p>';
		$block .= '<ul>' . implode( '', array_map( static function ( $li ) { return (string) $li; }, $items ) ) . '</ul></div>';

		if ( 'after_h2_1' === $position ) {
			$pos = stripos( $content, '<h2' );
			if ( false !== $pos ) {
				$end = stripos( $content, '</h2>', $pos );
				if ( false !== $end ) {
					$end += 5;
					$new = substr( $content, 0, $end ) . $block . substr( $content, $end );
					return array( 'content' => $new, 'inserted' => count( $items ) );
				}
			}
		}
		return array( 'content' => (string) $content . $block, 'inserted' => count( $items ) );
	}

	private static function apply_excerpt_and_lead( array $parsed, $content_format ) {
		$opts = ZhiWrite_AI_Writer_Settings::get_options();
		$fmt  = (string) $content_format;
		$out  = $parsed;

		$content = isset( $out['content'] ) ? (string) $out['content'] : '';
		$excerpt = isset( $out['excerpt'] ) ? trim( (string) $out['excerpt'] ) : '';

		// Auto excerpt when empty.
		if ( empty( $excerpt ) && ! empty( $opts['auto_excerpt_enabled'] ) ) {
			$len = isset( $opts['auto_excerpt_len'] ) ? (int) $opts['auto_excerpt_len'] : 120;
			$len = max( 20, min( 400, $len ) );
			$plain = wp_strip_all_tags( (string) $content );
			$plain = preg_replace( '/\s+/', ' ', (string) $plain );
			$excerpt = function_exists( 'mb_substr' ) ? mb_substr( (string) $plain, 0, $len ) : substr( (string) $plain, 0, $len );
			$excerpt = trim( (string) $excerpt );
			if ( '' !== $excerpt ) {
				$out['excerpt'] = $excerpt;
			}
		}

		// Lead into content (optional).
		if ( ! empty( $opts['lead_enabled'] ) && '' !== $excerpt ) {
			$prefix = isset( $opts['lead_prefix'] ) ? trim( (string) $opts['lead_prefix'] ) : '';
			$lead_text = '' !== $prefix ? ( $prefix . ' ' . $excerpt ) : $excerpt;

			if ( ZhiWrite_AI_Writer_Settings::CONTENT_FORMAT_MARKDOWN === $fmt ) {
				$lead_block = "\n\n> " . $lead_text . "\n\n";
				$content = ltrim( (string) $content );
				if ( 0 !== strpos( $content, '> ' ) ) {
					$out['content'] = $lead_block . $content;
				}
			} else {
				$lead_block = '<p><strong>' . esc_html( $prefix ) . '</strong> ' . esc_html( $excerpt ) . '</p>';
				if ( '' === $prefix ) {
					$lead_block = '<p>' . esc_html( $excerpt ) . '</p>';
				}
				$out['content'] = $lead_block . (string) $content;
			}
		}

		return $out;
	}

	private static function normalize_term_names( $names ) {
		$names = is_array( $names ) ? $names : array();
		$out   = array();
		foreach ( $names as $n ) {
			$n = trim( (string) $n );
			if ( '' === $n ) {
				continue;
			}
			$out[] = $n;
		}
		return array_values( array_unique( $out ) );
	}

	private static function apply_terms_to_post( $post_id, array $categories, array $tags ) {
		$post_id = (int) $post_id;
		if ( $post_id <= 0 ) {
			return array( 'ok' => false, 'message' => 'invalid_post' );
		}
		$opts = ZhiWrite_AI_Writer_Settings::get_options();
		if ( empty( $opts['terms_apply_enabled'] ) ) {
			return array( 'ok' => false, 'message' => 'terms_apply_disabled' );
		}
		$auto_create = ! empty( $opts['terms_auto_create'] );
		$cats = self::normalize_term_names( $categories );
		$tgs  = self::normalize_term_names( $tags );

		$cat_ids = array();
		$cat_skipped = 0;
		foreach ( $cats as $name ) {
			$ex = term_exists( $name, 'category' );
			if ( is_array( $ex ) && isset( $ex['term_id'] ) ) {
				$cat_ids[] = (int) $ex['term_id'];
				continue;
			}
			if ( is_int( $ex ) && $ex > 0 ) {
				$cat_ids[] = (int) $ex;
				continue;
			}
			if ( $auto_create ) {
				$created = wp_insert_term( $name, 'category' );
				if ( is_array( $created ) && isset( $created['term_id'] ) ) {
					$cat_ids[] = (int) $created['term_id'];
				} else {
					$cat_skipped++;
				}
			} else {
				$cat_skipped++;
			}
		}

		$tag_ids = array();
		$tag_skipped = 0;
		foreach ( $tgs as $name ) {
			$ex = term_exists( $name, 'post_tag' );
			if ( is_array( $ex ) && isset( $ex['term_id'] ) ) {
				$tag_ids[] = (int) $ex['term_id'];
				continue;
			}
			if ( is_int( $ex ) && $ex > 0 ) {
				$tag_ids[] = (int) $ex;
				continue;
			}
			if ( $auto_create ) {
				$created = wp_insert_term( $name, 'post_tag' );
				if ( is_array( $created ) && isset( $created['term_id'] ) ) {
					$tag_ids[] = (int) $created['term_id'];
				} else {
					$tag_skipped++;
				}
			} else {
				$tag_skipped++;
			}
		}

		if ( ! empty( $cat_ids ) ) {
			$res1 = wp_set_post_terms( $post_id, $cat_ids, 'category', false );
			if ( is_wp_error( $res1 ) ) {
				return array( 'ok' => false, 'message' => $res1->get_error_message() );
			}
		}
		if ( ! empty( $tag_ids ) ) {
			$res2 = wp_set_post_terms( $post_id, $tag_ids, 'post_tag', false );
			if ( is_wp_error( $res2 ) ) {
				return array( 'ok' => false, 'message' => $res2->get_error_message() );
			}
		}

		// Verify by reading back assigned terms (names) and counting overlaps.
		$cat_names_now = wp_get_post_terms( $post_id, 'category', array( 'fields' => 'names' ) );
		$tag_names_now = wp_get_post_terms( $post_id, 'post_tag', array( 'fields' => 'names' ) );
		$cat_names_now = is_wp_error( $cat_names_now ) || ! is_array( $cat_names_now ) ? array() : $cat_names_now;
		$tag_names_now = is_wp_error( $tag_names_now ) || ! is_array( $tag_names_now ) ? array() : $tag_names_now;
		$cat_names_now = array_map( 'strval', $cat_names_now );
		$tag_names_now = array_map( 'strval', $tag_names_now );
		$cat_written = count( array_intersect( $cats, $cat_names_now ) );
		$tag_written = count( array_intersect( $tgs, $tag_names_now ) );

		return array(
			'ok'          => true,
			'cat_written' => (int) $cat_written,
			'tag_written' => (int) $tag_written,
			'cat_skipped' => (int) $cat_skipped,
			'tag_skipped' => (int) $tag_skipped,
			'auto_create' => $auto_create ? 1 : 0,
		);
	}

	private static function should_require_terms_confirm() {
		$opts = ZhiWrite_AI_Writer_Settings::get_options();
		return ! empty( $opts['terms_require_confirm'] );
	}

	private static function toc_extract_headings( $content, $content_format, $include_h3 ) {
		$content = (string) $content;
		$fmt     = (string) $content_format;
		$include_h3 = (bool) $include_h3;

		$items = array();
		if ( ZhiWrite_AI_Writer_Settings::CONTENT_FORMAT_MARKDOWN === $fmt ) {
			$lines = preg_split( "/\r\n|\n|\r/", $content );
			$lines = is_array( $lines ) ? $lines : array();
			foreach ( $lines as $line ) {
				$line = trim( (string) $line );
				if ( preg_match( '/^(##|###)\s+(.+)$/', $line, $m ) ) {
					$level = '###' === $m[1] ? 3 : 2;
					if ( 3 === $level && ! $include_h3 ) {
						continue;
					}
					$text = trim( (string) $m[2] );
					if ( '' !== $text ) {
						$items[] = array( 'level' => $level, 'text' => $text );
					}
				}
			}
		} else {
			// HTML: match <h2> / <h3>.
			if ( preg_match_all( '/<(h2|h3)\b[^>]*>(.*?)<\/\1>/is', $content, $m, PREG_SET_ORDER ) ) {
				foreach ( $m as $mm ) {
					$tag = isset( $mm[1] ) ? strtolower( (string) $mm[1] ) : '';
					$level = 'h3' === $tag ? 3 : 2;
					if ( 3 === $level && ! $include_h3 ) {
						continue;
					}
					$text = isset( $mm[2] ) ? wp_strip_all_tags( (string) $mm[2] ) : '';
					$text = trim( (string) $text );
					if ( '' !== $text ) {
						$items[] = array( 'level' => $level, 'text' => $text );
					}
				}
			}
		}
		return $items;
	}

	private static function toc_build_block( array $items, $content_format ) {
		$fmt = (string) $content_format;
		if ( empty( $items ) ) {
			return '';
		}

		if ( ZhiWrite_AI_Writer_Settings::CONTENT_FORMAT_MARKDOWN === $fmt ) {
			$out = "\n\n## 目录\n\n";
			foreach ( $items as $it ) {
				$level = isset( $it['level'] ) ? (int) $it['level'] : 2;
				$text  = isset( $it['text'] ) ? (string) $it['text'] : '';
				if ( '' === trim( $text ) ) {
					continue;
				}
				$indent = 3 === $level ? '  ' : '';
				$out .= $indent . '- ' . $text . "\n";
			}
			return $out . "\n";
		}

		$out  = '<div class="zhiwrite-toc"><p><strong>' . esc_html__( '目录', 'zhiwrite-ai-writer' ) . '</strong></p><ul>';
		foreach ( $items as $it ) {
			$level = isset( $it['level'] ) ? (int) $it['level'] : 2;
			$text  = isset( $it['text'] ) ? (string) $it['text'] : '';
			if ( '' === trim( $text ) ) {
				continue;
			}
			$cls = 3 === $level ? ' class="zhiwrite-toc__h3"' : '';
			$out .= '<li' . $cls . '>' . esc_html( $text ) . '</li>';
		}
		$out .= '</ul></div>';
		return $out;
	}

	private static function toc_apply( $content, $content_format, $position, $min_headings, $include_h3 ) {
		$content = (string) $content;
		$items = self::toc_extract_headings( $content, $content_format, (bool) $include_h3 );
		$min_headings = max( 0, min( 50, (int) $min_headings ) );
		if ( $min_headings > 0 && count( $items ) < $min_headings ) {
			return array( 'content' => $content, 'inserted' => 0 );
		}
		$block = self::toc_build_block( $items, $content_format );
		if ( '' === $block ) {
			return array( 'content' => $content, 'inserted' => 0 );
		}

		$pos = (string) $position;
		$fmt = (string) $content_format;

		// Avoid double insert.
		if ( false !== strpos( $content, 'class="zhiwrite-toc"' ) || false !== strpos( $content, "\n\n## 目录\n" ) ) {
			return array( 'content' => $content, 'inserted' => 0 );
		}

		if ( ZhiWrite_AI_Writer_Settings::CONTENT_FORMAT_MARKDOWN === $fmt ) {
			if ( 'after_h2_1' === $pos ) {
				if ( preg_match( '/^##\s.+$/m', $content, $m, PREG_OFFSET_CAPTURE ) ) {
					$off = (int) $m[0][1];
					$eol = strpos( $content, "\n", $off );
					if ( false !== $eol ) {
						$eol += 1;
						$new = substr( $content, 0, $eol ) . $block . substr( $content, $eol );
						return array( 'content' => $new, 'inserted' => count( $items ) );
					}
				}
			}
			// start or after_lead fallback to start.
			return array( 'content' => $block . ltrim( $content ), 'inserted' => count( $items ) );
		}

		// HTML.
		if ( 'after_h2_1' === $pos ) {
			$p = stripos( $content, '<h2' );
			if ( false !== $p ) {
				$end = stripos( $content, '</h2>', $p );
				if ( false !== $end ) {
					$end += 5;
					$new = substr( $content, 0, $end ) . $block . substr( $content, $end );
					return array( 'content' => $new, 'inserted' => count( $items ) );
				}
			}
		}
		return array( 'content' => $block . (string) $content, 'inserted' => count( $items ) );
	}

	private static function faq_normalize( $faq, $max ) {
		$max = max( 1, min( 15, (int) $max ) );
		$faq = is_array( $faq ) ? $faq : array();
		$out = array();
		foreach ( $faq as $row ) {
			if ( count( $out ) >= $max ) {
				break;
			}
			$row = is_array( $row ) ? $row : array();
			$q = isset( $row['q'] ) ? trim( (string) $row['q'] ) : ( isset( $row['question'] ) ? trim( (string) $row['question'] ) : '' );
			$a = isset( $row['a'] ) ? trim( (string) $row['a'] ) : ( isset( $row['answer'] ) ? trim( (string) $row['answer'] ) : '' );
			if ( '' === $q || '' === $a ) {
				continue;
			}
			$out[] = array( 'q' => $q, 'a' => $a );
		}
		return $out;
	}

	private static function faq_build_block( array $faq, $content_format ) {
		$fmt = (string) $content_format;
		if ( empty( $faq ) ) {
			return '';
		}
		if ( ZhiWrite_AI_Writer_Settings::CONTENT_FORMAT_MARKDOWN === $fmt ) {
			$out = "\n\n## FAQ\n\n";
			foreach ( $faq as $it ) {
				$q = isset( $it['q'] ) ? (string) $it['q'] : '';
				$a = isset( $it['a'] ) ? (string) $it['a'] : '';
				if ( '' === trim( $q ) || '' === trim( $a ) ) {
					continue;
				}
				$out .= "### Q：{$q}\n\n{$a}\n\n";
			}
			return $out;
		}
		$out  = '<div class="zhiwrite-faq"><h2>' . esc_html__( 'FAQ', 'zhiwrite-ai-writer' ) . '</h2>';
		foreach ( $faq as $it ) {
			$q = isset( $it['q'] ) ? (string) $it['q'] : '';
			$a = isset( $it['a'] ) ? (string) $it['a'] : '';
			if ( '' === trim( $q ) || '' === trim( $a ) ) {
				continue;
			}
			$out .= '<h3>' . esc_html( 'Q：' . $q ) . '</h3><p>' . esc_html( $a ) . '</p>';
		}
		$out .= '</div>';
		return $out;
	}

	private static function faq_apply( $content, $content_format, array $faq, $position ) {
		$content = (string) $content;
		$fmt = (string) $content_format;
		if ( empty( $faq ) ) {
			return array( 'content' => $content, 'inserted' => 0 );
		}
		// Avoid double insert.
		if ( false !== strpos( $content, 'class="zhiwrite-faq"' ) || false !== strpos( $content, "\n\n## FAQ\n" ) ) {
			return array( 'content' => $content, 'inserted' => 0 );
		}
		$block = self::faq_build_block( $faq, $content_format );
		if ( '' === $block ) {
			return array( 'content' => $content, 'inserted' => 0 );
		}

		$pos = (string) $position;
		if ( 'before_end' === $pos ) {
			// simple heuristic: insert before "免责声明" paragraph if exists.
			if ( ZhiWrite_AI_Writer_Settings::CONTENT_FORMAT_MARKDOWN === $fmt ) {
				$i = mb_stripos( $content, '免责声明' );
				if ( false !== $i ) {
					$new = mb_substr( $content, 0, $i ) . $block . mb_substr( $content, $i );
					return array( 'content' => $new, 'inserted' => count( $faq ) );
				}
			} else {
				$i = stripos( $content, '免责声明' );
				if ( false !== $i ) {
					$new = substr( $content, 0, $i ) . $block . substr( $content, $i );
					return array( 'content' => $new, 'inserted' => count( $faq ) );
				}
			}
		}
		return array( 'content' => (string) rtrim( $content ) . $block, 'inserted' => count( $faq ) );
	}

	private static function precheck_run( $title, $excerpt, $content, $content_format, array $safety ) {
		$opts = ZhiWrite_AI_Writer_Settings::get_options();
		if ( empty( $opts['precheck_enabled'] ) ) {
			return array(
				'enabled' => 0,
				'items'   => array(),
				'passed'  => 1,
			);
		}

		$title   = trim( (string) $title );
		$excerpt = trim( (string) $excerpt );
		$content = (string) $content;
		$fmt     = (string) $content_format;

		$items = array();

		// Excerpt required.
		if ( ! empty( $opts['precheck_require_excerpt'] ) ) {
			$ok = '' !== $excerpt;
			$items[] = array(
				'key'   => 'excerpt',
				'level' => $ok ? 'ok' : 'warn',
				'text'  => $ok ? __( '摘要：已填写', 'zhiwrite-ai-writer' ) : __( '摘要：为空（建议补充 meta 描述）', 'zhiwrite-ai-writer' ),
			);
		}

		// Image required.
		if ( ! empty( $opts['precheck_require_image'] ) ) {
			$has_img = false;
			if ( ZhiWrite_AI_Writer_Settings::CONTENT_FORMAT_MARKDOWN === $fmt ) {
				$has_img = (bool) preg_match( '/!\[[^\]]*\]\([^)]+\)/', $content );
			} else {
				$has_img = false !== stripos( $content, '<img' );
			}
			$items[] = array(
				'key'   => 'image',
				'level' => $has_img ? 'ok' : 'warn',
				'text'  => $has_img ? __( '图片：已包含', 'zhiwrite-ai-writer' ) : __( '图片：未检测到（建议至少插入一张配图）', 'zhiwrite-ai-writer' ),
			);
		}

		// External links max.
		$max_ext = isset( $opts['precheck_external_links_max'] ) ? (int) $opts['precheck_external_links_max'] : 10;
		if ( $max_ext > 0 ) {
			$ext = 0;
			if ( ZhiWrite_AI_Writer_Settings::CONTENT_FORMAT_MARKDOWN === $fmt ) {
				if ( preg_match_all( '/\[[^\]]*\]\((https?:\/\/[^)]+)\)/i', $content, $m ) ) {
					$ext = count( $m[1] );
				}
			} else {
				if ( preg_match_all( '/<a\b[^>]*href=["\'](https?:\/\/[^"\']+)["\']/i', $content, $m ) ) {
					$ext = count( $m[1] );
				}
			}
			$ok = $ext <= $max_ext;
			$items[] = array(
				'key'   => 'external_links',
				'level' => $ok ? 'ok' : 'warn',
				'text'  => $ok
					? sprintf( __( '外链：%1$d（≤ %2$d）', 'zhiwrite-ai-writer' ), $ext, $max_ext )
					: sprintf( __( '外链：%1$d（超出上限 %2$d）', 'zhiwrite-ai-writer' ), $ext, $max_ext ),
				'meta'  => array( 'count' => $ext, 'max' => $max_ext ),
			);
		}

		// Content safety.
		$hits = isset( $safety['hits'] ) && is_array( $safety['hits'] ) ? $safety['hits'] : array();
		if ( ! empty( $hits ) ) {
			$items[] = array(
				'key'   => 'safety',
				'level' => 'warn',
				'text'  => sprintf( __( '内容安全：命中敏感词 %s', 'zhiwrite-ai-writer' ), implode( ', ', array_slice( $hits, 0, 8 ) ) ),
			);
		} else {
			$items[] = array(
				'key'   => 'safety',
				'level' => 'ok',
				'text'  => __( '内容安全：未命中敏感词', 'zhiwrite-ai-writer' ),
			);
		}

		$passed = 1;
		foreach ( $items as $it ) {
			if ( isset( $it['level'] ) && 'warn' === (string) $it['level'] ) {
				$passed = 0;
				break;
			}
		}

		return array(
			'enabled' => 1,
			'items'   => $items,
			'passed'  => $passed,
		);
	}

	private static function cache_key_for_generation( array $parts ) {
		$raw = wp_json_encode( $parts, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );
		return 'zhiwrite_ai_cache_' . md5( (string) $raw );
	}

	private static function cache_get( $key ) {
		$key = (string) $key;
		$v   = get_transient( $key );
		return is_array( $v ) ? $v : null;
	}

	private static function cache_set( $key, array $value, $ttl_seconds ) {
		$key = (string) $key;
		$ttl = max( 60, (int) $ttl_seconds );
		set_transient( $key, $value, $ttl );

		// Track cache keys for "clear cache" tool (best-effort, bounded).
		$idx_key = 'zhiwrite_ai_cache_keys';
		$idx     = get_option( $idx_key, array() );
		$idx     = is_array( $idx ) ? $idx : array();
		$idx[ $key ] = time() + $ttl;
		if ( count( $idx ) > 1500 ) {
			// Drop expired first, then trim oldest.
			$now = time();
			foreach ( $idx as $k => $exp ) {
				if ( (int) $exp > 0 && (int) $exp < $now ) {
					unset( $idx[ $k ] );
				}
			}
			if ( count( $idx ) > 1500 ) {
				asort( $idx ); // oldest expiry first
				$idx = array_slice( $idx, -1200, null, true );
			}
		}
		update_option( $idx_key, $idx, false );
	}

	private static function cb_state_key( $api_base_url, $model ) {
		return 'zhiwrite_ai_cb_' . md5( (string) $api_base_url . '|' . (string) $model );
	}

	private static function cb_get_state( $api_base_url, $model ) {
		$k = self::cb_state_key( $api_base_url, $model );
		$s = get_transient( $k );
		return is_array( $s ) ? $s : array( 'fails' => 0, 'open_until' => 0 );
	}

	private static function cb_mark_success( $api_base_url, $model ) {
		$k = self::cb_state_key( $api_base_url, $model );
		set_transient( $k, array( 'fails' => 0, 'open_until' => 0 ), 12 * HOUR_IN_SECONDS );
	}

	private static function cb_mark_failure( $api_base_url, $model, array $opts ) {
		$threshold = isset( $opts['failover_fail_threshold'] ) ? (int) $opts['failover_fail_threshold'] : 2;
		$threshold = max( 1, min( 10, $threshold ) );
		$cooldown  = isset( $opts['failover_cooldown_sec'] ) ? (int) $opts['failover_cooldown_sec'] : 300;
		$cooldown  = max( 30, min( 86400, $cooldown ) );

		$k = self::cb_state_key( $api_base_url, $model );
		$s = self::cb_get_state( $api_base_url, $model );
		$f = isset( $s['fails'] ) ? (int) $s['fails'] : 0;
		$f++;
		$open_until = isset( $s['open_until'] ) ? (int) $s['open_until'] : 0;
		if ( $f >= $threshold ) {
			$open_until = time() + $cooldown;
		}
		set_transient( $k, array( 'fails' => $f, 'open_until' => $open_until ), 12 * HOUR_IN_SECONDS );
	}

	private static function call_upstream_with_failover( array $primary_iface, $model, $system, $user, array $opts, $content_format, $do_seo, $do_terms, $do_disc ) {
		$interfaces = isset( $opts['interfaces'] ) && is_array( $opts['interfaces'] ) ? $opts['interfaces'] : array();
		$candidates = array();

		// Primary first.
		if ( ! empty( $primary_iface ) ) {
			$candidates[] = $primary_iface;
		}
		// Then others.
		foreach ( $interfaces as $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}
			$api_base_url = isset( $row['api_base_url'] ) ? (string) $row['api_base_url'] : '';
			if ( '' === trim( $api_base_url ) ) {
				continue;
			}
			if ( isset( $primary_iface['api_base_url'] ) && (string) $primary_iface['api_base_url'] === (string) $api_base_url ) {
				continue;
			}
			$candidates[] = $row;
		}

		$enable_failover = ! empty( $opts['failover_enabled'] );
		$attempted = array();
		$last = array(
			'ok'         => false,
			'text'       => '',
			'raw'        => array(),
			'error'      => __( '请求失败。', 'zhiwrite-ai-writer' ),
			'error_code' => 'upstream_failed',
			'meta'       => array(),
		);

		foreach ( $candidates as $idx => $iface ) {
			if ( $idx > 0 && ! $enable_failover ) {
				break;
			}
			$api_base_url = isset( $iface['api_base_url'] ) ? (string) $iface['api_base_url'] : '';
			$api_key      = isset( $iface['api_key'] ) ? (string) $iface['api_key'] : '';
			if ( '' === trim( $api_base_url ) || '' === trim( $api_key ) ) {
				continue;
			}

			// Circuit breaker.
			$state = self::cb_get_state( $api_base_url, $model );
			$open_until = isset( $state['open_until'] ) ? (int) $state['open_until'] : 0;
			if ( $open_until > time() ) {
				continue;
			}

			$attempted[] = $api_base_url;
			$res = ZhiWrite_AI_Writer_API::chat_completions(
				array(
					'api_base_url' => $api_base_url,
					'api_key'      => $api_key,
					'model'        => (string) $model,
					'timeout'      => (int) $opts['timeout'],
					'retry_times'  => isset( $opts['retry_times'] ) ? (int) $opts['retry_times'] : 0,
					'retry_backoff_ms' => isset( $opts['retry_backoff_ms'] ) ? (int) $opts['retry_backoff_ms'] : 0,
					'messages'     => array(
						array( 'role' => 'system', 'content' => (string) $system ),
						array( 'role' => 'user', 'content' => (string) $user ),
					),
				)
			);

			if ( ! empty( $res['ok'] ) ) {
				self::cb_mark_success( $api_base_url, $model );
				$res['meta']['failover_used'] = ( $idx > 0 ) ? 1 : 0;
				$res['meta']['attempted'] = $attempted;
				$res['meta']['chosen_api_base_url'] = $api_base_url;
				return array( 'api_res' => $res, 'iface' => $iface );
			}

			self::cb_mark_failure( $api_base_url, $model, $opts );
			$last = is_array( $res ) ? $res : $last;
			$last['meta']['attempted'] = $attempted;
			$last['meta']['failover_used'] = ( $idx > 0 ) ? 1 : 0;
			$last['meta']['chosen_api_base_url'] = $api_base_url;
		}

		return array( 'api_res' => $last, 'iface' => $primary_iface, 'attempted' => $attempted );
	}

	private static function maybe_route_model( $model, $prompt, $do_seo, $do_terms, $do_disc, array $opts ) {
		$model = (string) $model;
		if ( empty( $opts['model_router_enabled'] ) ) {
			return $model;
		}
		$prompt = (string) $prompt;
		$len = function_exists( 'mb_strlen' ) ? mb_strlen( $prompt ) : strlen( $prompt );

		// SEO/structure tasks.
		if ( ( $do_seo || $do_terms || $do_disc ) && ! empty( $opts['model_router_seo_model'] ) ) {
			return (string) $opts['model_router_seo_model'];
		}

		// Long prompt tasks.
		$th = isset( $opts['model_router_long_threshold'] ) ? (int) $opts['model_router_long_threshold'] : 2500;
		if ( $th > 0 && $len >= $th && ! empty( $opts['model_router_long_model'] ) ) {
			return (string) $opts['model_router_long_model'];
		}

		return $model;
	}

	private static function webhook_send( $event, array $payload ) {
		$opts = ZhiWrite_AI_Writer_Settings::get_options();
		if ( empty( $opts['webhook_enabled'] ) ) {
			return;
		}
		$url = isset( $opts['webhook_url'] ) ? trim( (string) $opts['webhook_url'] ) : '';
		if ( '' === $url ) {
			return;
		}
		$timeout = isset( $opts['webhook_timeout'] ) ? (int) $opts['webhook_timeout'] : 3;
		$timeout = max( 1, min( 20, $timeout ) );
		$secret  = isset( $opts['webhook_secret'] ) ? (string) $opts['webhook_secret'] : '';

		$body_arr = array(
			'event' => (string) $event,
			'site'  => home_url(),
			'ts'    => time(),
			'data'  => $payload,
		);
		$body = wp_json_encode( $body_arr, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );
		$headers = array(
			'Content-Type' => 'application/json',
		);
		if ( '' !== $secret ) {
			$headers['X-ZhiWrite-Signature'] = hash_hmac( 'sha256', (string) $body, (string) $secret );
		}

		$started = microtime( true );
		// Use blocking request so we can record http code/elapsed/resp snippet for webhook logs panel.
		$resp = wp_remote_post(
			$url,
			array(
				'timeout'  => $timeout,
				'blocking' => true,
				'headers'  => $headers,
				'body'     => $body,
			)
		);
		$elapsed_ms = (int) round( ( microtime( true ) - $started ) * 1000 );

		$code = 0;
		$err  = '';
		if ( is_wp_error( $resp ) ) {
			$err = $resp->get_error_message();
			self::maybe_log(
				array(
					'action' => 'webhook_error',
					'meta'   => wp_json_encode(
						array(
							'event' => (string) $event,
							'url'   => $url,
							'err'   => $err,
							'elapsed_ms' => $elapsed_ms,
						),
						JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
					),
				)
			);
			self::webhook_retry_enqueue( $event, $body_arr, $body, $headers, $url, 0, $err, $opts );
			return;
		}

		$code = (int) wp_remote_retrieve_response_code( $resp );
		$resp_body = (string) wp_remote_retrieve_body( $resp );
		$resp_body = (string) substr( $resp_body, 0, 800 );

		if ( $code >= 200 && $code < 300 ) {
			self::maybe_log(
				array(
					'action' => 'webhook_send',
					'meta'   => wp_json_encode(
						array(
							'event'            => (string) $event,
							'url'              => $url,
							'http_code'         => $code,
							'resp'             => (string) $resp_body,
							'elapsed_ms'        => $elapsed_ms,
							'signature_enabled' => ( '' !== $secret ) ? 1 : 0,
						),
						JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
					),
				)
			);
			return;
		}

		if ( $code < 200 || $code >= 300 ) {
			$resp_body = (string) wp_remote_retrieve_body( $resp );
			$resp_body = (string) substr( $resp_body, 0, 800 );
			self::maybe_log(
				array(
					'action' => 'webhook_error',
					'meta'   => wp_json_encode(
						array(
							'event' => (string) $event,
							'url'   => $url,
							'http_code' => $code,
							'resp' => $resp_body,
							'elapsed_ms' => $elapsed_ms,
							'signature_enabled' => ( '' !== $secret ) ? 1 : 0,
						),
						JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
					),
				)
			);
			self::webhook_retry_enqueue( $event, $body_arr, $body, $headers, $url, $code, '', $opts );
			return;
		}
	}

	public static function render_webhook_logs_page() {
		if ( ! current_user_can( ZhiWrite_AI_Writer_Settings::capability_logs() ) ) {
			wp_die( esc_html__( '权限不足。', 'zhiwrite-ai-writer' ) );
		}
		?>
		<div class="wrap zhiwrite-ai-wrap">
			<h1><?php echo esc_html__( '智写AI - Webhook 日志', 'zhiwrite-ai-writer' ); ?></h1>
			<p class="description" style="margin:8px 0 14px;">
				<?php echo esc_html__( '展示最近 Webhook 回调记录（耗时/HTTP 状态/响应片段截断脱敏/是否启用签名）。', 'zhiwrite-ai-writer' ); ?>
			</p>
			<div class="zhiwrite-td-card">
				<div class="zhiwrite-td-card__body">
					<p>
						<button class="button button-secondary" id="zhiwrite-webhook-logs-refresh"><?php echo esc_html__( '刷新', 'zhiwrite-ai-writer' ); ?></button>
					</p>
					<table class="widefat striped">
						<thead>
							<tr>
								<th style="width:170px;"><?php echo esc_html__( '时间', 'zhiwrite-ai-writer' ); ?></th>
								<th style="width:120px;"><?php echo esc_html__( '事件', 'zhiwrite-ai-writer' ); ?></th>
								<th style="width:90px;"><?php echo esc_html__( 'HTTP', 'zhiwrite-ai-writer' ); ?></th>
								<th style="width:90px;"><?php echo esc_html__( '耗时(ms)', 'zhiwrite-ai-writer' ); ?></th>
								<th style="width:90px;"><?php echo esc_html__( '签名', 'zhiwrite-ai-writer' ); ?></th>
								<th><?php echo esc_html__( 'URL / 响应片段', 'zhiwrite-ai-writer' ); ?></th>
							</tr>
						</thead>
						<tbody id="zhiwrite-webhook-logs-tbody">
							<tr><td colspan="6"><?php echo esc_html__( '加载中…', 'zhiwrite-ai-writer' ); ?></td></tr>
						</tbody>
					</table>
					<p class="description" style="margin-top:10px;">
						<?php echo esc_html__( '说明：响应片段最多展示 800 字符；仅用于诊断。', 'zhiwrite-ai-writer' ); ?>
					</p>
				</div>
			</div>
		</div>
		<?php
	}

	public static function ajax_webhook_logs() {
		if ( ! current_user_can( ZhiWrite_AI_Writer_Settings::capability_logs() ) ) {
			wp_send_json_error( array( 'message' => __( '权限不足。', 'zhiwrite-ai-writer' ) ), 403 );
		}
		check_ajax_referer( 'zhiwrite_ai_nonce', 'nonce' );

		$rows = ZhiWrite_AI_Writer_DB::get_logs( 100, 0, array() );
		$out  = array();
		foreach ( $rows as $r ) {
			$action = isset( $r['action'] ) ? (string) $r['action'] : '';
			if ( ! in_array( $action, array( 'webhook_send', 'webhook_error', 'webhook_retry_ok', 'webhook_retry_error' ), true ) ) {
				continue;
			}
			$meta = array();
			if ( ! empty( $r['meta'] ) ) {
				$meta = json_decode( (string) $r['meta'], true );
			}
			$meta = is_array( $meta ) ? $meta : array();
			$out[] = array(
				'created_at' => isset( $r['created_at'] ) ? (string) $r['created_at'] : '',
				'action'     => $action,
				'event'      => isset( $meta['event'] ) ? (string) $meta['event'] : '',
				'url'        => isset( $meta['url'] ) ? (string) $meta['url'] : '',
				'http_code'  => isset( $meta['http_code'] ) ? (int) $meta['http_code'] : 0,
				'elapsed_ms' => isset( $meta['elapsed_ms'] ) ? (int) $meta['elapsed_ms'] : 0,
				'signature_enabled' => ! empty( $meta['signature_enabled'] ) ? 1 : 0,
				'resp'       => isset( $meta['resp'] ) ? (string) $meta['resp'] : '',
				'err'        => isset( $meta['err'] ) ? (string) $meta['err'] : '',
				'attempt'    => isset( $meta['attempt'] ) ? (int) $meta['attempt'] : 0,
				'max'        => isset( $meta['max'] ) ? (int) $meta['max'] : 0,
			);
			if ( count( $out ) >= 100 ) {
				break;
			}
		}

		wp_send_json_success( array( 'rows' => $out ) );
	}

	public static function ajax_clear_cache() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( '权限不足。', 'zhiwrite-ai-writer' ) ), 403 );
		}
		check_ajax_referer( 'zhiwrite_ai_nonce', 'nonce' );

		$idx_key = 'zhiwrite_ai_cache_keys';
		$idx = get_option( $idx_key, array() );
		$idx = is_array( $idx ) ? $idx : array();

		$deleted = 0;
		foreach ( $idx as $k => $exp ) {
			$k = (string) $k;
			if ( '' === $k || 0 !== strpos( $k, 'zhiwrite_ai_cache_' ) ) {
				continue;
			}
			if ( delete_transient( $k ) ) {
				$deleted++;
			} else {
				// Even if already expired/missing, count it as cleaned from index.
				$deleted++;
			}
		}
		update_option( $idx_key, array(), false );

		wp_send_json_success(
			array(
				'message' => sprintf( __( '已清理缓存：%d 条。', 'zhiwrite-ai-writer' ), (int) $deleted ),
			)
		);
	}

	private static function webhook_retry_enqueue( $event, array $body_arr, $body, array $headers, $url, $http_code, $err, array $opts ) {
		if ( empty( $opts['webhook_retry_enabled'] ) ) {
			return;
		}
		if ( empty( $opts['enable_queue'] ) ) {
			// Retry queue depends on WP-Cron queue.
			return;
		}
		$max = isset( $opts['webhook_retry_max'] ) ? (int) $opts['webhook_retry_max'] : 6;
		if ( $max <= 0 ) {
			return;
		}
		$base = isset( $opts['webhook_retry_base_sec'] ) ? (int) $opts['webhook_retry_base_sec'] : 10;
		$base = max( 1, min( 600, $base ) );
		$max_delay = isset( $opts['webhook_retry_max_sec'] ) ? (int) $opts['webhook_retry_max_sec'] : 1800;
		$max_delay = max( 10, min( 86400, $max_delay ) );

		$req_id = 'wh_' . gmdate( 'Ymd_His' ) . '_' . wp_generate_password( 8, false, false );
		$next_ts = time() + $base;
		$payload = array(
			'task_type'  => 'webhook_retry',
			'event'      => (string) $event,
			'url'        => (string) $url,
			'headers'    => $headers,
			'body_arr'   => $body_arr,
			'body'       => (string) $body,
			'http_code'  => (int) $http_code,
			'err'        => (string) $err,
			'max'        => (int) $max,
			'base'       => (int) $base,
			'max_delay'  => (int) $max_delay,
			'next_ts'    => (int) $next_ts,
		);

		ZhiWrite_AI_Writer_DB::insert_task(
			array(
				'request_id' => (string) $req_id,
				'user_id'    => get_current_user_id(),
				'status'     => ZhiWrite_AI_Writer_DB::TASK_STATUS_PENDING,
				'progress'   => 1,
				'message'    => __( 'Webhook 失败：已进入重试队列…', 'zhiwrite-ai-writer' ),
				'payload'    => wp_json_encode( $payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ),
			)
		);
		self::maybe_schedule_queue();
	}
	private static function budget_notice_key() {
		return 'zhiwrite_ai_budget_notice_' . gmdate( 'Ymd' );
	}

	private static function budget_should_block( array $opts ) {
		if ( empty( $opts['budget_enabled'] ) ) {
			return array( 'block' => false );
		}

		$max_reqs   = isset( $opts['budget_daily_requests'] ) ? (int) $opts['budget_daily_requests'] : 0;
		$max_tokens = isset( $opts['budget_daily_tokens'] ) ? (int) $opts['budget_daily_tokens'] : 0;

		if ( $max_reqs <= 0 && $max_tokens <= 0 ) {
			return array( 'block' => false );
		}

		global $wpdb;
		$table = ZhiWrite_AI_Writer_DB::logs_table();
		$day0  = gmdate( 'Y-m-d 00:00:00' );

		// Requests.
		$reqs = 0;
		if ( $max_reqs > 0 ) {
			// Count all successful AI calls (any action with tokens recorded).
			$sql = "SELECT COUNT(*) FROM {$table} WHERE created_at >= %s AND total_tokens > 0";
			// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
			$reqs = (int) $wpdb->get_var( $wpdb->prepare( $sql, $day0 ) );
			if ( $reqs >= $max_reqs ) {
				return array(
					'block'  => true,
					'reason' => 'requests',
					'cur'    => $reqs,
					'max'    => $max_reqs,
				);
			}
		}

		// Tokens (only meaningful when upstream provides usage; otherwise will be 0).
		if ( $max_tokens > 0 ) {
			$sql2 = "SELECT SUM(total_tokens) FROM {$table} WHERE created_at >= %s AND total_tokens > 0";
			// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
			$sum_tokens = (int) $wpdb->get_var( $wpdb->prepare( $sql2, $day0 ) );
			if ( $sum_tokens >= $max_tokens ) {
				return array(
					'block'  => true,
					'reason' => 'tokens',
					'cur'    => $sum_tokens,
					'max'    => $max_tokens,
				);
			}
		}

		return array( 'block' => false );
	}

	private static function budget_maybe_notify( array $opts, array $block_info ) {
		if ( empty( $block_info['block'] ) ) {
			return;
		}
		$key = self::budget_notice_key();
		if ( get_transient( $key ) ) {
			return;
		}
		// 12 hours is enough; key contains date anyway.
		set_transient( $key, 1, 12 * HOUR_IN_SECONDS );

		$reason = isset( $block_info['reason'] ) ? (string) $block_info['reason'] : '';
		$cur    = isset( $block_info['cur'] ) ? (int) $block_info['cur'] : 0;
		$max    = isset( $block_info['max'] ) ? (int) $block_info['max'] : 0;

		// Email notify.
		if ( ! empty( $opts['budget_notify_email'] ) ) {
			$to      = get_option( 'admin_email' );
			$subject = '【智写AI】预算阈值已触发';
			$metric  = ( 'tokens' === $reason ) ? 'tokens' : '请求数';
			$body    = "站点用量已达到预算阈值，生成将被拦截。\n\n指标：{$metric}\n当前：{$cur}\n阈值：{$max}\n\n可在后台「智写AI -> 功能配置」调整预算阈值，或在「智写AI -> 用量统计」查看明细。";
			if ( is_string( $to ) && '' !== trim( $to ) ) {
				self::send_mail( (string) $to, (string) $subject, (string) $body, 'send' );
			}
		}
	}

	/**
	 * Send plugin email using either system wp_mail or plugin SMTP config.
	 *
	 * @param string $to
	 * @param string $subject
	 * @param string $body
	 * @return bool
	 */
	private static function send_mail( $to, $subject, $body, $context = 'send' ) {
		$opts = ZhiWrite_AI_Writer_Settings::get_options();
		$mode = isset( $opts['mail_mode'] ) ? (string) $opts['mail_mode'] : 'system';
		$mode = in_array( $mode, array( 'system', 'smtp' ), true ) ? $mode : 'system';
		$context = in_array( (string) $context, array( 'test', 'send' ), true ) ? (string) $context : 'send';

		$headers = array();
		$from_email = isset( $opts['mail_from_email'] ) ? trim( (string) $opts['mail_from_email'] ) : '';
		$from_name  = isset( $opts['mail_from_name'] ) ? trim( (string) $opts['mail_from_name'] ) : '';
		if ( '' !== $from_email ) {
			$h = 'From: ';
			if ( '' !== $from_name ) {
				$h .= $from_name . ' <' . $from_email . '>';
			} else {
				$h .= $from_email;
			}
			$headers[] = $h;
		}

		$hooked = false;
		if ( 'smtp' === $mode ) {
			$hooked = true;
			$timeout = ( 'test' === $context )
				? ( isset( $opts['smtp_timeout_test'] ) ? (int) $opts['smtp_timeout_test'] : 10 )
				: ( isset( $opts['smtp_timeout_send'] ) ? (int) $opts['smtp_timeout_send'] : 15 );
			self::$smtp_timeout_override = max( 3, min( 120, (int) $timeout ) );
			add_action( 'phpmailer_init', array( __CLASS__, 'configure_phpmailer_smtp' ), 20, 1 );
		}
		$ok = @wp_mail( (string) $to, (string) $subject, (string) $body, $headers );
		if ( $hooked ) {
			remove_action( 'phpmailer_init', array( __CLASS__, 'configure_phpmailer_smtp' ), 20 );
			self::$smtp_timeout_override = null;
		}
		return (bool) $ok;
	}

	/**
	 * Configure PHPMailer to use SMTP for this wp_mail call.
	 *
	 * @param PHPMailer $phpmailer
	 * @return void
	 */
	public static function configure_phpmailer_smtp( $phpmailer ) {
		if ( ! is_object( $phpmailer ) ) {
			return;
		}
		$opts = ZhiWrite_AI_Writer_Settings::get_options();
		$mode = isset( $opts['mail_mode'] ) ? (string) $opts['mail_mode'] : 'system';
		if ( 'smtp' !== $mode ) {
			return;
		}

		$host = isset( $opts['smtp_host'] ) ? trim( (string) $opts['smtp_host'] ) : '';
		$port = isset( $opts['smtp_port'] ) ? (int) $opts['smtp_port'] : 587;
		$enc  = isset( $opts['smtp_encryption'] ) ? (string) $opts['smtp_encryption'] : 'tls';
		$user = isset( $opts['smtp_username'] ) ? (string) $opts['smtp_username'] : '';
		$pass = isset( $opts['smtp_password'] ) ? (string) $opts['smtp_password'] : '';

		if ( '' === $host ) {
			return;
		}

		// phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase
		$phpmailer->isSMTP();
		// phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase
		$phpmailer->Host = $host;
		// phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase
		$phpmailer->Port = max( 1, min( 65535, (int) $port ) );
		// phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase
		$phpmailer->SMTPAuth = ( '' !== (string) $user || '' !== (string) $pass );
		if ( $phpmailer->SMTPAuth ) {
			// phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase
			$phpmailer->Username = $user;
			// phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase
			$phpmailer->Password = $pass;
		}
		if ( 'none' === $enc ) {
			// phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase
			$phpmailer->SMTPSecure = '';
		} else {
			// phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase
			$phpmailer->SMTPSecure = $enc;
		}

		// Timeout (connection/transaction). Applies to SMTP.
		$timeout = is_int( self::$smtp_timeout_override ) ? (int) self::$smtp_timeout_override : 0;
		if ( $timeout > 0 ) {
			// phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase
			$phpmailer->Timeout = $timeout;
			// phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase
			$phpmailer->Timelimit = $timeout;
		}
	}
	/**
	 * Concurrency lock keys.
	 */
	private static function gen_lock_user_key( $user_id ) {
		return 'zhiwrite_ai_gen_lock_u_' . (int) $user_id;
	}

	private static function gen_lock_global_key() {
		return 'zhiwrite_ai_gen_lock_global';
	}

	/**
	 * Acquire a best-effort generation lock (per-user + global).
	 *
	 * @param int    $user_id
	 * @param string $request_id
	 * @param array  $opts
	 * @return array { ok:bool, lock:array, message:string, meta:array }
	 */
	private static function acquire_generation_lock( $user_id, $request_id, array $opts ) {
		$user_id  = (int) $user_id;
		$now      = time();
		$ttl      = isset( $opts['concurrency_lock_ttl'] ) ? max( 60, (int) $opts['concurrency_lock_ttl'] ) : 900;
		$user_max = isset( $opts['concurrency_user_max'] ) ? max( 1, (int) $opts['concurrency_user_max'] ) : 1;
		$g_max    = isset( $opts['concurrency_global_max'] ) ? max( 1, (int) $opts['concurrency_global_max'] ) : 3;

		$user_key   = self::gen_lock_user_key( $user_id );
		$global_key = self::gen_lock_global_key();

		$user_state = get_transient( $user_key );
		$user_state = is_array( $user_state ) ? $user_state : array();
		if ( empty( $user_state['items'] ) || ! is_array( $user_state['items'] ) ) {
			$user_state['items'] = array();
		}
		// Prune expired.
		foreach ( $user_state['items'] as $rid => $exp ) {
			if ( (int) $exp <= $now ) {
				unset( $user_state['items'][ $rid ] );
			}
		}

		$global_state = get_transient( $global_key );
		$global_state = is_array( $global_state ) ? $global_state : array();
		if ( empty( $global_state['items'] ) || ! is_array( $global_state['items'] ) ) {
			$global_state['items'] = array();
		}
		foreach ( $global_state['items'] as $k => $row ) {
			$row = is_array( $row ) ? $row : array();
			$exp = isset( $row['expires_at'] ) ? (int) $row['expires_at'] : 0;
			if ( $exp <= $now ) {
				unset( $global_state['items'][ $k ] );
			}
		}

		$user_count   = count( $user_state['items'] );
		$global_count = count( $global_state['items'] );

		if ( $user_count >= $user_max ) {
			$next_exp = 0;
			foreach ( $user_state['items'] as $exp ) {
				$next_exp = 0 === $next_exp ? (int) $exp : min( $next_exp, (int) $exp );
			}
			$wait = $next_exp > $now ? ( $next_exp - $now ) : 0;
			return array(
				'ok'      => false,
				'lock'    => array(),
				'message' => sprintf( __( '你已有生成任务正在运行，请等待（预计 %d 秒内可重试）。', 'zhiwrite-ai-writer' ), (int) $wait ),
				'meta'    => array(
					'reason'       => 'user_busy',
					'user_max'     => $user_max,
					'user_count'   => $user_count,
					'global_max'   => $g_max,
					'global_count' => $global_count,
					'wait_sec'     => (int) $wait,
				),
			);
		}

		if ( $global_count >= $g_max ) {
			// Best-effort: estimate wait based on earliest expiry.
			$next_exp = 0;
			foreach ( $global_state['items'] as $row ) {
				$exp = isset( $row['expires_at'] ) ? (int) $row['expires_at'] : 0;
				if ( $exp > 0 ) {
					$next_exp = 0 === $next_exp ? $exp : min( $next_exp, $exp );
				}
			}
			$wait = $next_exp > $now ? ( $next_exp - $now ) : 0;
			return array(
				'ok'      => false,
				'lock'    => array(),
				'message' => sprintf( __( '当前生成任务较多（全站繁忙），请稍后重试（预计 %d 秒内可重试）。', 'zhiwrite-ai-writer' ), (int) $wait ),
				'meta'    => array(
					'reason'       => 'global_busy',
					'user_max'     => $user_max,
					'user_count'   => $user_count,
					'global_max'   => $g_max,
					'global_count' => $global_count,
					'wait_sec'     => (int) $wait,
				),
			);
		}

		$expires_at = $now + $ttl;
		$user_state['items'][ (string) $request_id ] = $expires_at;
		set_transient( $user_key, $user_state, $ttl );

		$global_state['items'][ (string) $request_id ] = array(
			'user_id'    => $user_id,
			'request_id' => (string) $request_id,
			'expires_at' => $expires_at,
		);
		set_transient( $global_key, $global_state, $ttl );

		return array(
			'ok'   => true,
			'lock' => array(
				'user_id'    => $user_id,
				'request_id' => (string) $request_id,
				'ttl'        => $ttl,
			),
		);
	}

	/**
	 * Release a previously acquired generation lock.
	 *
	 * @param array $lock
	 * @return void
	 */
	private static function release_generation_lock( array $lock ) {
		$user_id    = isset( $lock['user_id'] ) ? (int) $lock['user_id'] : 0;
		$request_id = isset( $lock['request_id'] ) ? (string) $lock['request_id'] : '';
		if ( $user_id <= 0 || '' === $request_id ) {
			return;
		}

		$user_key   = self::gen_lock_user_key( $user_id );
		$global_key = self::gen_lock_global_key();

		$user_state = get_transient( $user_key );
		$user_state = is_array( $user_state ) ? $user_state : array();
		if ( isset( $user_state['items'] ) && is_array( $user_state['items'] ) ) {
			unset( $user_state['items'][ $request_id ] );
			// If empty, delete to reduce clutter.
			if ( empty( $user_state['items'] ) ) {
				delete_transient( $user_key );
			} else {
				// Keep remaining locks.
				set_transient( $user_key, $user_state, 10 * MINUTE_IN_SECONDS );
			}
		}

		$global_state = get_transient( $global_key );
		$global_state = is_array( $global_state ) ? $global_state : array();
		if ( isset( $global_state['items'] ) && is_array( $global_state['items'] ) ) {
			unset( $global_state['items'][ $request_id ] );
			if ( empty( $global_state['items'] ) ) {
				delete_transient( $global_key );
			} else {
				set_transient( $global_key, $global_state, 10 * MINUTE_IN_SECONDS );
			}
		}
	}
	// (streaming-related helpers and endpoints removed; only direct output is kept)

	/**
	 * Generation status (non-stream) helper.
	 * We store status in transient so the UI can poll and show real progress/heartbeats.
	 */
	private static function generation_status_key( $request_id, $user_id = null ) {
		$user_id    = null === $user_id ? get_current_user_id() : (int) $user_id;
		$request_id = sanitize_key( (string) $request_id );
		return 'zhiwrite_ai_gen_status_' . (int) $user_id . '_' . $request_id;
	}

	private static function generation_status_update( $request_id, $stage, $message = '', $percent = null, $user_id = null ) {
		if ( '' === (string) $request_id ) {
			return;
		}
		$key        = self::generation_status_key( $request_id, $user_id );
		$prev       = get_transient( $key );
		$started_at = is_array( $prev ) && isset( $prev['started_at'] ) ? (int) $prev['started_at'] : time();

		$data = array(
			'request_id' => (string) $request_id,
			'stage'      => sanitize_key( (string) $stage ),
			'message'    => (string) $message,
			'percent'    => is_null( $percent ) ? null : (int) $percent,
			'started_at' => $started_at,
			'updated_at' => time(),
		);
		// 10 minutes should cover most runs, and avoids stale state lingering too long.
		set_transient( $key, $data, 10 * MINUTE_IN_SECONDS );
	}

	private static function generation_status_clear( $request_id, $user_id = null ) {
		if ( '' === (string) $request_id ) {
			return;
		}
		delete_transient( self::generation_status_key( $request_id, $user_id ) );
	}

	public static function ajax_generation_status() {
		if ( ! current_user_can( ZhiWrite_AI_Writer_Settings::capability_generate() ) ) {
			wp_send_json_error( array( 'message' => __( '权限不足。', 'zhiwrite-ai-writer' ) ), 403 );
		}
		check_ajax_referer( 'zhiwrite_ai_nonce', 'nonce' );

		$request_id = isset( $_POST['request_id'] ) ? sanitize_key( (string) wp_unslash( $_POST['request_id'] ) ) : '';
		if ( '' === $request_id ) {
			wp_send_json_error( array( 'message' => __( '参数错误。', 'zhiwrite-ai-writer' ) ), 400 );
		}

		$data = get_transient( self::generation_status_key( $request_id ) );
		if ( ! is_array( $data ) ) {
			wp_send_json_error( array( 'message' => __( '状态不存在或已过期。', 'zhiwrite-ai-writer' ) ), 404 );
		}

		$started_at = isset( $data['started_at'] ) ? (int) $data['started_at'] : time();
		$updated_at = isset( $data['updated_at'] ) ? (int) $data['updated_at'] : time();

		wp_send_json_success(
			array(
				'requestId' => (string) $request_id,
				'stage'     => isset( $data['stage'] ) ? (string) $data['stage'] : '',
				'message'   => isset( $data['message'] ) ? (string) $data['message'] : '',
				'percent'   => array_key_exists( 'percent', $data ) ? $data['percent'] : null,
				'elapsed'   => max( 0, time() - $started_at ),
				'age'       => max( 0, time() - $updated_at ),
				'updatedAt' => $updated_at,
			)
		);
	}
	public static function render_settings_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( '权限不足。', 'zhiwrite-ai-writer' ) );
		}

		$tabs = array(
			'interfaces' => array(
				'id'    => 'interfaces',
				'title' => __( '接口设置', 'zhiwrite-ai-writer' ),
				'desc'  => __( 'API 地址 / Key / 默认模型', 'zhiwrite-ai-writer' ),
			),
			'generation' => array(
				'id'    => 'generation',
				'title' => __( '生成与内容', 'zhiwrite-ai-writer' ),
				'desc'  => __( '格式、业务背景提示词', 'zhiwrite-ai-writer' ),
			),
			'publishing' => array(
				'id'    => 'publishing',
				'title' => __( '发布与权限', 'zhiwrite-ai-writer' ),
				'desc'  => __( '默认发布策略、允许编辑使用', 'zhiwrite-ai-writer' ),
			),
			'privacy' => array(
				'id'    => 'privacy',
				'title' => __( '隐私与脱敏', 'zhiwrite-ai-writer' ),
				'desc'  => __( 'PII 脱敏、禁用外发字段', 'zhiwrite-ai-writer' ),
			),
			'budget' => array(
				'id'    => 'budget',
				'title' => __( '用量与预算', 'zhiwrite-ai-writer' ),
				'desc'  => __( '用量阈值、超额拦截与通知', 'zhiwrite-ai-writer' ),
			),
			'email' => array(
				'id'    => 'email',
				'title' => __( 'SMTP 邮件配置', 'zhiwrite-ai-writer' ),
				'desc'  => __( '系统邮件 / 插件 SMTP（二选一）', 'zhiwrite-ai-writer' ),
			),
			'safety' => array(
				'id'    => 'safety',
				'title' => __( '内容安全', 'zhiwrite-ai-writer' ),
				'desc'  => __( '敏感词库与命中策略', 'zhiwrite-ai-writer' ),
			),
			'seo' => array(
				'id'    => 'seo',
				'title' => __( 'SEO 规则', 'zhiwrite-ai-writer' ),
				'desc'  => __( '标题/摘要/H 标签/关键词密度提示', 'zhiwrite-ai-writer' ),
			),
			'internal_links' => array(
				'id'    => 'internal_links',
				'title' => __( '内部链接', 'zhiwrite-ai-writer' ),
				'desc'  => __( '相关文章推荐与插入规则', 'zhiwrite-ai-writer' ),
			),
			'lead' => array(
				'id'    => 'lead',
				'title' => __( '导语/摘要', 'zhiwrite-ai-writer' ),
				'desc'  => __( '自动摘要、正文导语', 'zhiwrite-ai-writer' ),
			),
			'terms' => array(
				'id'    => 'terms',
				'title' => __( '分类/标签写入', 'zhiwrite-ai-writer' ),
				'desc'  => __( '控制保存文章时的分类/标签写入策略', 'zhiwrite-ai-writer' ),
			),
			'tag_gen' => array(
				'id'    => 'tag_gen',
				'title' => __( '标签生成', 'zhiwrite-ai-writer' ),
				'desc'  => __( '文章列表（edit.php）标签生成默认配置', 'zhiwrite-ai-writer' ),
			),
			'prompt_builder' => array(
				'id'    => 'prompt_builder',
				'title' => __( '提示词构建器', 'zhiwrite-ai-writer' ),
				'desc'  => __( '模板/变量/风格预设的配置与回滚。生成时会注入到提示词中。', 'zhiwrite-ai-writer' ),
			),
			'toc' => array(
				'id'    => 'toc',
				'title' => __( '目录（TOC）', 'zhiwrite-ai-writer' ),
				'desc'  => __( '按 H2/H3 自动插入目录', 'zhiwrite-ai-writer' ),
			),
			'faq' => array(
				'id'    => 'faq',
				'title' => __( 'FAQ', 'zhiwrite-ai-writer' ),
				'desc'  => __( '自动 FAQ（问答）', 'zhiwrite-ai-writer' ),
			),
			'precheck' => array(
				'id'    => 'precheck',
				'title' => __( '发布前校验', 'zhiwrite-ai-writer' ),
				'desc'  => __( '缺图/缺摘要/外链超限/敏感词等', 'zhiwrite-ai-writer' ),
			),
			'cache' => array(
				'id'    => 'cache',
				'title' => __( '缓存策略', 'zhiwrite-ai-writer' ),
				'desc'  => __( '避免重复生成与重复扣费', 'zhiwrite-ai-writer' ),
			),
			'failover' => array(
				'id'    => 'failover',
				'title' => __( '主备接口切换', 'zhiwrite-ai-writer' ),
				'desc'  => __( '失败自动切换与熔断参数', 'zhiwrite-ai-writer' ),
			),
			'model_router' => array(
				'id'    => 'model_router',
				'title' => __( '模型路由', 'zhiwrite-ai-writer' ),
				'desc'  => __( '按任务类型自动选模型', 'zhiwrite-ai-writer' ),
			),
			'webhook' => array(
				'id'    => 'webhook',
				'title' => __( 'Webhook 回调', 'zhiwrite-ai-writer' ),
				'desc'  => __( '生成完成回调外部系统', 'zhiwrite-ai-writer' ),
			),
			'fact_check' => array(
				'id'    => 'fact_check',
				'title' => __( '事实核查', 'zhiwrite-ai-writer' ),
				'desc'  => __( '可验证要点清单（有限）', 'zhiwrite-ai-writer' ),
			),
			'stability' => array(
				'id'    => 'stability',
				'title' => __( '稳定性与性能', 'zhiwrite-ai-writer' ),
				'desc'  => __( '超时等稳定性参数', 'zhiwrite-ai-writer' ),
			),
			'data' => array(
				'id'    => 'data',
				'title' => __( '日志与数据', 'zhiwrite-ai-writer' ),
				'desc'  => __( '生成记录、卸载保留', 'zhiwrite-ai-writer' ),
			),
		);
		$active_tab = isset( $_GET['tab'] ) ? sanitize_key( (string) wp_unslash( $_GET['tab'] ) ) : 'interfaces';
		if ( ! isset( $tabs[ $active_tab ] ) ) {
			$active_tab = 'interfaces';
		}
		?>
		<div class="wrap zhiwrite-ai-wrap">
			<h1><?php echo esc_html__( '智写AI - 功能配置', 'zhiwrite-ai-writer' ); ?></h1>
			<?php
			// Use toast instead of WP notice after saving settings.
			if ( isset( $_GET['settings-updated'] ) ) {
				?>
				<script>
					(function () {
						var msg = <?php echo wp_json_encode( __( '设置已保存。', 'zhiwrite-ai-writer' ) ); ?>;
						function tryShow() {
							if (window.zhiwriteShowToast) {
								window.zhiwriteShowToast("success", msg, 2500);
								return true;
							}
							return false;
						}
						// Run after DOM is ready; admin.js may be enqueued in footer.
						if (document.readyState === "loading") {
							document.addEventListener("DOMContentLoaded", function () {
								if (tryShow()) return;
								var tries = 0;
								var t = window.setInterval(function () {
									tries++;
									if (tryShow() || tries >= 40) { // ~2s
										window.clearInterval(t);
									}
								}, 50);
							});
						} else {
							if (tryShow()) return;
							var tries2 = 0;
							var t2 = window.setInterval(function () {
								tries2++;
								if (tryShow() || tries2 >= 40) {
									window.clearInterval(t2);
								}
							}, 50);
						}
					})();
				</script>
				<?php
			}
			?>
			<h2 class="nav-tab-wrapper" style="margin-top:14px;">
				<?php foreach ( $tabs as $key => $tab ) : ?>
					<?php
					$url = add_query_arg(
						array(
							'page' => 'zhiwrite-ai-settings',
							'tab'  => $key,
						),
						admin_url( 'admin.php' )
					);
					?>
					<a class="nav-tab <?php echo $active_tab === $key ? 'nav-tab-active' : ''; ?>" href="<?php echo esc_url( $url ); ?>">
						<?php echo esc_html( $tab['title'] ); ?>
					</a>
				<?php endforeach; ?>
			</h2>
			<p class="description" style="margin:8px 0 14px;">
				<?php echo esc_html( $tabs[ $active_tab ]['desc'] ); ?>
			</p>

			<form method="post" action="options.php">
				<?php settings_fields( 'zhiwrite_ai_writer_settings' ); ?>

				<div class="zhiwrite-td-card">
					<div class="zhiwrite-td-card__header">
						<div class="zhiwrite-td-card__title"><?php echo esc_html( $tabs[ $active_tab ]['title'] ); ?></div>
					</div>
					<div class="zhiwrite-td-card__body">
						<?php if ( 'interfaces' === $active_tab ) : ?>
							<?php do_settings_fields( 'zhiwrite-ai-writer', 'zhiwrite_ai_writer_interfaces' ); ?>
							<p class="description" style="margin-top:10px;">
								<?php echo esc_html__( '提示：API 接口地址建议填写到 /v1，例如 https://api.example.com/v1。', 'zhiwrite-ai-writer' ); ?>
							</p>
						<?php else : ?>
							<table class="form-table" role="presentation">
								<?php
								if ( 'generation' === $active_tab ) {
									do_settings_fields( 'zhiwrite-ai-writer', 'zhiwrite_ai_writer_generation' );
								} elseif ( 'publishing' === $active_tab ) {
									do_settings_fields( 'zhiwrite-ai-writer', 'zhiwrite_ai_writer_publishing' );
								} elseif ( 'privacy' === $active_tab ) {
									do_settings_fields( 'zhiwrite-ai-writer', 'zhiwrite_ai_writer_privacy' );
								} elseif ( 'budget' === $active_tab ) {
									do_settings_fields( 'zhiwrite-ai-writer', 'zhiwrite_ai_writer_budget' );
								} elseif ( 'email' === $active_tab ) {
									do_settings_fields( 'zhiwrite-ai-writer', 'zhiwrite_ai_writer_email' );
								} elseif ( 'safety' === $active_tab ) {
									do_settings_fields( 'zhiwrite-ai-writer', 'zhiwrite_ai_writer_safety' );
								} elseif ( 'seo' === $active_tab ) {
									do_settings_fields( 'zhiwrite-ai-writer', 'zhiwrite_ai_writer_seo_rules' );
								} elseif ( 'internal_links' === $active_tab ) {
									do_settings_fields( 'zhiwrite-ai-writer', 'zhiwrite_ai_writer_internal_links' );
								} elseif ( 'lead' === $active_tab ) {
									do_settings_fields( 'zhiwrite-ai-writer', 'zhiwrite_ai_writer_lead' );
								} elseif ( 'terms' === $active_tab ) {
									do_settings_fields( 'zhiwrite-ai-writer', 'zhiwrite_ai_writer_terms' );
								} elseif ( 'tag_gen' === $active_tab ) {
									do_settings_fields( 'zhiwrite-ai-writer', 'zhiwrite_ai_writer_tag_gen' );
								} elseif ( 'prompt_builder' === $active_tab ) {
									do_settings_fields( 'zhiwrite-ai-writer', 'zhiwrite_ai_writer_prompt_builder' );
								} elseif ( 'toc' === $active_tab ) {
									do_settings_fields( 'zhiwrite-ai-writer', 'zhiwrite_ai_writer_toc' );
								} elseif ( 'faq' === $active_tab ) {
									do_settings_fields( 'zhiwrite-ai-writer', 'zhiwrite_ai_writer_faq' );
								} elseif ( 'precheck' === $active_tab ) {
									do_settings_fields( 'zhiwrite-ai-writer', 'zhiwrite_ai_writer_precheck' );
								} elseif ( 'cache' === $active_tab ) {
									do_settings_fields( 'zhiwrite-ai-writer', 'zhiwrite_ai_writer_cache' );
								} elseif ( 'failover' === $active_tab ) {
									do_settings_fields( 'zhiwrite-ai-writer', 'zhiwrite_ai_writer_failover' );
								} elseif ( 'model_router' === $active_tab ) {
									do_settings_fields( 'zhiwrite-ai-writer', 'zhiwrite_ai_writer_model_router' );
								} elseif ( 'webhook' === $active_tab ) {
									do_settings_fields( 'zhiwrite-ai-writer', 'zhiwrite_ai_writer_webhook' );
								} elseif ( 'fact_check' === $active_tab ) {
									do_settings_fields( 'zhiwrite-ai-writer', 'zhiwrite_ai_writer_fact_check' );
								} elseif ( 'stability' === $active_tab ) {
									do_settings_fields( 'zhiwrite-ai-writer', 'zhiwrite_ai_writer_stability' );
								} elseif ( 'data' === $active_tab ) {
									do_settings_fields( 'zhiwrite-ai-writer', 'zhiwrite_ai_writer_data' );
								}
								?>
							</table>
						<?php endif; ?>
					</div>
				</div>

				<div class="zhiwrite-settings-submit">
					<?php submit_button(); ?>
				</div>
			</form>
		</div>
		<?php
	}

	public static function render_generate_page() {
		if ( ! current_user_can( ZhiWrite_AI_Writer_Settings::capability() ) ) {
			wp_die( esc_html__( '权限不足。', 'zhiwrite-ai-writer' ) );
		}
		$opts = ZhiWrite_AI_Writer_Settings::get_options();
		$interfaces = isset( $opts['interfaces'] ) && is_array( $opts['interfaces'] ) ? $opts['interfaces'] : array();
		$default_id = isset( $opts['default_interface_id'] ) ? (string) $opts['default_interface_id'] : '';
		?>
		<div class="wrap zhiwrite-ai-wrap">
			<h1><?php echo esc_html__( '智写AI - 生成内容', 'zhiwrite-ai-writer' ); ?></h1>

			<div class="zhiwrite-ai-grid">
				<div class="zhiwrite-ai-card zhiwrite-td-card">
					<div class="zhiwrite-td-card__header">
						<div class="zhiwrite-td-card__title"><?php echo esc_html__( '输入', 'zhiwrite-ai-writer' ); ?></div>
					</div>
					<div class="zhiwrite-td-card__body">

					<table class="form-table" role="presentation">
						<tr>
							<th scope="row"><label for="zhiwrite_interface"><?php echo esc_html__( '接口', 'zhiwrite-ai-writer' ); ?></label></th>
							<td>
								<select id="zhiwrite_interface">
									<?php if ( empty( $interfaces ) ) : ?>
										<option value=""><?php echo esc_html__( '未配置接口（请先到“设置-接口设置”添加）', 'zhiwrite-ai-writer' ); ?></option>
									<?php else : ?>
										<?php foreach ( $interfaces as $row ) : ?>
											<?php
											$id   = isset( $row['id'] ) ? (string) $row['id'] : '';
											$name = isset( $row['name'] ) && '' !== (string) $row['name'] ? (string) $row['name'] : __( '未命名接口', 'zhiwrite-ai-writer' );
											?>
											<option value="<?php echo esc_attr( $id ); ?>" <?php selected( $default_id, $id ); ?>>
												<?php echo esc_html( $name ); ?>
											</option>
										<?php endforeach; ?>
									<?php endif; ?>
								</select>
								<p class="description">
									<?php echo esc_html__( '生成时会使用所选接口的 API 地址 / Key / 默认模型。', 'zhiwrite-ai-writer' ); ?>
								</p>
							</td>
						</tr>
						<tr>
							<th scope="row"><label for="zhiwrite_title"><?php echo esc_html__( '主题/标题（可选）', 'zhiwrite-ai-writer' ); ?></label></th>
							<td><input id="zhiwrite_title" type="text" class="regular-text" placeholder="<?php echo esc_attr__( '例如：WordPress SEO 优化实战指南', 'zhiwrite-ai-writer' ); ?>" /></td>
						</tr>
						<tr>
							<th scope="row"><label for="zhiwrite_prompt"><?php echo esc_html__( '写作需求（必填）', 'zhiwrite-ai-writer' ); ?></label></th>
							<td>
								<textarea id="zhiwrite_prompt" rows="10" class="large-text" placeholder="<?php echo esc_attr__( '例如：写一篇面向新手的教程，包含步骤、常见坑、FAQ，语气专业但易懂。', 'zhiwrite-ai-writer' ); ?>"></textarea>
							</td>
						</tr>
						<?php
						$pb = isset( $opts['prompt_builder'] ) && is_array( $opts['prompt_builder'] ) ? $opts['prompt_builder'] : array();
						$pb_tpls = isset( $pb['templates'] ) && is_array( $pb['templates'] ) ? $pb['templates'] : array();
						$pb_styles = isset( $pb['styles'] ) && is_array( $pb['styles'] ) ? $pb['styles'] : array();
						$pb_def_tpl = isset( $pb['default_template_id'] ) ? (string) $pb['default_template_id'] : '';
						$pb_def_style = isset( $pb['default_style_id'] ) ? (string) $pb['default_style_id'] : '';
						?>
						<tr>
							<th scope="row"><label for="zhiwrite_template_id"><?php echo esc_html__( '模板（可选）', 'zhiwrite-ai-writer' ); ?></label></th>
							<td>
								<select id="zhiwrite_template_id">
									<option value=""><?php echo esc_html__( '（不使用）', 'zhiwrite-ai-writer' ); ?></option>
									<?php foreach ( $pb_tpls as $t ) : ?>
										<?php
										$tid = isset( $t['id'] ) ? (string) $t['id'] : '';
										$tn  = isset( $t['name'] ) ? (string) $t['name'] : '';
										if ( '' === $tid || '' === $tn ) {
											continue;
										}
										?>
										<option value="<?php echo esc_attr( $tid ); ?>" <?php selected( $pb_def_tpl, $tid ); ?>><?php echo esc_html( $tn ); ?></option>
									<?php endforeach; ?>
								</select>
								<p class="description"><?php echo esc_html__( '从“提示词构建器”中选择一个模板注入 system prompt。', 'zhiwrite-ai-writer' ); ?></p>
							</td>
						</tr>
						<tr>
							<th scope="row"><label for="zhiwrite_style_id"><?php echo esc_html__( '风格预设（可选）', 'zhiwrite-ai-writer' ); ?></label></th>
							<td>
								<select id="zhiwrite_style_id">
									<option value=""><?php echo esc_html__( '（不使用）', 'zhiwrite-ai-writer' ); ?></option>
									<?php foreach ( $pb_styles as $s ) : ?>
										<?php
										$sid = isset( $s['id'] ) ? (string) $s['id'] : '';
										$sn  = isset( $s['name'] ) ? (string) $s['name'] : '';
										if ( '' === $sid || '' === $sn ) {
											continue;
										}
										?>
										<option value="<?php echo esc_attr( $sid ); ?>" <?php selected( $pb_def_style, $sid ); ?>><?php echo esc_html( $sn ); ?></option>
									<?php endforeach; ?>
								</select>
								<p class="description"><?php echo esc_html__( '风格预设会注入 system prompt，用于控制语气/长度/结构。', 'zhiwrite-ai-writer' ); ?></p>
							</td>
						</tr>
						<tr>
							<th scope="row"><label for="zhiwrite_vars_override"><?php echo esc_html__( '变量覆盖（可选）', 'zhiwrite-ai-writer' ); ?></label></th>
							<td>
								<textarea id="zhiwrite_vars_override" rows="4" class="large-text code" placeholder="<?php echo esc_attr__( '{\"site_name\":\"XX\",\"language\":\"zh-CN\"}', 'zhiwrite-ai-writer' ); ?>"></textarea>
								<p class="description"><?php echo esc_html__( '可填写 JSON 对象，用于覆盖/新增变量（仅本次生成生效）。', 'zhiwrite-ai-writer' ); ?></p>
							</td>
						</tr>
						<tr>
							<th scope="row"><label for="zhiwrite_model"><?php echo esc_html__( '模型（可选覆盖）', 'zhiwrite-ai-writer' ); ?></label></th>
							<td><input id="zhiwrite_model" type="text" class="regular-text" value="<?php echo esc_attr( (string) $opts['model'] ); ?>" placeholder="gpt-4o-mini" /></td>
						</tr>
						<tr>
							<th scope="row"><?php echo esc_html__( '选项', 'zhiwrite-ai-writer' ); ?></th>
							<td>
								<label><input type="checkbox" id="zhiwrite_do_seo" checked /> <?php echo esc_html__( '生成 SEO 字段（标题/摘要/slug/焦点关键词）', 'zhiwrite-ai-writer' ); ?></label>
								<br />
								<label><input type="checkbox" id="zhiwrite_do_terms" checked /> <?php echo esc_html__( '建议分类/标签（可手动确认后再保存）', 'zhiwrite-ai-writer' ); ?></label>
								<br />
								<label><input type="checkbox" id="zhiwrite_do_disclaimer" /> <?php echo esc_html__( '追加免责声明（可选）', 'zhiwrite-ai-writer' ); ?></label>
							</td>
						</tr>
					</table>

					<p>
						<button class="button button-primary" id="zhiwrite_generate_btn"><?php echo esc_html__( '开始生成', 'zhiwrite-ai-writer' ); ?></button>
						<span class="zhiwrite-ai-spinner spinner"></span>
					</p>
					<p class="description">
						<?php
						$pol = isset( $opts['default_post_status'] ) ? (string) $opts['default_post_status'] : 'draft';
						if ( 'manual' === $pol ) {
							echo esc_html__( '当前策略：仅展示结果。生成后请手动选择“保存为草稿 / 直接发布”。', 'zhiwrite-ai-writer' );
						} elseif ( 'publish' === $pol ) {
							echo esc_html__( '当前策略：生成后直接发布。', 'zhiwrite-ai-writer' );
						} else {
							echo esc_html__( '当前策略：生成后保存为草稿。', 'zhiwrite-ai-writer' );
						}
						?>
					</p>
					</div>
				</div>

				<div class="zhiwrite-ai-card zhiwrite-td-card">
					<div class="zhiwrite-td-card__header">
						<div class="zhiwrite-td-card__title"><?php echo esc_html__( '输出', 'zhiwrite-ai-writer' ); ?></div>
					</div>
					<div class="zhiwrite-td-card__body">
					<div id="zhiwrite_result" class="zhiwrite-ai-result">
						<div class="zhiwrite-empty">
							<div class="zhiwrite-empty__title"><?php echo esc_html__( '等待生成结果', 'zhiwrite-ai-writer' ); ?></div>
							<div class="zhiwrite-empty__desc">
								<?php echo esc_html__( '在左侧填写写作需求，点击“开始生成”。生成完成后，这里会展示标题/摘要/正文，并提供保存、发布、应用分类/标签等操作。', 'zhiwrite-ai-writer' ); ?>
							</div>
							<ol class="zhiwrite-empty__steps">
								<li><?php echo esc_html__( '选择接口（可选覆盖模型）', 'zhiwrite-ai-writer' ); ?></li>
								<li><?php echo esc_html__( '填写写作需求（越具体越好）', 'zhiwrite-ai-writer' ); ?></li>
								<li><?php echo esc_html__( '点击“开始生成”，等待进度完成', 'zhiwrite-ai-writer' ); ?></li>
							</ol>
							<div class="zhiwrite-empty__examples">
								<div class="zhiwrite-empty__examples-title"><?php echo esc_html__( '示例需求（点击一键填入）', 'zhiwrite-ai-writer' ); ?></div>
								<div class="zhiwrite-empty__chips">
									<button type="button" class="button zhiwrite-empty-chip" data-zhiwrite-fill="写一篇面向新手的教程：主题是 WordPress 文章 SEO 优化。需要包含：步骤清单、常见误区、FAQ（5条），语气专业但易懂。"><?php echo esc_html__( 'SEO 教程', 'zhiwrite-ai-writer' ); ?></button>
									<button type="button" class="button zhiwrite-empty-chip" data-zhiwrite-fill="写一篇产品评测文章：对象是某款智能手表。要求：先给结论，再按优缺点、适合人群、购买建议展开；避免夸大；结尾给一个简短总结。"><?php echo esc_html__( '产品评测', 'zhiwrite-ai-writer' ); ?></button>
									<button type="button" class="button zhiwrite-empty-chip" data-zhiwrite-fill="写一篇清单型文章：主题是“新手入门摄影必备装备”。要求：按预算分档（入门/进阶），每档给建议组合与理由；最后附FAQ。"><?php echo esc_html__( '清单文章', 'zhiwrite-ai-writer' ); ?></button>
								</div>
								<p class="description" style="margin:10px 0 0;"><?php echo esc_html__( '提示：可以在“功能配置 -> 提示词构建器”里配置模板/风格预设，统一写作口吻。', 'zhiwrite-ai-writer' ); ?></p>
							</div>
						</div>
					</div>
					</div>
				</div>
			</div>
		</div>
		<?php
	}

	public static function render_logs_page() {
		if ( ! current_user_can( ZhiWrite_AI_Writer_Settings::capability() ) ) {
			wp_die( esc_html__( '权限不足。', 'zhiwrite-ai-writer' ) );
		}

		$filters = self::logs_filters_from_request( $_GET );
		$logs    = ZhiWrite_AI_Writer_DB::get_logs( 50, 0, $filters );
		$total   = ZhiWrite_AI_Writer_DB::count_logs( $filters );
		?>
		<div class="wrap zhiwrite-ai-wrap">
			<h1><?php echo esc_html__( '智写AI - 生成记录', 'zhiwrite-ai-writer' ); ?></h1>

			<div class="zhiwrite-td-page">
				<div class="zhiwrite-td-card">
					<div class="zhiwrite-td-card__header">
						<div class="zhiwrite-td-card__title">
							<?php
							// translators: %d is total rows
							echo esc_html( sprintf( __( '最近 50 条（符合筛选：%d 条）', 'zhiwrite-ai-writer' ), (int) $total ) );
							?>
						</div>
						<div class="zhiwrite-td-card__actions">
							<button type="button" class="button button-secondary" id="zhiwrite-export-logs-json"><?php echo esc_html__( '导出 JSON', 'zhiwrite-ai-writer' ); ?></button>
							<button type="button" class="button button-secondary" id="zhiwrite-export-logs-csv"><?php echo esc_html__( '导出 CSV', 'zhiwrite-ai-writer' ); ?></button>
						</div>
					</div>
					<div class="zhiwrite-td-card__body">
						<form method="get" class="zhiwrite-logs-filter" style="margin:0 0 12px;">
							<input type="hidden" name="page" value="zhiwrite-ai-logs" />
							<div class="zhiwrite-logs-filter__grid">
								<div class="zhiwrite-logs-filter__field">
									<label class="description" for="zhiwrite_log_action"><?php echo esc_html__( '事件', 'zhiwrite-ai-writer' ); ?></label><br />
									<input id="zhiwrite_log_action" name="log_action" type="text" class="regular-text" value="<?php echo esc_attr( isset( $filters['action'] ) ? (string) $filters['action'] : '' ); ?>" placeholder="generate / generate_error / settings_update" />
								</div>
								<div class="zhiwrite-logs-filter__field">
									<label class="description" for="zhiwrite_log_model"><?php echo esc_html__( '模型', 'zhiwrite-ai-writer' ); ?></label><br />
									<input id="zhiwrite_log_model" name="model" type="text" class="regular-text" value="<?php echo esc_attr( isset( $filters['model'] ) ? (string) $filters['model'] : '' ); ?>" placeholder="gpt-4o-mini" />
								</div>
								<div class="zhiwrite-logs-filter__field">
									<label class="description" for="zhiwrite_log_user"><?php echo esc_html__( '用户ID', 'zhiwrite-ai-writer' ); ?></label><br />
									<input id="zhiwrite_log_user" name="user_id" type="number" min="0" class="small-text" value="<?php echo esc_attr( isset( $filters['user_id'] ) ? (int) $filters['user_id'] : 0 ); ?>" />
								</div>
								<div class="zhiwrite-logs-filter__field">
									<label class="description" for="zhiwrite_log_from"><?php echo esc_html__( '从（时间）', 'zhiwrite-ai-writer' ); ?></label><br />
										<input id="zhiwrite_log_from" name="from" type="datetime-local" class="regular-text" value="<?php echo esc_attr( isset( $filters['from'] ) ? self::datetime_to_local_input_value( (string) $filters['from'] ) : '' ); ?>" />
								</div>
								<div class="zhiwrite-logs-filter__field">
									<label class="description" for="zhiwrite_log_to"><?php echo esc_html__( '到（时间）', 'zhiwrite-ai-writer' ); ?></label><br />
										<input id="zhiwrite_log_to" name="to" type="datetime-local" class="regular-text" value="<?php echo esc_attr( isset( $filters['to'] ) ? self::datetime_to_local_input_value( (string) $filters['to'] ) : '' ); ?>" />
								</div>
								<div class="zhiwrite-logs-filter__field zhiwrite-logs-filter__field--q">
									<label class="description" for="zhiwrite_log_q"><?php echo esc_html__( '关键词', 'zhiwrite-ai-writer' ); ?></label><br />
									<input id="zhiwrite_log_q" name="q" type="text" class="regular-text" value="<?php echo esc_attr( isset( $filters['q'] ) ? (string) $filters['q'] : '' ); ?>" placeholder="<?php echo esc_attr__( '标题/需求/正文/meta 模糊搜索', 'zhiwrite-ai-writer' ); ?>" />
								</div>
								<div class="zhiwrite-logs-filter__actions">
									<?php submit_button( __( '筛选', 'zhiwrite-ai-writer' ), 'secondary', '', false ); ?>
									<a class="button" href="<?php echo esc_url( admin_url( 'admin.php?page=zhiwrite-ai-logs' ) ); ?>"><?php echo esc_html__( '清空', 'zhiwrite-ai-writer' ); ?></a>
								</div>
							</div>
						</form>

						<table class="widefat striped">
							<thead>
								<tr>
									<th><?php echo esc_html__( '时间', 'zhiwrite-ai-writer' ); ?></th>
									<th><?php echo esc_html__( '用户', 'zhiwrite-ai-writer' ); ?></th>
									<th><?php echo esc_html__( '事件', 'zhiwrite-ai-writer' ); ?></th>
									<th><?php echo esc_html__( '模型', 'zhiwrite-ai-writer' ); ?></th>
									<th><?php echo esc_html__( '标题', 'zhiwrite-ai-writer' ); ?></th>
									<th><?php echo esc_html__( '文章', 'zhiwrite-ai-writer' ); ?></th>
									<th><?php echo esc_html__( '操作', 'zhiwrite-ai-writer' ); ?></th>
								</tr>
							</thead>
							<tbody>
								<?php if ( empty( $logs ) ) : ?>
									<tr><td colspan="7"><?php echo esc_html__( '暂无记录。', 'zhiwrite-ai-writer' ); ?></td></tr>
								<?php else : ?>
									<?php foreach ( $logs as $row ) : ?>
										<?php
										$user = $row['user_id'] ? get_user_by( 'id', (int) $row['user_id'] ) : null;
										?>
										<tr>
											<td><?php echo esc_html( $row['created_at'] ); ?></td>
											<td><?php echo esc_html( $user ? $user->user_login : '-' ); ?></td>
											<td><?php echo esc_html( (string) $row['action'] ); ?></td>
											<td><?php echo esc_html( (string) $row['model'] ); ?></td>
											<td><?php echo esc_html( wp_html_excerpt( (string) $row['input_title'], 60, '…' ) ); ?></td>
											<td>
												<?php
												$pid = ! empty( $row['post_id'] ) ? (int) $row['post_id'] : 0;
												if ( $pid > 0 ) {
													$p = get_post( $pid );
													$edit = $p ? get_edit_post_link( $pid, 'raw' ) : '';
													$is_trash = $p && isset( $p->post_status ) && 'trash' === (string) $p->post_status;
													if ( $p && ! $is_trash && '' !== (string) $edit ) {
														?>
														<a href="<?php echo esc_url( $edit ); ?>"><?php echo esc_html__( '查看/编辑', 'zhiwrite-ai-writer' ); ?></a>
														<?php
													} else {
														?>
														<a href="#" class="zhiwrite-ai-post-missing" aria-disabled="true" data-post-id="<?php echo esc_attr( (string) $pid ); ?>" data-reason="<?php echo esc_attr( $is_trash ? 'trash' : 'missing' ); ?>">
															<?php echo esc_html__( '查看/编辑', 'zhiwrite-ai-writer' ); ?>
														</a>
														<?php
													}
												} else {
													echo '-';
												}
												?>
											</td>
											<td>
												<button class="button button-small zhiwrite-ai-delete-log" data-log-id="<?php echo esc_attr( (int) $row['id'] ); ?>">
													<?php echo esc_html__( '删除', 'zhiwrite-ai-writer' ); ?>
												</button>
											</td>
										</tr>
									<?php endforeach; ?>
								<?php endif; ?>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
		<?php
	}

	/**
	 * 队列管理页：展示和控制后台任务队列。
	 */
	public static function render_queue_page() {
		if ( ! current_user_can( ZhiWrite_AI_Writer_Settings::capability_logs() ) ) {
			wp_die( esc_html__( '权限不足。', 'zhiwrite-ai-writer' ) );
		}

		$filters = array();
		$active_status = '';
		if ( isset( $_GET['status'] ) ) {
			$active_status = sanitize_key( (string) wp_unslash( $_GET['status'] ) );
			$filters['status'] = $active_status;
		}
		if ( isset( $_GET['user_id'] ) ) {
			$filters['user_id'] = (int) $_GET['user_id'];
		}

		$tasks = ZhiWrite_AI_Writer_DB::get_tasks( 50, 0, $filters );
		$total = ZhiWrite_AI_Writer_DB::count_tasks( $filters );
		?>
		<div class="wrap zhiwrite-ai-wrap">
			<h1><?php echo esc_html__( '智写AI - 队列管理', 'zhiwrite-ai-writer' ); ?></h1>

			<?php
			$tabs = array(
				'' => __( '全部', 'zhiwrite-ai-writer' ),
				ZhiWrite_AI_Writer_DB::TASK_STATUS_PENDING => __( '未执行', 'zhiwrite-ai-writer' ),
				ZhiWrite_AI_Writer_DB::TASK_STATUS_RUNNING => __( '正在执行', 'zhiwrite-ai-writer' ),
				ZhiWrite_AI_Writer_DB::TASK_STATUS_SUCCEEDED => __( '已完成', 'zhiwrite-ai-writer' ),
				ZhiWrite_AI_Writer_DB::TASK_STATUS_FAILED => __( '失败', 'zhiwrite-ai-writer' ),
				ZhiWrite_AI_Writer_DB::TASK_STATUS_CANCELLED => __( '已取消', 'zhiwrite-ai-writer' ),
			);
			?>
			<h2 class="nav-tab-wrapper" style="margin-top:12px;">
				<?php foreach ( $tabs as $st => $label ) : ?>
					<?php
					$args = array(
						'page' => 'zhiwrite-ai-queue',
					);
					if ( '' !== (string) $st ) {
						$args['status'] = (string) $st;
					}
					if ( isset( $filters['user_id'] ) && (int) $filters['user_id'] > 0 ) {
						$args['user_id'] = (int) $filters['user_id'];
					}
					$url = add_query_arg( $args, admin_url( 'admin.php' ) );
					$is_active = ( (string) $active_status === (string) $st ) || ( '' === (string) $st && '' === (string) $active_status );
					?>
					<a class="nav-tab <?php echo $is_active ? 'nav-tab-active' : ''; ?>" href="<?php echo esc_url( $url ); ?>">
						<?php echo esc_html( $label ); ?>
					</a>
				<?php endforeach; ?>
			</h2>

			<div class="zhiwrite-td-page">
				<div class="zhiwrite-td-card">
					<div class="zhiwrite-td-card__header">
						<div class="zhiwrite-td-card__title" id="zhiwrite-queue-total">
							<?php
							// translators: %d is total rows
							echo esc_html( sprintf( __( '最近 50 条队列任务（共 %d 条）', 'zhiwrite-ai-writer' ), (int) $total ) );
							?>
						</div>
					</div>
					<div class="zhiwrite-td-card__body">
						<table class="widefat striped" id="zhiwrite-queue-table">
							<thead>
								<tr>
									<th><?php echo esc_html__( 'ID', 'zhiwrite-ai-writer' ); ?></th>
									<th><?php echo esc_html__( '时间', 'zhiwrite-ai-writer' ); ?></th>
									<th><?php echo esc_html__( '更新时间', 'zhiwrite-ai-writer' ); ?></th>
									<th><?php echo esc_html__( '用户', 'zhiwrite-ai-writer' ); ?></th>
									<th><?php echo esc_html__( '状态', 'zhiwrite-ai-writer' ); ?></th>
									<th><?php echo esc_html__( '进度', 'zhiwrite-ai-writer' ); ?></th>
									<th><?php echo esc_html__( '消息', 'zhiwrite-ai-writer' ); ?></th>
									<th><?php echo esc_html__( '锁定到', 'zhiwrite-ai-writer' ); ?></th>
									<th><?php echo esc_html__( '操作', 'zhiwrite-ai-writer' ); ?></th>
								</tr>
							</thead>
							<tbody id="zhiwrite-queue-tbody">
								<?php if ( empty( $tasks ) ) : ?>
									<tr><td colspan="9"><?php echo esc_html__( '暂无队列任务。', 'zhiwrite-ai-writer' ); ?></td></tr>
								<?php else : ?>
									<?php foreach ( $tasks as $row ) : ?>
										<?php
										$user = $row['user_id'] ? get_user_by( 'id', (int) $row['user_id'] ) : null;
										$status = isset( $row['status'] ) ? (string) $row['status'] : '';
										$progress = isset( $row['progress'] ) ? (int) $row['progress'] : 0;
										$message = isset( $row['message'] ) ? (string) $row['message'] : '';
										$locked_until = isset( $row['locked_until'] ) ? (string) $row['locked_until'] : '';
										$updated_at = isset( $row['updated_at'] ) ? (string) $row['updated_at'] : '';
										$can_cancel = in_array( $status, array( ZhiWrite_AI_Writer_DB::TASK_STATUS_PENDING, ZhiWrite_AI_Writer_DB::TASK_STATUS_RUNNING ), true );
										$can_delete = ! $can_cancel;
										?>
										<tr>
											<td><?php echo esc_html( (int) $row['id'] ); ?></td>
											<td><?php echo esc_html( isset( $row['created_at'] ) ? (string) $row['created_at'] : '' ); ?></td>
											<td><?php echo esc_html( $updated_at ); ?></td>
											<td><?php echo esc_html( $user ? $user->user_login : '-' ); ?></td>
											<td><?php echo self::task_status_badge_html( $status ); ?></td>
											<td><?php echo esc_html( $progress ); ?>%</td>
											<td><?php echo esc_html( wp_html_excerpt( $message, 80, '…' ) ); ?></td>
											<td><?php echo esc_html( '' !== $locked_until ? $locked_until : '-' ); ?></td>
											<td>
												<?php if ( $can_cancel ) : ?>
													<button class="button button-small zhiwrite-ai-cancel-task" data-task-id="<?php echo esc_attr( (int) $row['id'] ); ?>">
														<?php echo esc_html__( '停止', 'zhiwrite-ai-writer' ); ?>
													</button>
												<?php endif; ?>
												<?php if ( $can_delete ) : ?>
													<button class="button button-small zhiwrite-ai-delete-task" data-task-id="<?php echo esc_attr( (int) $row['id'] ); ?>" style="margin-left:6px;">
														<?php echo esc_html__( '删除', 'zhiwrite-ai-writer' ); ?>
													</button>
												<?php endif; ?>
												<?php if ( ! $can_cancel && ! $can_delete ) : ?>
													-
												<?php endif; ?>
											</td>
										</tr>
									<?php endforeach; ?>
								<?php endif; ?>
							</tbody>
						</table>
						<input type="hidden" id="zhiwrite-queue-filter-status" value="<?php echo esc_attr( (string) $active_status ); ?>" />
						<input type="hidden" id="zhiwrite-queue-filter-user" value="<?php echo esc_attr( isset( $filters['user_id'] ) ? (int) $filters['user_id'] : 0 ); ?>" />
					</div>
				</div>
			</div>
		</div>
		<?php
	}

	public static function render_webhook_queue_page() {
		if ( ! current_user_can( ZhiWrite_AI_Writer_Settings::capability_logs() ) ) {
			wp_die( esc_html__( '权限不足。', 'zhiwrite-ai-writer' ) );
		}
		?>
		<div class="wrap zhiwrite-ai-wrap">
			<h1><?php echo esc_html__( '智写AI - Webhook 重试队列', 'zhiwrite-ai-writer' ); ?></h1>
			<p class="description" style="margin:8px 0 14px;">
				<?php echo esc_html__( '展示 Webhook 失败后进入重试队列的任务；可手动触发立即重试。', 'zhiwrite-ai-writer' ); ?>
			</p>
			<div class="zhiwrite-td-card">
				<div class="zhiwrite-td-card__body">
					<p>
						<button class="button button-secondary" id="zhiwrite-webhook-refresh"><?php echo esc_html__( '刷新', 'zhiwrite-ai-writer' ); ?></button>
					</p>
					<table class="widefat striped">
						<thead>
							<tr>
								<th style="width:90px;"><?php echo esc_html__( 'ID', 'zhiwrite-ai-writer' ); ?></th>
								<th style="width:140px;"><?php echo esc_html__( '状态', 'zhiwrite-ai-writer' ); ?></th>
								<th style="width:170px;"><?php echo esc_html__( '更新时间', 'zhiwrite-ai-writer' ); ?></th>
								<th><?php echo esc_html__( '信息', 'zhiwrite-ai-writer' ); ?></th>
								<th style="width:120px;"><?php echo esc_html__( '操作', 'zhiwrite-ai-writer' ); ?></th>
							</tr>
						</thead>
						<tbody id="zhiwrite-webhook-queue-tbody">
							<tr><td colspan="5"><?php echo esc_html__( '加载中…', 'zhiwrite-ai-writer' ); ?></td></tr>
						</tbody>
					</table>
					<p class="description" style="margin-top:10px;">
						<?php echo esc_html__( '说明：该列表仅展示 request_id 以 “wh_” 开头的任务。', 'zhiwrite-ai-writer' ); ?>
					</p>
				</div>
			</div>
		</div>
		<?php
	}

	/**
	 * 用量统计页（Phase 3.1 最小可用版）。
	 */
	public static function render_usage_page() {
		if ( ! current_user_can( ZhiWrite_AI_Writer_Settings::capability_logs() ) ) {
			wp_die( esc_html__( '权限不足。', 'zhiwrite-ai-writer' ) );
		}

		$days = isset( $_GET['days'] ) ? max( 1, min( 365, (int) $_GET['days'] ) ) : 30;
		$from = gmdate( 'Y-m-d H:i:s', time() - ( $days * DAY_IN_SECONDS ) );

		global $wpdb;
		$table = ZhiWrite_AI_Writer_DB::logs_table();

		$sql_day = "SELECT DATE(created_at) AS d,
				COUNT(*) AS reqs,
				SUM(elapsed_ms) AS elapsed_ms,
				SUM(total_tokens) AS total_tokens
			FROM {$table}
			WHERE created_at >= %s AND total_tokens > 0
			GROUP BY DATE(created_at)
			ORDER BY d DESC
			LIMIT 400";
		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		$rows_day = $wpdb->get_results( $wpdb->prepare( $sql_day, $from ), ARRAY_A );

		$sql_if = "SELECT api_base_url,
				COUNT(*) AS reqs,
				SUM(elapsed_ms) AS elapsed_ms,
				SUM(total_tokens) AS total_tokens
			FROM {$table}
			WHERE created_at >= %s AND total_tokens > 0
			GROUP BY api_base_url
			ORDER BY reqs DESC
			LIMIT 200";
		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		$rows_if = $wpdb->get_results( $wpdb->prepare( $sql_if, $from ), ARRAY_A );

		$sql_action = "SELECT action,
				COUNT(*) AS reqs,
				SUM(elapsed_ms) AS elapsed_ms,
				SUM(total_tokens) AS total_tokens
			FROM {$table}
			WHERE created_at >= %s AND total_tokens > 0
			GROUP BY action
			ORDER BY reqs DESC
			LIMIT 200";
		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		$rows_action = $wpdb->get_results( $wpdb->prepare( $sql_action, $from ), ARRAY_A );

		// Cache hit stats (best-effort: parse meta JSON).
		$sql_meta = "SELECT meta FROM {$table} WHERE action = %s AND created_at >= %s AND meta IS NOT NULL AND meta <> '' LIMIT 20000";
		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		$rows_meta = $wpdb->get_col( $wpdb->prepare( $sql_meta, 'generate', $from ) );
		$cache_hit = 0;
		$saved_prompt_tokens = 0;
		$saved_completion_tokens = 0;
		$saved_total_tokens = 0;
		if ( is_array( $rows_meta ) ) {
			foreach ( $rows_meta as $mraw ) {
				$m = json_decode( (string) $mraw, true );
				if ( ! is_array( $m ) ) {
					continue;
				}
				if ( ! empty( $m['cache_hit'] ) ) {
					$cache_hit++;
					$saved_prompt_tokens += isset( $m['prompt_tokens'] ) ? (int) $m['prompt_tokens'] : 0;
					$saved_completion_tokens += isset( $m['completion_tokens'] ) ? (int) $m['completion_tokens'] : 0;
					$saved_total_tokens += isset( $m['total_tokens'] ) ? (int) $m['total_tokens'] : 0;
				}
			}
		}

		?>
		<div class="wrap zhiwrite-ai-wrap">
			<h1><?php echo esc_html__( '智写AI - 用量统计', 'zhiwrite-ai-writer' ); ?></h1>
			<p class="description" style="margin:8px 0 14px;">
				<?php echo esc_html__( '统计口径：汇总所有带 tokens 的成功调用（包括正文生成、标签生成，以及未来的评论/摘要等）。tokens 仅在上游接口返回 usage 时可用。', 'zhiwrite-ai-writer' ); ?>
			</p>

			<?php if ( $cache_hit > 0 ) : ?>
				<div class="notice notice-info" style="margin:0 0 12px;">
					<p>
						<?php
						echo esc_html(
							sprintf(
								__( '缓存命中：%1$d 次（约节省请求 %1$d 次）。预计节省 tokens：%2$d（prompt %3$d / completion %4$d）。', 'zhiwrite-ai-writer' ),
								(int) $cache_hit,
								(int) $saved_total_tokens,
								(int) $saved_prompt_tokens,
								(int) $saved_completion_tokens
							)
						);
						?>
					</p>
				</div>
			<?php endif; ?>

			<form method="get" style="margin:0 0 12px;">
				<input type="hidden" name="page" value="zhiwrite-ai-usage" />
				<label class="description" for="zhiwrite_usage_days"><?php echo esc_html__( '统计范围（天）', 'zhiwrite-ai-writer' ); ?></label>
				<input id="zhiwrite_usage_days" name="days" type="number" min="1" max="365" value="<?php echo esc_attr( (int) $days ); ?>" class="small-text" />
				<?php submit_button( __( '刷新', 'zhiwrite-ai-writer' ), 'secondary', '', false ); ?>
				<button type="button" class="button button-secondary" id="zhiwrite-export-usage-csv"><?php echo esc_html__( '导出 CSV', 'zhiwrite-ai-writer' ); ?></button>
			</form>

			<div class="zhiwrite-td-page">
				<div class="zhiwrite-td-card" style="margin-bottom:14px;">
					<div class="zhiwrite-td-card__header">
						<div class="zhiwrite-td-card__title"><?php echo esc_html__( '按事件类型汇总（action）', 'zhiwrite-ai-writer' ); ?></div>
					</div>
					<div class="zhiwrite-td-card__body">
						<table class="widefat striped">
							<thead>
								<tr>
									<th><?php echo esc_html__( '事件', 'zhiwrite-ai-writer' ); ?></th>
									<th><?php echo esc_html__( '请求数', 'zhiwrite-ai-writer' ); ?></th>
									<th><?php echo esc_html__( '总耗时(ms)', 'zhiwrite-ai-writer' ); ?></th>
									<th><?php echo esc_html__( '总 tokens', 'zhiwrite-ai-writer' ); ?></th>
								</tr>
							</thead>
							<tbody>
								<?php if ( empty( $rows_action ) ) : ?>
									<tr><td colspan="4"><?php echo esc_html__( '暂无数据。', 'zhiwrite-ai-writer' ); ?></td></tr>
								<?php else : ?>
									<?php foreach ( $rows_action as $r ) : ?>
										<tr>
											<td><code><?php echo esc_html( (string) $r['action'] ); ?></code></td>
											<td><?php echo esc_html( (int) $r['reqs'] ); ?></td>
											<td><?php echo esc_html( (int) $r['elapsed_ms'] ); ?></td>
											<td><?php echo esc_html( (int) $r['total_tokens'] ); ?></td>
										</tr>
									<?php endforeach; ?>
								<?php endif; ?>
							</tbody>
						</table>
					</div>
				</div>

				<div class="zhiwrite-td-card" style="margin-bottom:14px;">
					<div class="zhiwrite-td-card__header">
						<div class="zhiwrite-td-card__title"><?php echo esc_html__( '按天汇总', 'zhiwrite-ai-writer' ); ?></div>
					</div>
					<div class="zhiwrite-td-card__body">
						<table class="widefat striped">
							<thead>
								<tr>
									<th><?php echo esc_html__( '日期', 'zhiwrite-ai-writer' ); ?></th>
									<th><?php echo esc_html__( '请求数', 'zhiwrite-ai-writer' ); ?></th>
									<th><?php echo esc_html__( '总耗时(ms)', 'zhiwrite-ai-writer' ); ?></th>
									<th><?php echo esc_html__( '总 tokens', 'zhiwrite-ai-writer' ); ?></th>
								</tr>
							</thead>
							<tbody>
								<?php if ( empty( $rows_day ) ) : ?>
									<tr><td colspan="4"><?php echo esc_html__( '暂无数据。', 'zhiwrite-ai-writer' ); ?></td></tr>
								<?php else : ?>
									<?php foreach ( $rows_day as $r ) : ?>
										<tr>
											<td><?php echo esc_html( (string) $r['d'] ); ?></td>
											<td><?php echo esc_html( (int) $r['reqs'] ); ?></td>
											<td><?php echo esc_html( (int) $r['elapsed_ms'] ); ?></td>
											<td><?php echo esc_html( (int) $r['total_tokens'] ); ?></td>
										</tr>
									<?php endforeach; ?>
								<?php endif; ?>
							</tbody>
						</table>
					</div>
				</div>

				<div class="zhiwrite-td-card">
					<div class="zhiwrite-td-card__header">
						<div class="zhiwrite-td-card__title"><?php echo esc_html__( '按接口汇总（API Base URL）', 'zhiwrite-ai-writer' ); ?></div>
					</div>
					<div class="zhiwrite-td-card__body">
						<table class="widefat striped">
							<thead>
								<tr>
									<th><?php echo esc_html__( '接口', 'zhiwrite-ai-writer' ); ?></th>
									<th><?php echo esc_html__( '请求数', 'zhiwrite-ai-writer' ); ?></th>
									<th><?php echo esc_html__( '总耗时(ms)', 'zhiwrite-ai-writer' ); ?></th>
									<th><?php echo esc_html__( '总 tokens', 'zhiwrite-ai-writer' ); ?></th>
								</tr>
							</thead>
							<tbody>
								<?php if ( empty( $rows_if ) ) : ?>
									<tr><td colspan="4"><?php echo esc_html__( '暂无数据。', 'zhiwrite-ai-writer' ); ?></td></tr>
								<?php else : ?>
									<?php foreach ( $rows_if as $r ) : ?>
										<tr>
											<td><?php echo esc_html( (string) $r['api_base_url'] ); ?></td>
											<td><?php echo esc_html( (int) $r['reqs'] ); ?></td>
											<td><?php echo esc_html( (int) $r['elapsed_ms'] ); ?></td>
											<td><?php echo esc_html( (int) $r['total_tokens'] ); ?></td>
										</tr>
									<?php endforeach; ?>
								<?php endif; ?>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
		<?php
	}

	/**
	 * Ajax：导出用量 CSV（明细）。
	 */
	public static function ajax_export_usage() {
		if ( ! current_user_can( ZhiWrite_AI_Writer_Settings::capability_logs() ) ) {
			wp_send_json_error( array( 'message' => __( '权限不足。', 'zhiwrite-ai-writer' ) ), 403 );
		}
		check_ajax_referer( 'zhiwrite_ai_nonce', 'nonce' );

		$days = isset( $_POST['days'] ) ? max( 1, min( 365, (int) $_POST['days'] ) ) : 30;
		$from = gmdate( 'Y-m-d H:i:s', time() - ( $days * DAY_IN_SECONDS ) );

		global $wpdb;
		$table = ZhiWrite_AI_Writer_DB::logs_table();

		$sql = "SELECT created_at, action, user_id, model, api_base_url, elapsed_ms, prompt_tokens, completion_tokens, total_tokens, post_id
			FROM {$table}
			WHERE created_at >= %s AND total_tokens > 0
			ORDER BY id DESC
			LIMIT 20000";
		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		$rows = $wpdb->get_results( $wpdb->prepare( $sql, $from ), ARRAY_A );

		$lines   = array();
		$headers = array( 'created_at', 'action', 'user_id', 'model', 'api_base_url', 'elapsed_ms', 'prompt_tokens', 'completion_tokens', 'total_tokens', 'post_id' );
		$lines[] = self::csv_line( $headers );
		foreach ( $rows as $r ) {
			$lines[] = self::csv_line(
				array(
					isset( $r['created_at'] ) ? (string) $r['created_at'] : '',
					isset( $r['action'] ) ? (string) $r['action'] : '',
					isset( $r['user_id'] ) ? (string) $r['user_id'] : '',
					isset( $r['model'] ) ? (string) $r['model'] : '',
					isset( $r['api_base_url'] ) ? (string) $r['api_base_url'] : '',
					isset( $r['elapsed_ms'] ) ? (string) $r['elapsed_ms'] : '',
					isset( $r['prompt_tokens'] ) ? (string) $r['prompt_tokens'] : '',
					isset( $r['completion_tokens'] ) ? (string) $r['completion_tokens'] : '',
					isset( $r['total_tokens'] ) ? (string) $r['total_tokens'] : '',
					isset( $r['post_id'] ) ? (string) $r['post_id'] : '',
				)
			);
		}

		$filename = 'zhiwrite_usage_' . gmdate( 'Ymd_His' ) . '.csv';
		wp_send_json_success(
			array(
				'filename' => $filename,
				'mime'     => 'text/csv; charset=utf-8',
				'content'  => implode( "\r\n", $lines ),
			)
		);
	}

	/**
	 * Ajax: send a test email to site admin email.
	 */
	public static function ajax_test_email() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( '权限不足。', 'zhiwrite-ai-writer' ) ), 403 );
		}
		check_ajax_referer( 'zhiwrite_ai_nonce', 'nonce' );

		$to = get_option( 'admin_email' );
		$to = is_string( $to ) ? trim( $to ) : '';
		if ( '' === $to ) {
			wp_send_json_error( array( 'message' => __( '站点管理员邮箱未设置。请在“设置 -> 常规”中设置管理员邮箱地址。', 'zhiwrite-ai-writer' ) ), 400 );
		}

		$site_name = wp_specialchars_decode( (string) get_bloginfo( 'name' ), ENT_QUOTES );
		$subject   = sprintf( __( '【智写AI】测试邮件 - %s', 'zhiwrite-ai-writer' ), ( '' !== $site_name ? $site_name : 'WordPress' ) );
		$body      = "这是一封来自智写AI插件的测试邮件。\n\n若你能收到此邮件，说明站点邮件投递（wp_mail）可用。\n\n发送时间：" . current_time( 'mysql' ) . "\n站点：" . home_url() . "\n";

		$ok = self::send_mail( $to, $subject, $body, 'test' );
		if ( ! $ok ) {
			wp_send_json_error(
				array(
					'message' => __( '发送失败：发送函数返回 false。请检查系统邮件或插件 SMTP 配置。', 'zhiwrite-ai-writer' ),
				),
				200
			);
		}

		wp_send_json_success(
			array(
				'message' => sprintf( __( '已发送测试邮件到：%s', 'zhiwrite-ai-writer' ), $to ),
			)
		);
	}

	/**
	 * Ajax: generate tags for an existing post and save to post_tag taxonomy.
	 *
	 * POST: post_id
	 */
	public static function ajax_generate_tags() {
		if ( ! current_user_can( ZhiWrite_AI_Writer_Settings::capability_generate() ) ) {
			wp_send_json_error( array( 'message' => __( '权限不足。', 'zhiwrite-ai-writer' ) ), 403 );
		}
		check_ajax_referer( 'zhiwrite_ai_nonce', 'nonce' );

		$post_id = isset( $_POST['post_id'] ) ? (int) $_POST['post_id'] : 0;
		if ( $post_id <= 0 ) {
			wp_send_json_error( array( 'message' => __( '参数错误。', 'zhiwrite-ai-writer' ) ), 400 );
		}
		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			wp_send_json_error( array( 'message' => __( '无权编辑该文章。', 'zhiwrite-ai-writer' ) ), 403 );
		}

		$p = get_post( $post_id );
		if ( ! $p ) {
			wp_send_json_error( array( 'message' => __( '文章不存在。', 'zhiwrite-ai-writer' ) ), 404 );
		}

		$opts = ZhiWrite_AI_Writer_Settings::get_options();
		$block = self::budget_should_block( $opts );
		if ( ! empty( $block['block'] ) ) {
			self::budget_maybe_notify( $opts, $block );
			wp_send_json_error(
				array(
					'message' => isset( $block['message'] ) ? (string) $block['message'] : __( '已达到预算限制，已阻止生成。', 'zhiwrite-ai-writer' ),
					'code'    => 'budget_block',
				),
				200
			);
		}

		$if_id = isset( $_POST['interface_id'] ) ? sanitize_text_field( (string) wp_unslash( $_POST['interface_id'] ) ) : '';
		if ( '' === $if_id ) {
			$if_id = isset( $opts['tag_gen_interface_id'] ) && '' !== (string) $opts['tag_gen_interface_id'] ? (string) $opts['tag_gen_interface_id'] : '';
		}
		if ( '' === $if_id ) {
			$if_id = isset( $opts['default_interface_id'] ) ? (string) $opts['default_interface_id'] : '';
		}
		$iface = ZhiWrite_AI_Writer_Settings::get_interface( $if_id );
		$model = isset( $_POST['model'] ) ? sanitize_text_field( (string) wp_unslash( $_POST['model'] ) ) : '';
		if ( '' === $model ) {
			$model = isset( $opts['tag_gen_model'] ) && '' !== (string) $opts['tag_gen_model'] ? (string) $opts['tag_gen_model'] : '';
		}
		if ( '' === $model ) {
			$model = ( '' !== (string) ( isset( $iface['model'] ) ? (string) $iface['model'] : '' ) ) ? (string) $iface['model'] : (string) ( isset( $opts['model'] ) ? $opts['model'] : '' );
		}
		$tag_count = isset( $_POST['tag_count'] ) ? (int) $_POST['tag_count'] : ( isset( $opts['tag_gen_count'] ) ? (int) $opts['tag_gen_count'] : 10 );
		$tag_count = max( 3, min( 20, $tag_count ) );
		$apply_mode = isset( $_POST['apply_mode'] ) ? sanitize_key( (string) wp_unslash( $_POST['apply_mode'] ) ) : ( isset( $opts['tag_gen_apply_mode'] ) ? (string) $opts['tag_gen_apply_mode'] : 'append' );
		$apply_mode = in_array( $apply_mode, array( 'replace', 'append' ), true ) ? $apply_mode : 'replace';

		$title   = wp_strip_all_tags( (string) $p->post_title );
		$content = wp_strip_all_tags( (string) $p->post_content );
		$content = preg_replace( '/\s+/', ' ', (string) $content );
		if ( function_exists( 'mb_substr' ) ) {
			$content = (string) mb_substr( (string) $content, 0, 1200 );
		} else {
			$content = (string) substr( (string) $content, 0, 1200 );
		}

		// Optional outbound filtering before sending to model/logs.
		$title_for_model   = self::filter_outbound_text( (string) $title );
		$content_for_model = self::filter_outbound_text( (string) $content );

		$prompt_for_model  = sprintf( "请基于以下文章标题与正文摘要，为该文章生成 %d 个中文标签（tags）。\n", $tag_count );
		$prompt_for_model .= "要求：\n";
		$prompt_for_model .= "- 标签应简短（2-6 字为主），避免重复与过于宽泛；\n";
		$prompt_for_model .= "- 仅输出 JSON，结构遵循 system prompt；\n";
		$prompt_for_model .= "- 只需要 tags 字段有值，categories 可为空数组，其他字段可留空字符串/空数组。\n\n";
		$prompt_for_model .= "【标题】\n" . $title_for_model . "\n\n";
		$prompt_for_model .= "【正文摘要】\n" . $content_for_model . "\n";

		if ( '' === (string) $iface['api_base_url'] || '' === (string) $iface['api_key'] || '' === (string) $model ) {
			wp_send_json_error( array( 'message' => __( '接口配置不完整：请先在插件后台配置默认接口与模型。', 'zhiwrite-ai-writer' ) ), 200 );
		}

		$content_format = isset( $opts['content_format'] ) ? (string) $opts['content_format'] : ZhiWrite_AI_Writer_Settings::CONTENT_FORMAT_WP_HTML;
		$do_seo   = false;
		$do_terms = true;
		$do_disc  = false;

		$system = self::system_prompt( $do_seo, $do_terms, $do_disc, $content_format );
		$user   = self::user_prompt( $title_for_model, $prompt_for_model );

		// Model router: only applies when user did NOT manually set model.
		if ( ! isset( $_POST['model'] ) || '' === sanitize_text_field( (string) wp_unslash( $_POST['model'] ) ) ) {
			$model = self::maybe_route_model( (string) $model, (string) $prompt_for_model, $do_seo, $do_terms, $do_disc, $opts );
		}

		$fo = self::call_upstream_with_failover( $iface, $model, $system, $user, $opts, $content_format, $do_seo, $do_terms, $do_disc );
		$api_res = isset( $fo['api_res'] ) ? $fo['api_res'] : array();
		if ( isset( $fo['iface'] ) && is_array( $fo['iface'] ) ) {
			$iface = $fo['iface'];
		}
		$usage_fields = self::extract_usage_fields( is_array( $api_res ) ? $api_res : array() );

		if ( empty( $api_res['ok'] ) ) {
			self::maybe_log(
				array(
					'action'       => 'generate_tags_error',
					'model'        => (string) $model,
					'api_base_url' => (string) $iface['api_base_url'],
					'input_title'  => (string) $title_for_model,
					'input_prompt' => (string) $prompt_for_model,
					'output_text'  => '',
					'elapsed_ms'   => (int) $usage_fields['elapsed_ms'],
					'prompt_tokens' => (int) $usage_fields['prompt_tokens'],
					'completion_tokens' => (int) $usage_fields['completion_tokens'],
					'total_tokens' => (int) $usage_fields['total_tokens'],
					'post_id'      => (int) $post_id,
					'meta'         => wp_json_encode( array( 'error' => (string) $api_res['error'], 'raw' => isset( $api_res['raw'] ) ? $api_res['raw'] : '' ), JSON_UNESCAPED_UNICODE ),
				)
			);
			wp_send_json_error(
				array(
					'message' => __( '生成失败：AI 接口返回错误。', 'zhiwrite-ai-writer' ),
					'detail'  => isset( $api_res['error'] ) ? (string) $api_res['error'] : '',
				),
				200
			);
		}

		$text   = isset( $api_res['text'] ) ? (string) $api_res['text'] : '';
		$parsed = self::parse_response_json( $text );
		$tags   = isset( $parsed['tags'] ) && is_array( $parsed['tags'] ) ? $parsed['tags'] : array();
		$tags   = self::normalize_term_names( $tags );

		if ( empty( $tags ) ) {
			self::maybe_log(
				array(
					'action'       => 'generate_tags_empty',
					'model'        => (string) $model,
					'api_base_url' => (string) $iface['api_base_url'],
					'input_title'  => (string) $title_for_model,
					'input_prompt' => (string) $prompt_for_model,
					'output_text'  => '',
					'elapsed_ms'   => (int) $usage_fields['elapsed_ms'],
					'prompt_tokens' => (int) $usage_fields['prompt_tokens'],
					'completion_tokens' => (int) $usage_fields['completion_tokens'],
					'total_tokens' => (int) $usage_fields['total_tokens'],
					'post_id'      => (int) $post_id,
					'meta'         => wp_json_encode( array( 'raw' => $text ), JSON_UNESCAPED_UNICODE ),
				)
			);
			wp_send_json_error( array( 'message' => __( '生成失败：未解析到标签（tags）。', 'zhiwrite-ai-writer' ) ), 200 );
		}

		// This is an explicit user action from post list, so we write tags immediately.
		$tag_ids = array();
		foreach ( $tags as $name ) {
			$ex = term_exists( $name, 'post_tag' );
			if ( is_array( $ex ) && isset( $ex['term_id'] ) ) {
				$tag_ids[] = (int) $ex['term_id'];
				continue;
			}
			$created = wp_insert_term( $name, 'post_tag' );
			if ( is_array( $created ) && isset( $created['term_id'] ) ) {
				$tag_ids[] = (int) $created['term_id'];
			}
		}
		$tag_ids = array_values( array_unique( array_filter( array_map( 'intval', $tag_ids ) ) ) );
		if ( empty( $tag_ids ) ) {
			wp_send_json_error( array( 'message' => __( '生成成功但写入标签失败：无法创建/获取标签 ID。', 'zhiwrite-ai-writer' ) ), 200 );
		}
		$append = ( 'append' === $apply_mode );
		wp_set_post_terms( $post_id, $tag_ids, 'post_tag', $append );
		update_post_meta( (int) $post_id, '_zhiwrite_term_suggestions', wp_json_encode( array( 'categories' => array(), 'tags' => $tags ), JSON_UNESCAPED_UNICODE ) );

		self::maybe_log(
			array(
				'action'       => 'generate_tags',
				'model'        => (string) $model,
				'api_base_url' => (string) $iface['api_base_url'],
				'input_title'  => (string) $title_for_model,
				'input_prompt' => (string) $prompt_for_model,
				'output_text'  => '',
				'elapsed_ms'   => (int) $usage_fields['elapsed_ms'],
				'prompt_tokens' => (int) $usage_fields['prompt_tokens'],
				'completion_tokens' => (int) $usage_fields['completion_tokens'],
				'total_tokens' => (int) $usage_fields['total_tokens'],
				'post_id'      => (int) $post_id,
				'meta'         => wp_json_encode(
					array(
						'tags' => $tags,
						'apply_mode' => $apply_mode,
					),
					JSON_UNESCAPED_UNICODE
				),
			)
		);

		// Return the latest rendered tags HTML (so list UI matches WordPress output).
		$tags_html = get_the_term_list( (int) $post_id, 'post_tag', '', ', ', '' );
		$tags_html = is_string( $tags_html ) ? $tags_html : '';
		if ( '' === trim( $tags_html ) ) {
			$tags_html = '—';
		}

		wp_send_json_success(
			array(
				'ok'      => true,
				'message' => __( '已生成并写入标签。', 'zhiwrite-ai-writer' ),
				'postId'  => (int) $post_id,
				'tags'    => $tags,
				'tagsHtml'=> $tags_html,
			)
		);
	}

	/**
	 * Ajax: enqueue a batch of tag-generation tasks (queue mode).
	 *
	 * POST: post_ids[], interface_id, model, tag_count, apply_mode
	 */
	public static function ajax_enqueue_tags_batch() {
		if ( ! current_user_can( ZhiWrite_AI_Writer_Settings::capability_generate() ) ) {
			wp_send_json_error( array( 'message' => __( '权限不足。', 'zhiwrite-ai-writer' ) ), 403 );
		}
		check_ajax_referer( 'zhiwrite_ai_nonce', 'nonce' );

		$opts = ZhiWrite_AI_Writer_Settings::get_options();
		if ( empty( $opts['enable_queue'] ) ) {
			wp_send_json_error( array( 'message' => __( '请先在“功能配置 -> 稳定性与性能”开启后台队列（WP-Cron），再使用批量生成。', 'zhiwrite-ai-writer' ) ), 200 );
		}

		$post_ids = isset( $_POST['post_ids'] ) ? wp_unslash( $_POST['post_ids'] ) : array();
		$post_ids = is_array( $post_ids ) ? $post_ids : array();
		$post_ids = array_values( array_unique( array_filter( array_map( 'intval', $post_ids ) ) ) );
		$post_ids = array_slice( $post_ids, 0, 50 );
		if ( empty( $post_ids ) ) {
			wp_send_json_error( array( 'message' => __( '未选择文章。', 'zhiwrite-ai-writer' ) ), 200 );
		}

		$if_id = isset( $_POST['interface_id'] ) ? sanitize_text_field( (string) wp_unslash( $_POST['interface_id'] ) ) : '';
		$model = isset( $_POST['model'] ) ? sanitize_text_field( (string) wp_unslash( $_POST['model'] ) ) : '';
		$tag_count = isset( $_POST['tag_count'] ) ? (int) $_POST['tag_count'] : 10;
		$tag_count = max( 3, min( 20, $tag_count ) );
		$apply_mode = isset( $_POST['apply_mode'] ) ? sanitize_key( (string) wp_unslash( $_POST['apply_mode'] ) ) : 'append';
		$apply_mode = in_array( $apply_mode, array( 'append', 'replace' ), true ) ? $apply_mode : 'append';

		$batch_id = 'tb_' . gmdate( 'Ymd_His' ) . '_' . wp_generate_password( 6, false, false );

		$enqueued = 0;
		$skipped  = 0;

		foreach ( $post_ids as $pid ) {
			if ( $pid <= 0 ) {
				$skipped++;
				continue;
			}
			if ( ! current_user_can( 'edit_post', $pid ) ) {
				$skipped++;
				continue;
			}
			$request_id = 'tagbatch_' . $batch_id . '_' . (int) $pid;
			$payload = array(
				'task_type'    => 'generate_tags',
				'batch_id'     => (string) $batch_id,
				'post_id'      => (int) $pid,
				'interface_id' => (string) $if_id,
				'model'        => (string) $model,
				'tag_count'    => (int) $tag_count,
				'apply_mode'   => (string) $apply_mode,
			);
			ZhiWrite_AI_Writer_DB::insert_task(
				array(
					'request_id' => (string) $request_id,
					'user_id'    => get_current_user_id(),
					'status'     => ZhiWrite_AI_Writer_DB::TASK_STATUS_PENDING,
					'progress'   => 1,
					'message'    => __( '已进入队列，等待后台执行…', 'zhiwrite-ai-writer' ),
					'payload'    => wp_json_encode( $payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ),
					'post_id'    => (int) $pid,
				)
			);
			$enqueued++;
		}

		self::maybe_schedule_queue();
		// Try process once in current request (best-effort).
		self::process_queue();

		wp_send_json_success(
			array(
				'batchId'  => (string) $batch_id,
				'enqueued' => (int) $enqueued,
				'skipped'  => (int) $skipped,
				'limit'    => 50,
			)
		);
	}

	/**
	 * Ajax: query a tags batch progress by batchId.
	 *
	 * POST: batch_id
	 */
	public static function ajax_tags_batch_status() {
		if ( ! current_user_can( ZhiWrite_AI_Writer_Settings::capability_generate() ) ) {
			wp_send_json_error( array( 'message' => __( '权限不足。', 'zhiwrite-ai-writer' ) ), 403 );
		}
		check_ajax_referer( 'zhiwrite_ai_nonce', 'nonce' );

		$batch_id = isset( $_POST['batch_id'] ) ? sanitize_text_field( (string) wp_unslash( $_POST['batch_id'] ) ) : '';
		if ( '' === $batch_id ) {
			wp_send_json_error( array( 'message' => __( '参数错误。', 'zhiwrite-ai-writer' ) ), 400 );
		}

		global $wpdb;
		$table = ZhiWrite_AI_Writer_DB::tasks_table();
		$prefix = 'tagbatch_' . $batch_id . '_%';
		$user_id = get_current_user_id();
		$sql = "SELECT id, request_id, status, progress, message, post_id, updated_at, result
			FROM {$table}
			WHERE user_id = %d AND request_id LIKE %s
			ORDER BY id ASC
			LIMIT 200";
		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		$rows = $wpdb->get_results( $wpdb->prepare( $sql, $user_id, $prefix ), ARRAY_A );
		$rows = is_array( $rows ) ? $rows : array();

		$total = count( $rows );
		$done  = 0;
		$ok    = 0;
		$fail  = 0;
		$out_rows = array();

		foreach ( $rows as $r ) {
			$st = isset( $r['status'] ) ? (string) $r['status'] : '';
			if ( in_array( $st, array( ZhiWrite_AI_Writer_DB::TASK_STATUS_SUCCEEDED, ZhiWrite_AI_Writer_DB::TASK_STATUS_FAILED, ZhiWrite_AI_Writer_DB::TASK_STATUS_CANCELLED ), true ) ) {
				$done++;
			}
			if ( ZhiWrite_AI_Writer_DB::TASK_STATUS_SUCCEEDED === $st ) {
				$ok++;
			} elseif ( ZhiWrite_AI_Writer_DB::TASK_STATUS_FAILED === $st ) {
				$fail++;
			}
			$res = array();
			if ( ! empty( $r['result'] ) ) {
				$res = json_decode( (string) $r['result'], true );
				$res = is_array( $res ) ? $res : array();
			}
			$out_rows[] = array(
				'id'       => isset( $r['id'] ) ? (int) $r['id'] : 0,
				'postId'   => isset( $r['post_id'] ) ? (int) $r['post_id'] : 0,
				'status'   => $st,
				'progress' => isset( $r['progress'] ) ? (int) $r['progress'] : 0,
				'message'  => isset( $r['message'] ) ? (string) $r['message'] : '',
				'tagsHtml' => isset( $res['tagsHtml'] ) ? (string) $res['tagsHtml'] : '',
			);
		}

		wp_send_json_success(
			array(
				'batchId' => (string) $batch_id,
				'total'   => (int) $total,
				'done'    => (int) $done,
				'ok'      => (int) $ok,
				'fail'    => (int) $fail,
				'rows'    => $out_rows,
			)
		);
	}

	public static function ajax_webhook_queue_status() {
		if ( ! current_user_can( ZhiWrite_AI_Writer_Settings::capability_logs() ) ) {
			wp_send_json_error( array( 'message' => __( '权限不足。', 'zhiwrite-ai-writer' ) ), 403 );
		}
		check_ajax_referer( 'zhiwrite_ai_nonce', 'nonce' );

		global $wpdb;
		$table = ZhiWrite_AI_Writer_DB::tasks_table();
		$sql = "SELECT id, request_id, status, progress, message, updated_at, attempts
			FROM {$table}
			WHERE request_id LIKE %s
			ORDER BY updated_at DESC
			LIMIT 100";
		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		$rows = $wpdb->get_results( $wpdb->prepare( $sql, 'wh_%' ), ARRAY_A );
		$rows = is_array( $rows ) ? $rows : array();

		$out = array();
		foreach ( $rows as $r ) {
			$st = isset( $r['status'] ) ? (string) $r['status'] : '';
			$out[] = array(
				'id'         => isset( $r['id'] ) ? (int) $r['id'] : 0,
				'request_id' => isset( $r['request_id'] ) ? (string) $r['request_id'] : '',
				'status'     => $st,
				'status_label' => self::task_status_label( $st ),
				'status_badge' => self::task_status_badge_html( $st ),
				'updated_at' => isset( $r['updated_at'] ) ? (string) $r['updated_at'] : '',
				'message'    => isset( $r['message'] ) ? (string) $r['message'] : '',
				'attempts'   => isset( $r['attempts'] ) ? (int) $r['attempts'] : 0,
			);
		}

		wp_send_json_success(
			array(
				'rows' => $out,
			)
		);
	}

	public static function ajax_webhook_retry_now() {
		if ( ! current_user_can( ZhiWrite_AI_Writer_Settings::capability_logs() ) ) {
			wp_send_json_error( array( 'message' => __( '权限不足。', 'zhiwrite-ai-writer' ) ), 403 );
		}
		check_ajax_referer( 'zhiwrite_ai_nonce', 'nonce' );

		$id = isset( $_POST['id'] ) ? (int) $_POST['id'] : 0;
		if ( $id <= 0 ) {
			wp_send_json_error( array( 'message' => __( '参数错误。', 'zhiwrite-ai-writer' ) ), 400 );
		}

		global $wpdb;
		$table = ZhiWrite_AI_Writer_DB::tasks_table();
		$sql   = "SELECT payload, status FROM {$table} WHERE id = %d LIMIT 1";
		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		$row = $wpdb->get_row( $wpdb->prepare( $sql, $id ), ARRAY_A );
		if ( ! is_array( $row ) ) {
			wp_send_json_error( array( 'message' => __( '任务不存在。', 'zhiwrite-ai-writer' ) ), 404 );
		}

		$payload = array();
		if ( ! empty( $row['payload'] ) ) {
			$payload = json_decode( (string) $row['payload'], true );
		}
		$payload = is_array( $payload ) ? $payload : array();
		if ( 'webhook_retry' !== ( isset( $payload['task_type'] ) ? (string) $payload['task_type'] : '' ) ) {
			wp_send_json_error( array( 'message' => __( '该任务不是 Webhook 重试任务。', 'zhiwrite-ai-writer' ) ), 400 );
		}

		$payload['next_ts'] = time();
		ZhiWrite_AI_Writer_DB::update_task(
			$id,
			array(
				'status'       => ZhiWrite_AI_Writer_DB::TASK_STATUS_PENDING,
				'progress'     => 1,
				'message'      => __( '已手动触发：等待立即重试…', 'zhiwrite-ai-writer' ),
				'payload'      => wp_json_encode( $payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ),
				'locked_until' => null,
			)
		);
		self::maybe_schedule_queue();
		self::process_queue();

		wp_send_json_success( array( 'ok' => true, 'message' => __( '已触发重试。', 'zhiwrite-ai-writer' ) ) );
	}

	/**
	 * Ajax：实时拉取队列任务状态。
	 */
	public static function ajax_queue_status() {
		if ( ! current_user_can( ZhiWrite_AI_Writer_Settings::capability_logs() ) ) {
			wp_send_json_error( array( 'message' => __( '权限不足。', 'zhiwrite-ai-writer' ) ), 403 );
		}
		check_ajax_referer( 'zhiwrite_ai_nonce', 'nonce' );

		$filters = array();
		if ( isset( $_POST['status'] ) ) {
			$filters['status'] = sanitize_key( (string) wp_unslash( $_POST['status'] ) );
		}
		if ( isset( $_POST['user_id'] ) ) {
			$filters['user_id'] = (int) $_POST['user_id'];
		}

		$tasks = ZhiWrite_AI_Writer_DB::get_tasks( 50, 0, $filters );
		$total = ZhiWrite_AI_Writer_DB::count_tasks( $filters );

		$rows = array();
		foreach ( $tasks as $row ) {
			$user = ! empty( $row['user_id'] ) ? get_user_by( 'id', (int) $row['user_id'] ) : null;
			$status = isset( $row['status'] ) ? (string) $row['status'] : '';
			$rows[] = array(
				'id'          => isset( $row['id'] ) ? (int) $row['id'] : 0,
				'created_at'  => isset( $row['created_at'] ) ? (string) $row['created_at'] : '',
				'updated_at'  => isset( $row['updated_at'] ) ? (string) $row['updated_at'] : '',
				'user'        => $user ? (string) $user->user_login : '-',
				'status'      => $status,
				'status_label'=> self::task_status_label( $status ),
				'progress'    => isset( $row['progress'] ) ? (int) $row['progress'] : 0,
				'message'     => isset( $row['message'] ) ? (string) $row['message'] : '',
				'locked_until'=> isset( $row['locked_until'] ) && '' !== (string) $row['locked_until'] ? (string) $row['locked_until'] : '-',
				'can_cancel'  => in_array( $status, array( ZhiWrite_AI_Writer_DB::TASK_STATUS_PENDING, ZhiWrite_AI_Writer_DB::TASK_STATUS_RUNNING ), true ) ? 1 : 0,
				'can_delete'  => in_array( $status, array( ZhiWrite_AI_Writer_DB::TASK_STATUS_PENDING, ZhiWrite_AI_Writer_DB::TASK_STATUS_RUNNING ), true ) ? 0 : 1,
			);
		}

		wp_send_json_success(
			array(
				'total' => (int) $total,
				'tasks' => $rows,
			)
		);
	}

	/**
	 * Ajax：删除单个队列任务。
	 */
	public static function ajax_delete_task() {
		if ( ! current_user_can( ZhiWrite_AI_Writer_Settings::capability_logs() ) ) {
			wp_send_json_error( array( 'message' => __( '权限不足。', 'zhiwrite-ai-writer' ) ), 403 );
		}
		check_ajax_referer( 'zhiwrite_ai_nonce', 'nonce' );

		$id = isset( $_POST['id'] ) ? (int) $_POST['id'] : 0;
		if ( $id <= 0 ) {
			wp_send_json_error( array( 'message' => __( '参数错误。', 'zhiwrite-ai-writer' ) ), 400 );
		}

		// Safety: refuse deleting active tasks; stop/cancel first.
		$task = null;
		global $wpdb;
		if ( isset( $wpdb ) && is_object( $wpdb ) ) {
			$table = ZhiWrite_AI_Writer_DB::tasks_table();
			$sql   = "SELECT status FROM {$table} WHERE id = %d LIMIT 1";
			// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
			$task = $wpdb->get_row( $wpdb->prepare( $sql, $id ), ARRAY_A );
		}
		$status = is_array( $task ) && isset( $task['status'] ) ? (string) $task['status'] : '';
		if ( in_array( $status, array( ZhiWrite_AI_Writer_DB::TASK_STATUS_PENDING, ZhiWrite_AI_Writer_DB::TASK_STATUS_RUNNING ), true ) ) {
			wp_send_json_error( array( 'message' => __( '该任务正在执行或未执行，请先停止/取消后再删除。', 'zhiwrite-ai-writer' ) ), 409 );
		}

		$ok = ZhiWrite_AI_Writer_DB::delete_task( $id );
		if ( ! $ok ) {
			wp_send_json_error( array( 'message' => __( '删除失败或任务不存在。', 'zhiwrite-ai-writer' ) ), 500 );
		}

		wp_send_json_success(
			array(
				'ok'      => true,
				'message' => __( '任务已删除。', 'zhiwrite-ai-writer' ),
			)
		);
	}

	/**
	 * Parse logs filters from request array.
	 *
	 * @param array $req
	 * @return array
	 */
	private static function logs_filters_from_request( $req ) {
		$req = is_array( $req ) ? $req : array();
		$out = array();

		$out['action']  = isset( $req['log_action'] ) ? sanitize_text_field( (string) wp_unslash( $req['log_action'] ) ) : '';
		$out['model']   = isset( $req['model'] ) ? sanitize_text_field( (string) wp_unslash( $req['model'] ) ) : '';
		$out['user_id'] = isset( $req['user_id'] ) ? (int) $req['user_id'] : 0;
		$out['from']    = isset( $req['from'] ) ? sanitize_text_field( (string) wp_unslash( $req['from'] ) ) : '';
		$out['to']      = isset( $req['to'] ) ? sanitize_text_field( (string) wp_unslash( $req['to'] ) ) : '';
		$out['q']       = isset( $req['q'] ) ? sanitize_text_field( (string) wp_unslash( $req['q'] ) ) : '';

		// Normalize empty.
		foreach ( $out as $k => $v ) {
			if ( is_string( $v ) ) {
				$out[ $k ] = trim( $v );
			}
		}
		return $out;
	}

	/**
	 * Convert a stored/received datetime into HTML datetime-local value (Y-m-d\TH:i).
	 *
	 * Accepts:
	 * - mysql: 2026-03-18 09:30:00
	 * - mysql-ish: 2026-03-18 09:30
	 * - datetime-local: 2026-03-18T09:30 or 2026-03-18T09:30:00
	 *
	 * Returns empty string when invalid.
	 *
	 * @param string $raw
	 * @return string
	 */
	private static function datetime_to_local_input_value( $raw ) {
		$raw = is_string( $raw ) ? trim( $raw ) : '';
		if ( '' === $raw ) {
			return '';
		}

		$raw = str_replace( 'T', ' ', $raw );
		if ( preg_match( '/^\d{4}-\d{2}-\d{2}\s\d{2}:\d{2}$/', $raw ) ) {
			$raw .= ':00';
		}

		if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}\s\d{2}:\d{2}:\d{2}$/', $raw ) ) {
			return '';
		}

		$dt = \DateTime::createFromFormat( 'Y-m-d H:i:s', $raw );
		if ( ! $dt ) {
			return '';
		}

		$errors = \DateTime::getLastErrors();
		if ( is_array( $errors ) && ( ! empty( $errors['warning_count'] ) || ! empty( $errors['error_count'] ) ) ) {
			return '';
		}

		return $dt->format( 'Y-m-d\TH:i' );
	}

	/**
	 * Export logs as JSON or CSV (best-effort, filtered by request).
	 * POST: format=json|csv, filters...
	 */
	public static function ajax_export_logs() {
		if ( ! current_user_can( ZhiWrite_AI_Writer_Settings::capability_logs() ) ) {
			wp_send_json_error( array( 'message' => __( '权限不足。', 'zhiwrite-ai-writer' ) ), 403 );
		}
		check_ajax_referer( 'zhiwrite_ai_nonce', 'nonce' );

		$format = isset( $_POST['format'] ) ? sanitize_key( (string) wp_unslash( $_POST['format'] ) ) : 'json';
		$format = in_array( $format, array( 'json', 'csv' ), true ) ? $format : 'json';

		$filters = self::logs_filters_from_request( $_POST );
		// For export, bump limit a bit but keep reasonable.
		$rows = ZhiWrite_AI_Writer_DB::get_logs( 2000, 0, $filters );

		$ts       = gmdate( 'Ymd_His' );
		$filename = 'zhiwrite_logs_' . $ts . '.' . $format;

		if ( 'csv' === $format ) {
			$lines   = array();
			$headers = array( 'id', 'created_at', 'user_id', 'action', 'model', 'api_base_url', 'input_title', 'post_id' );
			$lines[] = self::csv_line( $headers );
			foreach ( $rows as $r ) {
				$lines[] = self::csv_line(
					array(
						isset( $r['id'] ) ? (string) $r['id'] : '',
						isset( $r['created_at'] ) ? (string) $r['created_at'] : '',
						isset( $r['user_id'] ) ? (string) $r['user_id'] : '',
						isset( $r['action'] ) ? (string) $r['action'] : '',
						isset( $r['model'] ) ? (string) $r['model'] : '',
						isset( $r['api_base_url'] ) ? (string) $r['api_base_url'] : '',
						isset( $r['input_title'] ) ? (string) $r['input_title'] : '',
						isset( $r['post_id'] ) ? (string) $r['post_id'] : '',
					)
				);
			}
			wp_send_json_success(
				array(
					'filename' => $filename,
					'mime'     => 'text/csv; charset=utf-8',
					'content'  => implode( "\r\n", $lines ),
				)
			);
		}

		// JSON export (truncate large fields to avoid huge payloads).
		$out = array();
		foreach ( $rows as $r ) {
			if ( isset( $r['input_prompt'] ) && is_string( $r['input_prompt'] ) && strlen( $r['input_prompt'] ) > 5000 ) {
				$r['input_prompt'] = substr( $r['input_prompt'], 0, 5000 ) . '...';
			}
			if ( isset( $r['output_text'] ) && is_string( $r['output_text'] ) && strlen( $r['output_text'] ) > 5000 ) {
				$r['output_text'] = substr( $r['output_text'], 0, 5000 ) . '...';
			}
			if ( isset( $r['meta'] ) && is_string( $r['meta'] ) && strlen( $r['meta'] ) > 8000 ) {
				$r['meta'] = substr( $r['meta'], 0, 8000 ) . '...';
			}
			$out[] = $r;
		}

		wp_send_json_success(
			array(
				'filename' => $filename,
				'mime'     => 'application/json; charset=utf-8',
				'content'  => wp_json_encode( $out, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ),
			)
		);
	}

	/**
	 * Ajax：取消单个队列任务。
	 */
	public static function ajax_cancel_task() {
		if ( ! current_user_can( ZhiWrite_AI_Writer_Settings::capability_logs() ) ) {
			wp_send_json_error( array( 'message' => __( '权限不足。', 'zhiwrite-ai-writer' ) ), 403 );
		}
		check_ajax_referer( 'zhiwrite_ai_nonce', 'nonce' );

		$id = isset( $_POST['id'] ) ? (int) $_POST['id'] : 0;
		if ( $id <= 0 ) {
			wp_send_json_error( array( 'message' => __( '参数错误。', 'zhiwrite-ai-writer' ) ), 400 );
		}

		$ok = ZhiWrite_AI_Writer_DB::cancel_task( $id );
		if ( ! $ok ) {
			wp_send_json_error( array( 'message' => __( '取消失败或任务不存在。', 'zhiwrite-ai-writer' ) ), 500 );
		}

		wp_send_json_success(
			array(
				'ok'      => true,
				'message' => __( '任务已取消。', 'zhiwrite-ai-writer' ),
			)
		);
	}

	private static function csv_line( array $cols ) {
		$escaped = array();
		foreach ( $cols as $c ) {
			$s = (string) $c;
			$s = str_replace( '"', '""', $s );
			$escaped[] = '"' . $s . '"';
		}
		return implode( ',', $escaped );
	}

	public static function ajax_export_diagnostics() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( '权限不足。', 'zhiwrite-ai-writer' ) ), 403 );
		}
		check_ajax_referer( 'zhiwrite_ai_nonce', 'nonce' );

		$opts = ZhiWrite_AI_Writer_Settings::get_options();

		// Sanitize options for export: never include API keys.
		$interfaces = isset( $opts['interfaces'] ) && is_array( $opts['interfaces'] ) ? $opts['interfaces'] : array();
		$interfaces_out = array();
		foreach ( $interfaces as $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}
			$interfaces_out[] = array(
				'id'           => isset( $row['id'] ) ? (string) $row['id'] : '',
				'name'         => isset( $row['name'] ) ? (string) $row['name'] : '',
				'api_base_url' => isset( $row['api_base_url'] ) ? (string) $row['api_base_url'] : '',
				'model'        => isset( $row['model'] ) ? (string) $row['model'] : '',
				'has_api_key'  => ! empty( $row['api_key'] ) ? 1 : 0,
			);
		}

		$opts_out = array(
			'default_interface_id'    => isset( $opts['default_interface_id'] ) ? (string) $opts['default_interface_id'] : '',
			'timeout'                 => isset( $opts['timeout'] ) ? (int) $opts['timeout'] : 0,
			'retry_times'             => isset( $opts['retry_times'] ) ? (int) $opts['retry_times'] : 0,
			'retry_backoff_ms'        => isset( $opts['retry_backoff_ms'] ) ? (int) $opts['retry_backoff_ms'] : 0,
			'concurrency_user_max'    => isset( $opts['concurrency_user_max'] ) ? (int) $opts['concurrency_user_max'] : 0,
			'concurrency_global_max'  => isset( $opts['concurrency_global_max'] ) ? (int) $opts['concurrency_global_max'] : 0,
			'concurrency_lock_ttl'    => isset( $opts['concurrency_lock_ttl'] ) ? (int) $opts['concurrency_lock_ttl'] : 0,
			'enable_editors'          => ! empty( $opts['enable_editors'] ) ? 1 : 0,
			'cap_generate'            => isset( $opts['cap_generate'] ) ? (string) $opts['cap_generate'] : '',
			'cap_logs'                => isset( $opts['cap_logs'] ) ? (string) $opts['cap_logs'] : '',
			'default_post_status'     => isset( $opts['default_post_status'] ) ? (string) $opts['default_post_status'] : '',
			'content_format'          => isset( $opts['content_format'] ) ? (string) $opts['content_format'] : '',
			'save_logs'               => ! empty( $opts['save_logs'] ) ? 1 : 0,
			'keep_data_on_uninstall'  => ! empty( $opts['keep_data_on_uninstall'] ) ? 1 : 0,
			'interfaces'              => $interfaces_out,
		);

		// Recent logs (sanitized): keep meta but truncate large fields to avoid leaking content.
		$recent_errors = ZhiWrite_AI_Writer_DB::get_logs(
			30,
			0,
			array(
				'action' => 'generate_error',
			)
		);
		$recent_errors_out = array();
		foreach ( $recent_errors as $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}
			$meta = isset( $row['meta'] ) ? (string) $row['meta'] : '';
			if ( strlen( $meta ) > 4000 ) {
				$meta = substr( $meta, 0, 4000 ) . '...';
			}
			$recent_errors_out[] = array(
				'id'         => isset( $row['id'] ) ? (int) $row['id'] : 0,
				'created_at' => isset( $row['created_at'] ) ? (string) $row['created_at'] : '',
				'user_id'    => isset( $row['user_id'] ) ? (int) $row['user_id'] : 0,
				'action'     => isset( $row['action'] ) ? (string) $row['action'] : '',
				'model'      => isset( $row['model'] ) ? (string) $row['model'] : '',
				'api_base_url' => isset( $row['api_base_url'] ) ? (string) $row['api_base_url'] : '',
				'meta'       => $meta,
			);
		}

		$theme = function_exists( 'wp_get_theme' ) ? wp_get_theme() : null;
		$theme_name = $theme && method_exists( $theme, 'get' ) ? (string) $theme->get( 'Name' ) : '';
		$theme_ver  = $theme && method_exists( $theme, 'get' ) ? (string) $theme->get( 'Version' ) : '';

		global $wpdb;
		$payload = array(
			'exported_at' => gmdate( 'c' ),
			'site'        => array(
				'home_url' => home_url(),
				'site_url' => site_url(),
				'wp_version' => function_exists( 'get_bloginfo' ) ? get_bloginfo( 'version' ) : '',
				'language'   => function_exists( 'get_locale' ) ? get_locale() : '',
				'theme'      => trim( $theme_name . ( $theme_ver ? ' ' . $theme_ver : '' ) ),
			),
			'server'      => array(
				'php_version' => PHP_VERSION,
				'mysql_version' => method_exists( $wpdb, 'db_version' ) ? $wpdb->db_version() : '',
				'wp_memory_limit' => defined( 'WP_MEMORY_LIMIT' ) ? WP_MEMORY_LIMIT : '',
			),
			'plugin'      => array(
				'version' => defined( 'ZHIWRITE_AI_WRITER_VERSION' ) ? ZHIWRITE_AI_WRITER_VERSION : '',
			),
			'options'     => $opts_out,
			'recent_generate_errors' => $recent_errors_out,
		);

		$filename = 'zhiwrite-diagnostics-' . gmdate( 'Ymd-His' ) . '.json';
		wp_send_json_success(
			array(
				'filename' => $filename,
				'mime'     => 'application/json; charset=utf-8',
				'content'  => wp_json_encode( $payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ),
			)
		);
	}

	private static function maybe_schedule_queue() {
		if ( ! function_exists( 'wp_next_scheduled' ) || ! function_exists( 'wp_schedule_single_event' ) ) {
			return;
		}
		$next = wp_next_scheduled( 'zhiwrite_ai_process_queue' );
		if ( false === $next ) {
			wp_schedule_single_event( time() + 3, 'zhiwrite_ai_process_queue' );
		}
	}

	private static function enqueue_generation_task( $request_id, array $payload ) {
		// Safety net: ensure tables exist before enqueue (covers upgrade/no-reactivation cases).
		ZhiWrite_AI_Writer_DB::maybe_create_tables();

		$payload['request_id'] = (string) $request_id;
		$payload['queued_at']  = time();
		$task_id               = ZhiWrite_AI_Writer_DB::insert_task(
			array(
				'request_id' => (string) $request_id,
				'user_id'    => get_current_user_id(),
				'status'     => ZhiWrite_AI_Writer_DB::TASK_STATUS_PENDING,
				'progress'   => 1,
				'message'    => __( '已进入队列，等待后台执行…', 'zhiwrite-ai-writer' ),
				'payload'    => wp_json_encode( $payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ),
			)
		);

		// Do not pretend queued when DB write fails (e.g. tasks table missing).
		if ( $task_id <= 0 ) {
			$detail = '';
			global $wpdb;
			if ( isset( $wpdb ) && is_object( $wpdb ) && ! empty( $wpdb->last_error ) ) {
				$detail = (string) $wpdb->last_error;
			}
			self::generation_status_update( $request_id, 'error', __( '队列写入失败，请检查数据库表与权限。', 'zhiwrite-ai-writer' ), 0, get_current_user_id() );
			if ( '' !== $detail ) {
				self::maybe_log(
					array(
						'action' => 'queue_insert_error',
						'meta'   => wp_json_encode(
							array(
								'request_id' => (string) $request_id,
								'db_error'   => $detail,
							),
							JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
						),
					)
				);
			}
			return 0;
		}

		self::generation_status_update( $request_id, 'queued', __( '已进入队列，等待后台执行…', 'zhiwrite-ai-writer' ), 1, get_current_user_id() );
		self::maybe_schedule_queue();

		// 兼容性增强：无论 WP-Cron 是否可用，都在当前请求中“尝试”处理一次队列。
		// - 若当前任务被成功 claim，则立即进入真正执行流程，前端很快能看到进度从 1% 往后走；
		// - 若已经有其他进程/请求在运行队列，则 claim 失败，这里不会重复执行，后续仍可由 WP-Cron 接力。
		if ( method_exists( __CLASS__, 'process_queue' ) ) {
			self::process_queue();
		}

		return $task_id;
	}

	public static function ajax_get_task_result() {
		if ( ! current_user_can( ZhiWrite_AI_Writer_Settings::capability_generate() ) ) {
			wp_send_json_error( array( 'message' => __( '权限不足。', 'zhiwrite-ai-writer' ) ), 403 );
		}
		check_ajax_referer( 'zhiwrite_ai_nonce', 'nonce' );

		$request_id = isset( $_POST['request_id'] ) ? sanitize_key( (string) wp_unslash( $_POST['request_id'] ) ) : '';
		if ( '' === $request_id ) {
			wp_send_json_error( array( 'message' => __( '参数错误。', 'zhiwrite-ai-writer' ) ), 400 );
		}
		$task = ZhiWrite_AI_Writer_DB::get_task_by_request_id( $request_id );
		if ( ! is_array( $task ) ) {
			wp_send_json_error( array( 'message' => __( '任务不存在。', 'zhiwrite-ai-writer' ) ), 404 );
		}
		// Only owner or admin can fetch.
		if ( (int) $task['user_id'] !== (int) get_current_user_id() && ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( '无权访问该任务。', 'zhiwrite-ai-writer' ) ), 403 );
		}
		if ( ZhiWrite_AI_Writer_DB::TASK_STATUS_SUCCEEDED !== (string) $task['status'] ) {
			wp_send_json_error(
				array(
					'message' => __( '任务尚未完成。', 'zhiwrite-ai-writer' ),
					'status'  => (string) $task['status'],
				),
				200
			);
		}
		$res = array();
		if ( ! empty( $task['result'] ) ) {
			$res = json_decode( (string) $task['result'], true );
		}
		$res = is_array( $res ) ? $res : array();
		wp_send_json_success( $res );
	}

	/**
	 * WP-Cron queue processor.
	 */
	public static function process_queue() {
		$opts = ZhiWrite_AI_Writer_Settings::get_options();
		if ( empty( $opts['enable_queue'] ) ) {
			return;
		}

		$block = self::budget_should_block( $opts );
		if ( ! empty( $block['block'] ) ) {
			self::budget_maybe_notify( $opts, $block );
			// No re-schedule to avoid spamming; will resume next day or after admin changes budget.
			return;
		}

		$lock_ttl = isset( $opts['concurrency_lock_ttl'] ) ? (int) $opts['concurrency_lock_ttl'] : 300;
		$task     = ZhiWrite_AI_Writer_DB::claim_next_pending_task( $lock_ttl );
		if ( ! is_array( $task ) ) {
			return;
		}

		$task_id    = (int) $task['id'];
		$request_id = isset( $task['request_id'] ) ? (string) $task['request_id'] : '';
		$user_id    = isset( $task['user_id'] ) ? (int) $task['user_id'] : 0;
		$payload    = array();
		if ( ! empty( $task['payload'] ) ) {
			$payload = json_decode( (string) $task['payload'], true );
		}
		$payload = is_array( $payload ) ? $payload : array();

		// Support additional task types beyond full article generation.
		$task_type = isset( $payload['task_type'] ) ? sanitize_key( (string) $payload['task_type'] ) : '';
		if ( 'generate_tags' === $task_type ) {
			self::process_task_generate_tags( $task_id, $request_id, $user_id, $payload, $opts );
			return;
		}
		if ( 'webhook_retry' === $task_type ) {
			self::process_task_webhook_retry( $task_id, $request_id, $user_id, $payload, $opts );
			return;
		}

		// Start.
		ZhiWrite_AI_Writer_DB::update_task(
			$task_id,
			array(
				'status'   => ZhiWrite_AI_Writer_DB::TASK_STATUS_RUNNING,
				'progress' => 5,
				'message'  => __( '后台开始执行任务…', 'zhiwrite-ai-writer' ),
				'attempts' => isset( $task['attempts'] ) ? ( (int) $task['attempts'] + 1 ) : 1,
			)
		);
		self::generation_status_update( $request_id, 'start', __( '后台开始执行任务…', 'zhiwrite-ai-writer' ), 5, $user_id );

		$title    = isset( $payload['title'] ) ? (string) $payload['title'] : '';
		$prompt   = isset( $payload['prompt'] ) ? (string) $payload['prompt'] : '';
		$template_id = isset( $payload['template_id'] ) ? (string) $payload['template_id'] : '';
		$style_id    = isset( $payload['style_id'] ) ? (string) $payload['style_id'] : '';
		$vars_override_raw = isset( $payload['vars_override'] ) ? (string) $payload['vars_override'] : '';
		$if_id    = isset( $payload['interface_id'] ) ? (string) $payload['interface_id'] : '';
		$model    = isset( $payload['model'] ) ? (string) $payload['model'] : '';
		$do_seo   = ! empty( $payload['do_seo'] );
		$do_terms = ! empty( $payload['do_terms'] );
		$do_disc  = ! empty( $payload['do_disclaimer'] );
		$save_mode = isset( $payload['save_mode'] ) ? (string) $payload['save_mode'] : 'preview';

		$prompt = trim( $prompt );
		if ( '' === $prompt ) {
			ZhiWrite_AI_Writer_DB::update_task(
				$task_id,
				array(
					'status'   => ZhiWrite_AI_Writer_DB::TASK_STATUS_FAILED,
					'progress' => 0,
					'message'  => __( '写作需求为空。', 'zhiwrite-ai-writer' ),
					'locked_until' => null,
				)
			);
			self::generation_status_update( $request_id, 'error', __( '写作需求为空。', 'zhiwrite-ai-writer' ), 0, $user_id );
			return;
		}

		self::generation_status_update( $request_id, 'prepare', __( '读取接口配置与生成选项…', 'zhiwrite-ai-writer' ), 10, $user_id );
		$prompt_for_model_router = self::filter_outbound_text( $prompt );
		$iface     = ZhiWrite_AI_Writer_Settings::get_interface( $if_id );
		$use_model = '' !== $model ? $model : ( isset( $iface['model'] ) ? (string) $iface['model'] : '' );
		// Model router: only applies when user did NOT manually set model.
		if ( '' === $model ) {
			$use_model = self::maybe_route_model( $use_model, $prompt_for_model_router, $do_seo, $do_terms, $do_disc, $opts );
		}
		if ( '' === (string) $iface['api_base_url'] || '' === (string) $iface['api_key'] || '' === (string) $use_model ) {
			ZhiWrite_AI_Writer_DB::update_task(
				$task_id,
				array(
					'status'   => ZhiWrite_AI_Writer_DB::TASK_STATUS_FAILED,
					'progress' => 0,
					'message'  => __( '接口配置不完整。', 'zhiwrite-ai-writer' ),
					'locked_until' => null,
				)
			);
			self::generation_status_update( $request_id, 'error', __( '接口配置不完整。', 'zhiwrite-ai-writer' ), 0, $user_id );
			return;
		}

		$content_format = isset( $opts['content_format'] ) ? (string) $opts['content_format'] : ZhiWrite_AI_Writer_Settings::CONTENT_FORMAT_WP_HTML;

		// Optional outbound filtering before sending to model/logs.
		$title_for_model  = self::filter_outbound_text( $title );
		$prompt_for_model = self::filter_outbound_text( $prompt );

		self::generation_status_update( $request_id, 'prompt', __( '构建提示词（Prompt）…', 'zhiwrite-ai-writer' ), 15, $user_id );
		$system = self::system_prompt( $do_seo, $do_terms, $do_disc, $content_format );
		$system .= self::prompt_builder_system_append( $template_id, $style_id, $vars_override_raw, $title_for_model, $prompt_for_model, $opts );
		$user   = self::user_prompt( $title_for_model, $prompt_for_model );

		self::generation_status_update( $request_id, 'request', __( '请求 AI 接口生成内容…', 'zhiwrite-ai-writer' ), 30, $user_id );
		// Cache check (optional, queue mode).
		$cache_key = '';
		$cache_ttl = 0;
		if ( ! empty( $opts['cache_enabled'] ) ) {
			$cache_ttl = max( 1, (int) ( isset( $opts['cache_ttl_minutes'] ) ? (int) $opts['cache_ttl_minutes'] : 60 ) ) * 60;
			$scope = isset( $opts['cache_scope'] ) ? (string) $opts['cache_scope'] : 'strict';
			$parts = array(
				'system' => $system,
				'user'   => $user,
			);
			if ( 'strict' === $scope ) {
				$parts['api_base_url'] = (string) $iface['api_base_url'];
				$parts['model']        = (string) $use_model;
				$parts['format']       = (string) $content_format;
				$parts['do_seo']        = $do_seo ? 1 : 0;
				$parts['do_terms']      = $do_terms ? 1 : 0;
				$parts['do_disc']       = $do_disc ? 1 : 0;
			}
			$cache_key = self::cache_key_for_generation( $parts );
			$cached = self::cache_get( $cache_key );
			if ( is_array( $cached ) && isset( $cached['api_res'] ) && is_array( $cached['api_res'] ) ) {
				$api_res = $cached['api_res'];
				$api_res['meta']['cache_hit'] = 1;
			}
		}

		if ( ! isset( $api_res ) ) {
			$fo = self::call_upstream_with_failover( $iface, $use_model, $system, $user, $opts, $content_format, $do_seo, $do_terms, $do_disc );
			$api_res = isset( $fo['api_res'] ) ? $fo['api_res'] : array();
			if ( isset( $fo['iface'] ) && is_array( $fo['iface'] ) ) {
				$iface = $fo['iface'];
			}
			if ( '' !== (string) $cache_key && ! empty( $api_res['ok'] ) && $cache_ttl > 0 ) {
				self::cache_set( $cache_key, array( 'api_res' => $api_res, 'saved_at' => time() ), $cache_ttl );
			}
		}

		$usage_fields = self::extract_usage_fields( is_array( $api_res ) ? $api_res : array() );

		if ( empty( $api_res['ok'] ) ) {
			self::generation_status_update( $request_id, 'error', __( 'AI 接口返回错误。', 'zhiwrite-ai-writer' ), 0, $user_id );
			self::maybe_log(
				array(
					'action'       => 'generate_error',
					'model'        => $use_model,
					'api_base_url' => (string) $iface['api_base_url'],
					'input_title'  => $title_for_model,
					'input_prompt' => $prompt_for_model,
					'output_text'  => '',
					'elapsed_ms'   => (int) $usage_fields['elapsed_ms'],
					'prompt_tokens' => (int) $usage_fields['prompt_tokens'],
					'completion_tokens' => (int) $usage_fields['completion_tokens'],
					'total_tokens' => (int) $usage_fields['total_tokens'],
					'meta'         => wp_json_encode( array( 'error' => (string) $api_res['error'], 'raw' => $api_res['raw'] ), JSON_UNESCAPED_UNICODE ),
				)
			);
			ZhiWrite_AI_Writer_DB::update_task(
				$task_id,
				array(
					'status'   => ZhiWrite_AI_Writer_DB::TASK_STATUS_FAILED,
					'progress' => 0,
					'message'  => __( 'AI 接口返回错误。', 'zhiwrite-ai-writer' ),
					'result'   => null,
					'locked_until' => null,
				)
			);
			self::webhook_send(
				'generation_failed',
				array(
					'request_id'   => (string) $request_id,
					'task_id'      => (int) $task_id,
					'error'        => (string) $api_res['error'],
					'error_code'   => (string) $api_res['error_code'],
					'api_base_url' => (string) $iface['api_base_url'],
					'model'        => (string) $use_model,
				)
			);
			return;
		}

		self::generation_status_update( $request_id, 'parse', __( '解析生成结果…', 'zhiwrite-ai-writer' ), 65, $user_id );
		$text = isset( $api_res['text'] ) ? (string) $api_res['text'] : '';
		$parsed = self::parse_response_json( $text );

		$out = array(
			'title'         => '' !== (string) $parsed['title'] ? (string) $parsed['title'] : $title,
			'excerpt'       => (string) $parsed['excerpt'],
			'content'       => (string) $parsed['content'],
			'contentFormat' => (string) $content_format,
			'seo'           => array(
				'slug'         => (string) $parsed['slug'],
				'focusKeyword' => (string) $parsed['focus_keyword'],
			),
			'terms'         => array(
				'categories' => isset( $parsed['categories'] ) ? $parsed['categories'] : array(),
				'tags'       => isset( $parsed['tags'] ) ? $parsed['tags'] : array(),
			),
			'postId'        => 0,
			'saved'         => 0,
			'editUrl'       => '',
		);

		$out['seoHints'] = self::seo_hints(
			(string) $out['title'],
			(string) $out['excerpt'],
			(string) $out['content'],
			isset( $parsed['focus_keyword'] ) ? (string) $parsed['focus_keyword'] : '',
			(string) $content_format
		);

		// Internal links (queue mode).
		$opts_now = ZhiWrite_AI_Writer_Settings::get_options();
		$out['internalLinks'] = array( 'enabled' => ! empty( $opts_now['internal_links_enabled'] ) );
		if ( ! empty( $opts_now['internal_links_enabled'] ) ) {
			$max_links = isset( $opts_now['internal_links_max'] ) ? (int) $opts_now['internal_links_max'] : 3;
			$posi      = isset( $opts_now['internal_links_position'] ) ? (string) $opts_now['internal_links_position'] : 'after_h2_1';
			$strat     = isset( $opts_now['internal_links_strategy'] ) ? (string) $opts_now['internal_links_strategy'] : 'keyword';
			$out['internalLinks']['position'] = $posi;
			$out['internalLinks']['strategy'] = $strat;
			$links = self::internal_links_suggest( (string) $out['title'], isset( $parsed['focus_keyword'] ) ? (string) $parsed['focus_keyword'] : '', $max_links );
			$applied = self::internal_links_apply( (string) $out['content'], (string) $content_format, $links, $posi );
			$out['content'] = (string) $applied['content'];
			$out['internalLinks']['inserted'] = isset( $applied['inserted'] ) ? (int) $applied['inserted'] : 0;
			$out['internalLinks']['links'] = $links;
		}

		// Excerpt/lead (queue mode).
		$tmp = self::apply_excerpt_and_lead(
			array(
				'excerpt' => (string) $out['excerpt'],
				'content' => (string) $out['content'],
			),
			(string) $content_format
		);
		if ( is_array( $tmp ) ) {
			$out['excerpt'] = isset( $tmp['excerpt'] ) ? (string) $tmp['excerpt'] : (string) $out['excerpt'];
			$out['content'] = isset( $tmp['content'] ) ? (string) $tmp['content'] : (string) $out['content'];
		}

		// TOC (queue mode).
		$out['toc'] = array( 'enabled' => ! empty( $opts_now['toc_enabled'] ) );
		if ( ! empty( $opts_now['toc_enabled'] ) ) {
			$minh = isset( $opts_now['toc_min_headings'] ) ? (int) $opts_now['toc_min_headings'] : 3;
			$posi = isset( $opts_now['toc_position'] ) ? (string) $opts_now['toc_position'] : 'after_lead';
			$inc3 = ! empty( $opts_now['toc_include_h3'] );
			$ap   = self::toc_apply( (string) $out['content'], (string) $content_format, $posi, $minh, $inc3 );
			$out['content'] = (string) $ap['content'];
			$out['toc']['inserted'] = isset( $ap['inserted'] ) ? (int) $ap['inserted'] : 0;
			$out['toc']['position'] = $posi;
			$out['toc']['include_h3'] = $inc3 ? 1 : 0;
		}

		// FAQ (queue mode).
		$out['faq'] = array( 'enabled' => ! empty( $opts_now['faq_enabled'] ) );
		if ( ! empty( $opts_now['faq_enabled'] ) ) {
			$cnt = isset( $opts_now['faq_count'] ) ? (int) $opts_now['faq_count'] : 5;
			$pos = isset( $opts_now['faq_position'] ) ? (string) $opts_now['faq_position'] : 'end';
			$faq = self::faq_normalize( isset( $parsed['faq'] ) ? $parsed['faq'] : array(), $cnt );
			$apf = self::faq_apply( (string) $out['content'], (string) $content_format, $faq, $pos );
			$out['content'] = (string) $apf['content'];
			$out['faq']['inserted'] = isset( $apf['inserted'] ) ? (int) $apf['inserted'] : 0;
			$out['faq']['position'] = $pos;
			$out['faq']['items'] = $faq;
		}

		// Content safety check (queue mode).
		$safety = self::content_safety_apply( (string) $out['content'], 'content' );
		if ( ! empty( $safety['hits'] ) ) {
			if ( 'block' === (string) $safety['action'] && empty( $safety['ok'] ) ) {
				self::generation_status_update( $request_id, 'error', __( '内容安全拦截：命中敏感词。', 'zhiwrite-ai-writer' ), 0, $user_id );
				ZhiWrite_AI_Writer_DB::update_task(
					$task_id,
					array(
						'status'       => ZhiWrite_AI_Writer_DB::TASK_STATUS_FAILED,
						'progress'     => 0,
						'message'      => __( '内容安全拦截：命中敏感词。', 'zhiwrite-ai-writer' ),
						'result'       => null,
						'locked_until' => null,
					)
				);
				self::maybe_log(
					array(
						'action'       => 'content_safety_block',
						'model'        => $use_model,
						'api_base_url' => (string) $iface['api_base_url'],
						'input_title'  => $title_for_model,
						'input_prompt' => $prompt_for_model,
						'output_text'  => '',
						'meta'         => wp_json_encode( array( 'hits' => $safety['hits'], 'message' => $safety['message'] ), JSON_UNESCAPED_UNICODE ),
					)
				);
				return;
			}
			if ( 'replace' === (string) $safety['action'] && ! empty( $safety['text'] ) ) {
				$out['content'] = (string) $safety['text'];
			}
			$out['safety'] = array(
				'action'  => isset( $safety['action'] ) ? (string) $safety['action'] : '',
				'hits'    => isset( $safety['hits'] ) ? $safety['hits'] : array(),
				'message' => isset( $safety['message'] ) ? (string) $safety['message'] : '',
			);
		} else {
			$out['safety'] = array(
				'action'  => isset( $safety['action'] ) ? (string) $safety['action'] : '',
				'hits'    => array(),
				'message' => '',
			);
		}

		// Save policy: draft/publish/preview.
		$post_id = 0;
		if ( in_array( $save_mode, array( 'draft', 'publish' ), true ) ) {
			self::generation_status_update( $request_id, 'save', __( '保存文章…', 'zhiwrite-ai-writer' ), 80, $user_id );
			$postarr = array(
				'post_title'   => (string) $out['title'],
				'post_content' => (string) $out['content'],
				'post_excerpt' => (string) $out['excerpt'],
				'post_status'  => (string) $save_mode,
				'post_type'    => 'post',
				'post_author'  => $user_id,
			);
			$post_id = (int) wp_insert_post( $postarr, true );
			if ( $post_id > 0 ) {
				$out['saved']   = 1;
				$out['postId']  = (int) $post_id;
				$out['editUrl'] = get_edit_post_link( (int) $post_id, 'raw' );
				if ( $do_terms && ! self::should_require_terms_confirm() ) {
					$cats = isset( $parsed['categories'] ) && is_array( $parsed['categories'] ) ? $parsed['categories'] : array();
					$tags = isset( $parsed['tags'] ) && is_array( $parsed['tags'] ) ? $parsed['tags'] : array();
					self::apply_terms_to_post( (int) $post_id, $cats, $tags );
					update_post_meta( (int) $post_id, '_zhiwrite_term_suggestions', wp_json_encode( array( 'categories' => $cats, 'tags' => $tags ), JSON_UNESCAPED_UNICODE ) );
				}
				self::webhook_send(
					'generation_saved',
					array(
						'request_id'   => (string) $request_id,
						'task_id'      => (int) $task_id,
						'post_id'      => (int) $post_id,
						'edit_url'     => get_edit_post_link( (int) $post_id, 'raw' ),
						'api_base_url' => (string) $iface['api_base_url'],
						'model'        => (string) $use_model,
						'title'        => (string) $out['title'],
					)
				);
			}
		}

		self::generation_status_update( $request_id, 'done', __( '任务完成。', 'zhiwrite-ai-writer' ), 100, $user_id );
		ZhiWrite_AI_Writer_DB::update_task(
			$task_id,
			array(
				'status'       => ZhiWrite_AI_Writer_DB::TASK_STATUS_SUCCEEDED,
				'progress'     => 100,
				'message'      => __( '任务完成。', 'zhiwrite-ai-writer' ),
				'result'       => wp_json_encode( $out, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ),
				'post_id'      => $post_id,
				'locked_until' => null,
			)
		);
		if ( empty( $out['saved'] ) ) {
			self::webhook_send(
				'generation_preview',
				array(
					'request_id'   => (string) $request_id,
					'task_id'      => (int) $task_id,
					'api_base_url' => (string) $iface['api_base_url'],
					'model'        => (string) $use_model,
					'title'        => (string) $out['title'],
				)
			);
		}

		// Usage log (queue mode).
		$cache_hit = ! empty( $api_res['meta'] ) && is_array( $api_res['meta'] ) && ! empty( $api_res['meta']['cache_hit'] ) ? 1 : 0;
		self::maybe_log(
			array(
				'action'       => 'generate',
				'model'        => $use_model,
				'api_base_url' => (string) $iface['api_base_url'],
				'input_title'  => $title_for_model,
				'input_prompt' => $prompt_for_model,
				'output_text'  => (string) $out['content'],
				'elapsed_ms'   => (int) $usage_fields['elapsed_ms'],
				'prompt_tokens' => (int) $usage_fields['prompt_tokens'],
				'completion_tokens' => (int) $usage_fields['completion_tokens'],
				'total_tokens' => (int) $usage_fields['total_tokens'],
				'post_id'      => $post_id,
				'meta'         => wp_json_encode(
					array(
						'raw'              => $api_res['raw'],
						'cache_hit'        => $cache_hit,
						'template_id'      => $template_id,
						'style_id'         => $style_id,
						'prompt_tokens'     => (int) $usage_fields['prompt_tokens'],
						'completion_tokens' => (int) $usage_fields['completion_tokens'],
						'total_tokens'      => (int) $usage_fields['total_tokens'],
					),
					JSON_UNESCAPED_UNICODE
				),
			)
		);

		// If more tasks remain, schedule again.
		self::maybe_schedule_queue();
	}

	/**
	 * Queue task: generate tags for an existing post and save.
	 *
	 * Payload: { task_type=generate_tags, post_id, interface_id, model, tag_count, apply_mode, batch_id }
	 */
	private static function process_task_generate_tags( $task_id, $request_id, $user_id, array $payload, array $opts ) {
		$task_id    = (int) $task_id;
		$request_id = (string) $request_id;
		$user_id    = (int) $user_id;
		$post_id    = isset( $payload['post_id'] ) ? (int) $payload['post_id'] : 0;

		if ( $post_id <= 0 ) {
			ZhiWrite_AI_Writer_DB::update_task(
				$task_id,
				array(
					'status'       => ZhiWrite_AI_Writer_DB::TASK_STATUS_FAILED,
					'progress'     => 0,
					'message'      => __( '参数错误：post_id 为空。', 'zhiwrite-ai-writer' ),
					'locked_until' => null,
				)
			);
			self::generation_status_update( $request_id, 'error', __( '参数错误：post_id 为空。', 'zhiwrite-ai-writer' ), 0, $user_id );
			return;
		}

		$p = get_post( $post_id );
		if ( ! $p ) {
			ZhiWrite_AI_Writer_DB::update_task(
				$task_id,
				array(
					'status'       => ZhiWrite_AI_Writer_DB::TASK_STATUS_FAILED,
					'progress'     => 0,
					'message'      => __( '文章不存在。', 'zhiwrite-ai-writer' ),
					'locked_until' => null,
					'post_id'      => $post_id,
				)
			);
			self::generation_status_update( $request_id, 'error', __( '文章不存在。', 'zhiwrite-ai-writer' ), 0, $user_id );
			return;
		}

		ZhiWrite_AI_Writer_DB::update_task(
			$task_id,
			array(
				'progress' => 10,
				'message'  => __( '准备生成标签…', 'zhiwrite-ai-writer' ),
				'post_id'  => $post_id,
			)
		);
		self::generation_status_update( $request_id, 'prepare', __( '准备生成标签…', 'zhiwrite-ai-writer' ), 10, $user_id );

		// Budget guard.
		$block = self::budget_should_block( $opts );
		if ( ! empty( $block['block'] ) ) {
			self::budget_maybe_notify( $opts, $block );
			ZhiWrite_AI_Writer_DB::update_task(
				$task_id,
				array(
					'status'       => ZhiWrite_AI_Writer_DB::TASK_STATUS_FAILED,
					'progress'     => 0,
					'message'      => isset( $block['message'] ) ? (string) $block['message'] : __( '预算限制：已阻止生成。', 'zhiwrite-ai-writer' ),
					'locked_until' => null,
				)
			);
			self::generation_status_update( $request_id, 'error', __( '预算限制：已阻止生成。', 'zhiwrite-ai-writer' ), 0, $user_id );
			return;
		}

		$if_id = isset( $payload['interface_id'] ) ? sanitize_text_field( (string) $payload['interface_id'] ) : '';
		if ( '' === $if_id ) {
			$if_id = isset( $opts['tag_gen_interface_id'] ) && '' !== (string) $opts['tag_gen_interface_id'] ? (string) $opts['tag_gen_interface_id'] : '';
		}
		if ( '' === $if_id ) {
			$if_id = isset( $opts['default_interface_id'] ) ? (string) $opts['default_interface_id'] : '';
		}
		$iface = ZhiWrite_AI_Writer_Settings::get_interface( $if_id );

		$model = isset( $payload['model'] ) ? sanitize_text_field( (string) $payload['model'] ) : '';
		if ( '' === $model ) {
			$model = isset( $opts['tag_gen_model'] ) && '' !== (string) $opts['tag_gen_model'] ? (string) $opts['tag_gen_model'] : '';
		}
		if ( '' === $model ) {
			$model = ( '' !== (string) ( isset( $iface['model'] ) ? (string) $iface['model'] : '' ) ) ? (string) $iface['model'] : (string) ( isset( $opts['model'] ) ? $opts['model'] : '' );
		}

		$tag_count = isset( $payload['tag_count'] ) ? (int) $payload['tag_count'] : ( isset( $opts['tag_gen_count'] ) ? (int) $opts['tag_gen_count'] : 10 );
		$tag_count = max( 3, min( 20, $tag_count ) );

		$apply_mode = isset( $payload['apply_mode'] ) ? sanitize_key( (string) $payload['apply_mode'] ) : ( isset( $opts['tag_gen_apply_mode'] ) ? (string) $opts['tag_gen_apply_mode'] : 'append' );
		$apply_mode = in_array( $apply_mode, array( 'replace', 'append' ), true ) ? $apply_mode : 'append';

		if ( '' === (string) $iface['api_base_url'] || '' === (string) $iface['api_key'] || '' === (string) $model ) {
			ZhiWrite_AI_Writer_DB::update_task(
				$task_id,
				array(
					'status'       => ZhiWrite_AI_Writer_DB::TASK_STATUS_FAILED,
					'progress'     => 0,
					'message'      => __( '接口配置不完整。', 'zhiwrite-ai-writer' ),
					'locked_until' => null,
				)
			);
			self::generation_status_update( $request_id, 'error', __( '接口配置不完整。', 'zhiwrite-ai-writer' ), 0, $user_id );
			return;
		}

		$title   = wp_strip_all_tags( (string) $p->post_title );
		$content = wp_strip_all_tags( (string) $p->post_content );
		$content = preg_replace( '/\s+/', ' ', (string) $content );
		if ( function_exists( 'mb_substr' ) ) {
			$content = (string) mb_substr( (string) $content, 0, 1200 );
		} else {
			$content = (string) substr( (string) $content, 0, 1200 );
		}
		$title_for_model   = self::filter_outbound_text( (string) $title );
		$content_for_model = self::filter_outbound_text( (string) $content );

		$prompt_for_model  = sprintf( "请基于以下文章标题与正文摘要，为该文章生成 %d 个中文标签（tags）。\n", $tag_count );
		$prompt_for_model .= "要求：\n";
		$prompt_for_model .= "- 标签应简短（2-6 字为主），避免重复与过于宽泛；\n";
		$prompt_for_model .= "- 仅输出 JSON，结构遵循 system prompt；\n";
		$prompt_for_model .= "- 只需要 tags 字段有值，categories 可为空数组，其他字段可留空字符串/空数组。\n\n";
		$prompt_for_model .= "【标题】\n" . $title_for_model . "\n\n";
		$prompt_for_model .= "【正文摘要】\n" . $content_for_model . "\n";

		$content_format = isset( $opts['content_format'] ) ? (string) $opts['content_format'] : ZhiWrite_AI_Writer_Settings::CONTENT_FORMAT_WP_HTML;
		$do_seo   = false;
		$do_terms = true;
		$do_disc  = false;

		$system = self::system_prompt( $do_seo, $do_terms, $do_disc, $content_format );
		$user   = self::user_prompt( $title_for_model, $prompt_for_model );

		$model = self::maybe_route_model( (string) $model, (string) $prompt_for_model, $do_seo, $do_terms, $do_disc, $opts );

		ZhiWrite_AI_Writer_DB::update_task(
			$task_id,
			array(
				'progress' => 35,
				'message'  => __( '请求接口生成标签…', 'zhiwrite-ai-writer' ),
			)
		);
		self::generation_status_update( $request_id, 'request', __( '请求接口生成标签…', 'zhiwrite-ai-writer' ), 35, $user_id );

		$fo = self::call_upstream_with_failover( $iface, $model, $system, $user, $opts, $content_format, $do_seo, $do_terms, $do_disc );
		$api_res = isset( $fo['api_res'] ) ? $fo['api_res'] : array();
		if ( isset( $fo['iface'] ) && is_array( $fo['iface'] ) ) {
			$iface = $fo['iface'];
		}
		$usage_fields = self::extract_usage_fields( is_array( $api_res ) ? $api_res : array() );

		if ( empty( $api_res['ok'] ) ) {
			self::maybe_log(
				array(
					'action'       => 'generate_tags_error',
					'model'        => (string) $model,
					'api_base_url' => (string) $iface['api_base_url'],
					'input_title'  => (string) $title_for_model,
					'input_prompt' => (string) $prompt_for_model,
					'output_text'  => '',
					'elapsed_ms'   => (int) $usage_fields['elapsed_ms'],
					'prompt_tokens' => (int) $usage_fields['prompt_tokens'],
					'completion_tokens' => (int) $usage_fields['completion_tokens'],
					'total_tokens' => (int) $usage_fields['total_tokens'],
					'post_id'      => (int) $post_id,
					'meta'         => wp_json_encode( array( 'error' => (string) $api_res['error'], 'raw' => isset( $api_res['raw'] ) ? $api_res['raw'] : '' ), JSON_UNESCAPED_UNICODE ),
				)
			);

			ZhiWrite_AI_Writer_DB::update_task(
				$task_id,
				array(
					'status'       => ZhiWrite_AI_Writer_DB::TASK_STATUS_FAILED,
					'progress'     => 0,
					'message'      => __( 'AI 接口返回错误。', 'zhiwrite-ai-writer' ),
					'result'       => null,
					'locked_until' => null,
				)
			);
			self::generation_status_update( $request_id, 'error', __( 'AI 接口返回错误。', 'zhiwrite-ai-writer' ), 0, $user_id );
			return;
		}

		$text   = isset( $api_res['text'] ) ? (string) $api_res['text'] : '';
		$parsed = self::parse_response_json( $text );
		$tags   = isset( $parsed['tags'] ) && is_array( $parsed['tags'] ) ? $parsed['tags'] : array();
		$tags   = self::normalize_term_names( $tags );

		if ( empty( $tags ) ) {
			self::maybe_log(
				array(
					'action'       => 'generate_tags_empty',
					'model'        => (string) $model,
					'api_base_url' => (string) $iface['api_base_url'],
					'input_title'  => (string) $title_for_model,
					'input_prompt' => (string) $prompt_for_model,
					'output_text'  => '',
					'elapsed_ms'   => (int) $usage_fields['elapsed_ms'],
					'prompt_tokens' => (int) $usage_fields['prompt_tokens'],
					'completion_tokens' => (int) $usage_fields['completion_tokens'],
					'total_tokens' => (int) $usage_fields['total_tokens'],
					'post_id'      => (int) $post_id,
					'meta'         => wp_json_encode( array( 'raw' => $text ), JSON_UNESCAPED_UNICODE ),
				)
			);
			ZhiWrite_AI_Writer_DB::update_task(
				$task_id,
				array(
					'status'       => ZhiWrite_AI_Writer_DB::TASK_STATUS_FAILED,
					'progress'     => 0,
					'message'      => __( '未解析到标签（tags）。', 'zhiwrite-ai-writer' ),
					'locked_until' => null,
				)
			);
			self::generation_status_update( $request_id, 'error', __( '未解析到标签（tags）。', 'zhiwrite-ai-writer' ), 0, $user_id );
			return;
		}

		ZhiWrite_AI_Writer_DB::update_task(
			$task_id,
			array(
				'progress' => 75,
				'message'  => __( '写入文章标签…', 'zhiwrite-ai-writer' ),
			)
		);
		self::generation_status_update( $request_id, 'save', __( '写入文章标签…', 'zhiwrite-ai-writer' ), 75, $user_id );

		$tag_ids = array();
		foreach ( $tags as $name ) {
			$ex = term_exists( $name, 'post_tag' );
			if ( is_array( $ex ) && isset( $ex['term_id'] ) ) {
				$tag_ids[] = (int) $ex['term_id'];
				continue;
			}
			$created = wp_insert_term( $name, 'post_tag' );
			if ( is_array( $created ) && isset( $created['term_id'] ) ) {
				$tag_ids[] = (int) $created['term_id'];
			}
		}
		$tag_ids = array_values( array_unique( array_filter( array_map( 'intval', $tag_ids ) ) ) );
		if ( empty( $tag_ids ) ) {
			ZhiWrite_AI_Writer_DB::update_task(
				$task_id,
				array(
					'status'       => ZhiWrite_AI_Writer_DB::TASK_STATUS_FAILED,
					'progress'     => 0,
					'message'      => __( '写入失败：无法创建/获取标签 ID。', 'zhiwrite-ai-writer' ),
					'locked_until' => null,
				)
			);
			self::generation_status_update( $request_id, 'error', __( '写入失败：无法创建/获取标签 ID。', 'zhiwrite-ai-writer' ), 0, $user_id );
			return;
		}

		wp_set_post_terms( $post_id, $tag_ids, 'post_tag', ( 'append' === $apply_mode ) );
		update_post_meta( (int) $post_id, '_zhiwrite_term_suggestions', wp_json_encode( array( 'categories' => array(), 'tags' => $tags ), JSON_UNESCAPED_UNICODE ) );

		$tags_html = get_the_term_list( (int) $post_id, 'post_tag', '', ', ', '' );
		$tags_html = is_string( $tags_html ) ? $tags_html : '';
		if ( '' === trim( $tags_html ) ) {
			$tags_html = '—';
		}

		self::maybe_log(
			array(
				'action'       => 'generate_tags',
				'model'        => (string) $model,
				'api_base_url' => (string) $iface['api_base_url'],
				'input_title'  => (string) $title_for_model,
				'input_prompt' => (string) $prompt_for_model,
				'output_text'  => '',
				'elapsed_ms'   => (int) $usage_fields['elapsed_ms'],
				'prompt_tokens' => (int) $usage_fields['prompt_tokens'],
				'completion_tokens' => (int) $usage_fields['completion_tokens'],
				'total_tokens' => (int) $usage_fields['total_tokens'],
				'post_id'      => (int) $post_id,
				'meta'         => wp_json_encode(
					array(
						'tags'       => $tags,
						'apply_mode' => (string) $apply_mode,
						'batch_id'   => isset( $payload['batch_id'] ) ? (string) $payload['batch_id'] : '',
					),
					JSON_UNESCAPED_UNICODE
				),
			)
		);

		ZhiWrite_AI_Writer_DB::update_task(
			$task_id,
			array(
				'status'       => ZhiWrite_AI_Writer_DB::TASK_STATUS_SUCCEEDED,
				'progress'     => 100,
				'message'      => __( '已完成。', 'zhiwrite-ai-writer' ),
				'locked_until' => null,
				'result'       => wp_json_encode(
					array(
						'postId'   => (int) $post_id,
						'tags'     => $tags,
						'tagsHtml' => $tags_html,
					),
					JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
				),
			)
		);
		self::generation_status_update( $request_id, 'done', __( '已完成。', 'zhiwrite-ai-writer' ), 100, $user_id );
	}

	private static function process_task_webhook_retry( $task_id, $request_id, $user_id, array $payload, array $opts ) {
		$task_id    = (int) $task_id;
		$request_id = (string) $request_id;
		$user_id    = (int) $user_id;

		$next_ts = isset( $payload['next_ts'] ) ? (int) $payload['next_ts'] : 0;
		if ( $next_ts > time() ) {
			// Not time yet: put back to pending with message.
			ZhiWrite_AI_Writer_DB::update_task(
				$task_id,
				array(
					'status'       => ZhiWrite_AI_Writer_DB::TASK_STATUS_PENDING,
					'progress'     => 1,
					'message'      => sprintf( __( '等待重试：%s', 'zhiwrite-ai-writer' ), gmdate( 'Y-m-d H:i:s', $next_ts ) ),
					'locked_until' => null,
				)
			);
			return;
		}

		$attempts = isset( $payload['attempts'] ) ? (int) $payload['attempts'] : 0;
		$max      = isset( $payload['max'] ) ? (int) $payload['max'] : ( isset( $opts['webhook_retry_max'] ) ? (int) $opts['webhook_retry_max'] : 6 );
		$base     = isset( $payload['base'] ) ? (int) $payload['base'] : ( isset( $opts['webhook_retry_base_sec'] ) ? (int) $opts['webhook_retry_base_sec'] : 10 );
		$max_delay = isset( $payload['max_delay'] ) ? (int) $payload['max_delay'] : ( isset( $opts['webhook_retry_max_sec'] ) ? (int) $opts['webhook_retry_max_sec'] : 1800 );
		$base      = max( 1, min( 600, $base ) );
		$max_delay = max( 10, min( 86400, $max_delay ) );

		if ( $attempts >= $max ) {
			ZhiWrite_AI_Writer_DB::update_task(
				$task_id,
				array(
					'status'       => ZhiWrite_AI_Writer_DB::TASK_STATUS_FAILED,
					'progress'     => 0,
					'message'      => __( '已达到最大重试次数（死信）。', 'zhiwrite-ai-writer' ),
					'locked_until' => null,
				)
			);
			return;
		}

		$url = isset( $payload['url'] ) ? trim( (string) $payload['url'] ) : '';
		$body = isset( $payload['body'] ) ? (string) $payload['body'] : '';
		$headers = isset( $payload['headers'] ) && is_array( $payload['headers'] ) ? $payload['headers'] : array( 'Content-Type' => 'application/json' );
		$event = isset( $payload['event'] ) ? (string) $payload['event'] : '';

		if ( '' === $url || '' === $body ) {
			ZhiWrite_AI_Writer_DB::update_task(
				$task_id,
				array(
					'status'       => ZhiWrite_AI_Writer_DB::TASK_STATUS_FAILED,
					'progress'     => 0,
					'message'      => __( '重试任务缺少 url/body。', 'zhiwrite-ai-writer' ),
					'locked_until' => null,
				)
			);
			return;
		}

		$timeout = isset( $opts['webhook_timeout'] ) ? (int) $opts['webhook_timeout'] : 3;
		$timeout = max( 1, min( 20, $timeout ) );

		ZhiWrite_AI_Writer_DB::update_task(
			$task_id,
			array(
				'progress' => 35,
				'message'  => sprintf( __( 'Webhook 重试中（%1$d/%2$d）…', 'zhiwrite-ai-writer' ), $attempts + 1, $max ),
			)
		);

		$started = microtime( true );
		$resp = wp_remote_post(
			$url,
			array(
				'timeout'  => $timeout,
				'blocking' => true,
				'headers'  => $headers,
				'body'     => $body,
			)
		);
		$elapsed_ms = (int) round( ( microtime( true ) - $started ) * 1000 );

		$ok = true;
		$http_code = 0;
		$err = '';
		$resp_snip = '';
		if ( is_wp_error( $resp ) ) {
			$ok  = false;
			$err = $resp->get_error_message();
		} else {
			$http_code = (int) wp_remote_retrieve_response_code( $resp );
			if ( $http_code < 200 || $http_code >= 300 ) {
				$ok = false;
				$resp_snip = (string) wp_remote_retrieve_body( $resp );
				$resp_snip = (string) substr( $resp_snip, 0, 800 );
			}
		}

		self::maybe_log(
			array(
				'action' => $ok ? 'webhook_retry_ok' : 'webhook_retry_error',
				'meta'   => wp_json_encode(
					array(
						'event'      => (string) $event,
						'url'        => (string) $url,
						'attempt'    => $attempts + 1,
						'max'        => $max,
						'http_code'  => $http_code,
						'err'        => (string) $err,
						'resp'       => (string) $resp_snip,
						'elapsed_ms' => $elapsed_ms,
					),
					JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
				),
			)
		);

		if ( $ok ) {
			ZhiWrite_AI_Writer_DB::update_task(
				$task_id,
				array(
					'status'       => ZhiWrite_AI_Writer_DB::TASK_STATUS_SUCCEEDED,
					'progress'     => 100,
					'message'      => __( '回调重试成功。', 'zhiwrite-ai-writer' ),
					'locked_until' => null,
					'result'       => wp_json_encode(
						array(
							'ok'         => true,
							'http_code'   => $http_code,
							'elapsed_ms'  => $elapsed_ms,
						),
						JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
					),
				)
			);
			return;
		}

		// schedule next retry with exponential backoff + jitter.
		$attempts2 = $attempts + 1;
		$delay = (int) min( $max_delay, $base * ( 2 ** max( 0, $attempts2 - 1 ) ) );
		$jitter = (int) round( $delay * 0.2 );
		$delay = $delay + ( $jitter > 0 ? random_int( 0, $jitter ) : 0 );
		$next_ts2 = time() + $delay;
		$payload['attempts'] = $attempts2;
		$payload['next_ts'] = $next_ts2;
		$payload['last_http_code'] = $http_code;
		$payload['last_err'] = (string) $err;

		ZhiWrite_AI_Writer_DB::update_task(
			$task_id,
			array(
				'status'       => ZhiWrite_AI_Writer_DB::TASK_STATUS_PENDING,
				'progress'     => 1,
				'message'      => sprintf( __( '回调失败：将于 %s 重试。', 'zhiwrite-ai-writer' ), gmdate( 'Y-m-d H:i:s', $next_ts2 ) ),
				'payload'      => wp_json_encode( $payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ),
				'locked_until' => null,
			)
		);
		self::maybe_schedule_queue();
	}

	public static function ajax_generate() {
		if ( ! current_user_can( ZhiWrite_AI_Writer_Settings::capability_generate() ) ) {
			wp_send_json_error( array( 'message' => __( '权限不足。', 'zhiwrite-ai-writer' ) ), 403 );
		}
		check_ajax_referer( 'zhiwrite_ai_nonce', 'nonce' );

		$request_id = isset( $_POST['request_id'] ) ? sanitize_key( (string) wp_unslash( $_POST['request_id'] ) ) : '';
		if ( '' === $request_id ) {
			$request_id = 'req_' . wp_generate_password( 12, false, false );
		}
		$user_id = get_current_user_id();
		self::generation_status_update( $request_id, 'start', __( '已开始任务，正在校验参数…', 'zhiwrite-ai-writer' ), 5, $user_id );

		$title    = isset( $_POST['title'] ) ? sanitize_text_field( (string) wp_unslash( $_POST['title'] ) ) : '';
		$prompt   = isset( $_POST['prompt'] ) ? (string) wp_unslash( $_POST['prompt'] ) : '';
		$template_id = isset( $_POST['template_id'] ) ? sanitize_key( (string) wp_unslash( $_POST['template_id'] ) ) : '';
		$style_id    = isset( $_POST['style_id'] ) ? sanitize_key( (string) wp_unslash( $_POST['style_id'] ) ) : '';
		$vars_override_raw = isset( $_POST['vars_override'] ) ? (string) wp_unslash( $_POST['vars_override'] ) : '';
		$if_id    = isset( $_POST['interface_id'] ) ? sanitize_text_field( (string) wp_unslash( $_POST['interface_id'] ) ) : '';
		$model    = isset( $_POST['model'] ) ? sanitize_text_field( (string) wp_unslash( $_POST['model'] ) ) : '';
		$do_seo   = ! empty( $_POST['do_seo'] );
		$do_terms = ! empty( $_POST['do_terms'] );
		$do_disc  = ! empty( $_POST['do_disclaimer'] );
		$save_mode = isset( $_POST['save_mode'] ) ? sanitize_key( (string) wp_unslash( $_POST['save_mode'] ) ) : '';

		$prompt = trim( $prompt );
		if ( '' === $prompt ) {
			self::generation_status_update( $request_id, 'error', __( '写作需求为空。', 'zhiwrite-ai-writer' ), 0, $user_id );
			wp_send_json_error( array( 'message' => __( '请填写写作需求。', 'zhiwrite-ai-writer' ) ), 400 );
		}

		self::generation_status_update( $request_id, 'prepare', __( '读取接口配置与生成选项…', 'zhiwrite-ai-writer' ), 10, $user_id );
		$opts = ZhiWrite_AI_Writer_Settings::get_options();
		// Precompute filtered prompt for model router decision (avoid undefined var).
		$prompt_for_model_router = self::filter_outbound_text( $prompt );
		// Decide save policy: preview (only show), draft, publish.
		$default_policy = isset( $opts['default_post_status'] ) ? (string) $opts['default_post_status'] : 'draft';
		if ( '' === $save_mode ) {
			if ( 'manual' === $default_policy ) {
				$save_mode = 'preview';
			} else {
				$save_mode = $default_policy; // draft|publish
			}
		}
		$save_mode = in_array( $save_mode, array( 'preview', 'draft', 'publish' ), true ) ? $save_mode : 'preview';
		if ( 'publish' === $save_mode && ! current_user_can( 'publish_posts' ) ) {
			$save_mode = 'draft';
		}
		$content_format = isset( $opts['content_format'] ) ? (string) $opts['content_format'] : ZhiWrite_AI_Writer_Settings::CONTENT_FORMAT_WP_HTML;
		$iface     = ZhiWrite_AI_Writer_Settings::get_interface( $if_id );
		$use_model = '' !== $model ? $model : ( ( '' !== (string) $iface['model'] ) ? (string) $iface['model'] : (string) $opts['model'] );
		if ( '' === $model ) {
			$use_model = self::maybe_route_model( $use_model, $prompt_for_model_router, $do_seo, $do_terms, $do_disc, $opts );
		}

		if ( '' === (string) $iface['api_base_url'] || '' === (string) $iface['api_key'] || '' === (string) $use_model ) {
			self::generation_status_update( $request_id, 'error', __( '接口配置不完整。', 'zhiwrite-ai-writer' ), 0, $user_id );
			wp_send_json_error(
				array( 'message' => __( '请先在“设置-接口设置”里配置接口（API 地址 / Key / 默认模型）。', 'zhiwrite-ai-writer' ) ),
				400
			);
		}

		// Queue mode: enqueue and return immediately (avoid long-running admin-ajax request).
		if ( ! empty( $opts['enable_queue'] ) ) {
			$block = self::budget_should_block( $opts );
			if ( ! empty( $block['block'] ) ) {
				self::budget_maybe_notify( $opts, $block );
				$msg = __( '已触发预算阈值，今日生成已被限制。', 'zhiwrite-ai-writer' );
				if ( isset( $block['reason'], $block['cur'], $block['max'] ) ) {
					if ( 'tokens' === (string) $block['reason'] ) {
						$msg = sprintf( __( '已触发预算阈值：今日 tokens 已达 %1$d/%2$d，生成已被限制。', 'zhiwrite-ai-writer' ), (int) $block['cur'], (int) $block['max'] );
					} else {
						$msg = sprintf( __( '已触发预算阈值：今日请求数已达 %1$d/%2$d，生成已被限制。', 'zhiwrite-ai-writer' ), (int) $block['cur'], (int) $block['max'] );
					}
				}
				self::generation_status_update( $request_id, 'error', $msg, 0, $user_id );
				wp_send_json_error( array( 'message' => $msg, 'code' => 'budget' ), 200 );
			}

			$task_id = self::enqueue_generation_task(
				$request_id,
				array(
					'title'         => $title,
					'prompt'        => $prompt,
					'template_id'   => $template_id,
					'style_id'      => $style_id,
					'vars_override' => $vars_override_raw,
					'interface_id'  => $if_id,
					'model'         => $model,
					'do_seo'        => $do_seo ? 1 : 0,
					'do_terms'      => $do_terms ? 1 : 0,
					'do_disclaimer' => $do_disc ? 1 : 0,
					'save_mode'     => $save_mode,
				)
			);
			if ( $task_id <= 0 ) {
				wp_send_json_error(
					array(
						'requestId' => (string) $request_id,
						'message'   => __( '后台队列提交失败：任务未写入数据库。请检查插件数据表是否已创建。', 'zhiwrite-ai-writer' ),
					),
					500
				);
			}
			wp_send_json_success(
				array(
					'queued'    => 1,
					'taskId'    => (int) $task_id,
					'requestId' => (string) $request_id,
					'message'   => __( '任务已提交到后台队列。', 'zhiwrite-ai-writer' ),
				)
			);
		}

		// Acquire concurrency lock before calling upstream.
		$lock        = array();
		$lock_result = self::acquire_generation_lock( get_current_user_id(), $request_id, $opts );
		if ( empty( $lock_result['ok'] ) ) {
			self::generation_status_update( $request_id, 'error', __( '任务繁忙：并发限制触发。', 'zhiwrite-ai-writer' ), 0 );
			wp_send_json_error(
				array(
					'message' => isset( $lock_result['message'] ) ? (string) $lock_result['message'] : __( '当前任务繁忙，请稍后再试。', 'zhiwrite-ai-writer' ),
					'code'    => 'busy',
					'meta'    => isset( $lock_result['meta'] ) ? $lock_result['meta'] : array(),
				),
				200
			);
		}
		$lock = isset( $lock_result['lock'] ) && is_array( $lock_result['lock'] ) ? $lock_result['lock'] : array();

		// Budget guardrails (after lock to avoid races in high concurrency).
		$block2 = self::budget_should_block( $opts );
		if ( ! empty( $block2['block'] ) ) {
			self::budget_maybe_notify( $opts, $block2 );
			$msg2 = __( '已触发预算阈值，今日生成已被限制。', 'zhiwrite-ai-writer' );
			if ( isset( $block2['reason'], $block2['cur'], $block2['max'] ) ) {
				if ( 'tokens' === (string) $block2['reason'] ) {
					$msg2 = sprintf( __( '已触发预算阈值：今日 tokens 已达 %1$d/%2$d，生成已被限制。', 'zhiwrite-ai-writer' ), (int) $block2['cur'], (int) $block2['max'] );
				} else {
					$msg2 = sprintf( __( '已触发预算阈值：今日请求数已达 %1$d/%2$d，生成已被限制。', 'zhiwrite-ai-writer' ), (int) $block2['cur'], (int) $block2['max'] );
				}
			}
			self::generation_status_update( $request_id, 'error', $msg2, 0, $user_id );
			self::release_generation_lock( $lock );
			wp_send_json_error( array( 'message' => $msg2, 'code' => 'budget' ), 200 );
		}

		// Optional outbound filtering before sending to model/logs.
		$title_for_model  = self::filter_outbound_text( $title );
		$prompt_for_model = self::filter_outbound_text( $prompt );

		self::generation_status_update( $request_id, 'prompt', __( '构建提示词（Prompt）…', 'zhiwrite-ai-writer' ), 15 );
		$system = self::system_prompt( $do_seo, $do_terms, $do_disc, $content_format );
		$system .= self::prompt_builder_system_append( $template_id, $style_id, $vars_override_raw, $title_for_model, $prompt_for_model, $opts );
		$user   = self::user_prompt( $title_for_model, $prompt_for_model );

		// Cache check (optional).
		$cache_key = '';
		$cache_ttl = 0;
		if ( ! empty( $opts['cache_enabled'] ) ) {
			$cache_ttl = max( 1, (int) ( isset( $opts['cache_ttl_minutes'] ) ? (int) $opts['cache_ttl_minutes'] : 60 ) ) * 60;
			$scope = isset( $opts['cache_scope'] ) ? (string) $opts['cache_scope'] : 'strict';
			$parts = array(
				'system' => $system,
				'user'   => $user,
			);
			if ( 'strict' === $scope ) {
				$parts['api_base_url'] = (string) $iface['api_base_url'];
				$parts['model']        = (string) $use_model;
				$parts['format']       = (string) $content_format;
				$parts['do_seo']        = $do_seo ? 1 : 0;
				$parts['do_terms']      = $do_terms ? 1 : 0;
				$parts['do_disc']       = $do_disc ? 1 : 0;
			}
			$cache_key = self::cache_key_for_generation( $parts );
			$cached = self::cache_get( $cache_key );
			if ( is_array( $cached ) && isset( $cached['api_res'] ) && is_array( $cached['api_res'] ) ) {
				self::generation_status_update( $request_id, 'request', __( '命中缓存：直接复用结果…', 'zhiwrite-ai-writer' ), 60 );
				$api_res = $cached['api_res'];
				$api_res['meta']['cache_hit'] = 1;
			}
		}

		if ( ! isset( $api_res ) ) {
			self::generation_status_update( $request_id, 'request', __( '请求 AI 接口生成内容（这一步最耗时）…', 'zhiwrite-ai-writer' ), 30 );
			$fo = self::call_upstream_with_failover( $iface, $use_model, $system, $user, $opts, $content_format, $do_seo, $do_terms, $do_disc );
			$api_res = isset( $fo['api_res'] ) ? $fo['api_res'] : array();
			if ( isset( $fo['iface'] ) && is_array( $fo['iface'] ) ) {
				$iface = $fo['iface'];
			}
			if ( '' !== (string) $cache_key && ! empty( $api_res['ok'] ) && $cache_ttl > 0 ) {
				self::cache_set( $cache_key, array( 'api_res' => $api_res, 'saved_at' => time() ), $cache_ttl );
			}
		}

		$usage_fields = self::extract_usage_fields( is_array( $api_res ) ? $api_res : array() );

		if ( empty( $api_res['ok'] ) ) {
			self::generation_status_update( $request_id, 'error', __( 'AI 接口返回错误。', 'zhiwrite-ai-writer' ), 0 );
			self::maybe_log(
				array(
					'action'       => 'generate_error',
					'model'        => $use_model,
					'api_base_url' => (string) $iface['api_base_url'],
					'input_title'  => $title_for_model,
					'input_prompt' => $prompt_for_model,
					'output_text'  => '',
					'elapsed_ms'   => (int) $usage_fields['elapsed_ms'],
					'prompt_tokens' => (int) $usage_fields['prompt_tokens'],
					'completion_tokens' => (int) $usage_fields['completion_tokens'],
					'total_tokens' => (int) $usage_fields['total_tokens'],
					'meta'         => wp_json_encode( array( 'error' => (string) $api_res['error'], 'raw' => $api_res['raw'] ), JSON_UNESCAPED_UNICODE ),
				)
			);
			self::release_generation_lock( $lock );
			self::webhook_send(
				'generation_failed',
				array(
					'request_id'   => (string) $request_id,
					'error'        => (string) $api_res['error'],
					'error_code'   => (string) $api_res['error_code'],
					'api_base_url' => (string) $iface['api_base_url'],
					'model'        => (string) $use_model,
				)
			);
			wp_send_json_error( array( 'message' => (string) $api_res['error'] ), 500 );
		}

		self::generation_status_update( $request_id, 'parse', __( '解析生成结果…', 'zhiwrite-ai-writer' ), 70 );
		$parsed = self::parse_response_json( (string) $api_res['text'] );
		if ( empty( $parsed['content'] ) ) {
			$parsed['content'] = (string) $api_res['text'];
		}

		if ( ! isset( $parsed['excerpt'] ) ) {
			$parsed['excerpt'] = '';
		}

		$seo_hints = self::seo_hints(
			'' !== (string) $parsed['title'] ? (string) $parsed['title'] : $title,
			(string) $parsed['excerpt'],
			(string) $parsed['content'],
			isset( $parsed['focus_keyword'] ) ? (string) $parsed['focus_keyword'] : '',
			(string) $content_format
		);

		// Internal links strategy (optional).
		$opts_now = ZhiWrite_AI_Writer_Settings::get_options();
		$internal = array( 'enabled' => ! empty( $opts_now['internal_links_enabled'] ) );
		if ( ! empty( $opts_now['internal_links_enabled'] ) ) {
			$max_links = isset( $opts_now['internal_links_max'] ) ? (int) $opts_now['internal_links_max'] : 3;
			$posi      = isset( $opts_now['internal_links_position'] ) ? (string) $opts_now['internal_links_position'] : 'after_h2_1';
			$strat     = isset( $opts_now['internal_links_strategy'] ) ? (string) $opts_now['internal_links_strategy'] : 'keyword';
			$internal['position'] = $posi;
			$internal['strategy'] = $strat;
			$links = self::internal_links_suggest(
				'' !== (string) $parsed['title'] ? (string) $parsed['title'] : $title,
				isset( $parsed['focus_keyword'] ) ? (string) $parsed['focus_keyword'] : '',
				$max_links
			);
			$applied = self::internal_links_apply( (string) $parsed['content'], (string) $content_format, $links, $posi );
			$parsed['content'] = (string) $applied['content'];
			$internal['inserted'] = isset( $applied['inserted'] ) ? (int) $applied['inserted'] : 0;
			$internal['links'] = $links;
		}

		// Excerpt/lead (optional, after internal links so excerpt is based on final content).
		$parsed = self::apply_excerpt_and_lead( is_array( $parsed ) ? $parsed : array(), (string) $content_format );

		// TOC (optional).
		$opts_now2 = ZhiWrite_AI_Writer_Settings::get_options();
		$toc_meta  = array( 'enabled' => ! empty( $opts_now2['toc_enabled'] ) );
		if ( ! empty( $opts_now2['toc_enabled'] ) ) {
			$minh = isset( $opts_now2['toc_min_headings'] ) ? (int) $opts_now2['toc_min_headings'] : 3;
			$posi = isset( $opts_now2['toc_position'] ) ? (string) $opts_now2['toc_position'] : 'after_lead';
			$inc3 = ! empty( $opts_now2['toc_include_h3'] );
			$ap   = self::toc_apply( (string) $parsed['content'], (string) $content_format, $posi, $minh, $inc3 );
			$parsed['content'] = (string) $ap['content'];
			$toc_meta['inserted'] = isset( $ap['inserted'] ) ? (int) $ap['inserted'] : 0;
			$toc_meta['position'] = $posi;
			$toc_meta['include_h3'] = $inc3 ? 1 : 0;
		}

		// FAQ (optional).
		$faq_meta = array( 'enabled' => ! empty( $opts_now2['faq_enabled'] ) );
		if ( ! empty( $opts_now2['faq_enabled'] ) ) {
			$cnt = isset( $opts_now2['faq_count'] ) ? (int) $opts_now2['faq_count'] : 5;
			$pos = isset( $opts_now2['faq_position'] ) ? (string) $opts_now2['faq_position'] : 'end';
			$faq = self::faq_normalize( isset( $parsed['faq'] ) ? $parsed['faq'] : array(), $cnt );
			$apf = self::faq_apply( (string) $parsed['content'], (string) $content_format, $faq, $pos );
			$parsed['content'] = (string) $apf['content'];
			$faq_meta['inserted'] = isset( $apf['inserted'] ) ? (int) $apf['inserted'] : 0;
			$faq_meta['position'] = $pos;
			$faq_meta['items'] = $faq;
		}

		// Content safety check (on generated content) before preview/save.
		$safety = self::content_safety_apply( (string) $parsed['content'], 'content' );
		if ( ! empty( $safety['hits'] ) ) {
			if ( 'block' === (string) $safety['action'] && empty( $safety['ok'] ) ) {
				self::generation_status_update( $request_id, 'error', __( '内容安全拦截：命中敏感词。', 'zhiwrite-ai-writer' ), 0, $user_id );
				self::maybe_log(
					array(
						'action'       => 'content_safety_block',
						'model'        => $use_model,
						'api_base_url' => (string) $iface['api_base_url'],
						'input_title'  => $title_for_model,
						'input_prompt' => $prompt_for_model,
						'output_text'  => '',
						'meta'         => wp_json_encode( array( 'hits' => $safety['hits'], 'message' => $safety['message'] ), JSON_UNESCAPED_UNICODE ),
					)
				);
				self::release_generation_lock( $lock );
				wp_send_json_error(
					array(
						'message' => __( '内容安全拦截：命中敏感词，请调整提示词或改为“提示/替换”策略后重试。', 'zhiwrite-ai-writer' ),
						'code'    => 'content_safety',
						'hits'    => $safety['hits'],
					),
					200
				);
			}
			if ( 'replace' === (string) $safety['action'] && ! empty( $safety['text'] ) ) {
				$parsed['content'] = (string) $safety['text'];
			}
		}

		$precheck = self::precheck_run(
			'' !== (string) $parsed['title'] ? (string) $parsed['title'] : $title,
			(string) $parsed['excerpt'],
			(string) $parsed['content'],
			(string) $content_format,
			is_array( $safety ) ? $safety : array()
		);

		// Fact-check (limited): pass-through in response + store in post meta when saved.
		$fact = array(
			'enabled'       => ! empty( ZhiWrite_AI_Writer_Settings::get_options()['fact_check_enabled'] ),
			'verify_points' => isset( $parsed['verify_points'] ) && is_array( $parsed['verify_points'] ) ? array_values( $parsed['verify_points'] ) : array(),
			'source_hints'  => isset( $parsed['source_hints'] ) && is_array( $parsed['source_hints'] ) ? array_values( $parsed['source_hints'] ) : array(),
		);

		if ( 'preview' === $save_mode ) {
			self::generation_status_update( $request_id, 'done', __( '已生成：仅展示结果（未保存）。', 'zhiwrite-ai-writer' ), 100 );
			self::generation_status_clear( $request_id );
			self::release_generation_lock( $lock );
			self::webhook_send(
				'generation_preview',
				array(
					'request_id'   => (string) $request_id,
					'api_base_url' => (string) $iface['api_base_url'],
					'model'        => (string) $use_model,
					'title'        => '' !== (string) $parsed['title'] ? (string) $parsed['title'] : (string) $title,
				)
			);
			wp_send_json_success(
				array(
					'saved'         => false,
					'postId'        => 0,
					'requestId'     => (string) $request_id,
					'title'         => '' !== (string) $parsed['title'] ? (string) $parsed['title'] : ( '' !== $title ? $title : __( '未命名', 'zhiwrite-ai-writer' ) ),
					'excerpt'       => (string) $parsed['excerpt'],
					'content'       => (string) $parsed['content'],
					'contentFormat' => (string) $content_format,
					'seo'           => array(
						'slug'         => isset( $parsed['slug'] ) ? (string) $parsed['slug'] : '',
						'focusKeyword' => isset( $parsed['focus_keyword'] ) ? (string) $parsed['focus_keyword'] : '',
					),
					'terms'         => array(
						'categories' => isset( $parsed['categories'] ) ? $parsed['categories'] : array(),
						'tags'       => isset( $parsed['tags'] ) ? $parsed['tags'] : array(),
					),
					'safety'        => array(
						'action'  => isset( $safety['action'] ) ? (string) $safety['action'] : '',
						'hits'    => isset( $safety['hits'] ) ? $safety['hits'] : array(),
						'message' => isset( $safety['message'] ) ? (string) $safety['message'] : '',
					),
					'seoHints'       => is_array( $seo_hints ) ? $seo_hints : array(),
					'internalLinks'  => $internal,
					'toc'            => $toc_meta,
					'faq'            => $faq_meta,
					'precheck'       => $precheck,
					'fact'           => $fact,
				)
			);
		}

		self::generation_status_update( $request_id, 'save', __( '保存文章到 WordPress…', 'zhiwrite-ai-writer' ), 85 );
		$postarr = array(
			'post_type'    => 'post',
			'post_status'  => (string) $save_mode,
			'post_title'   => '' !== (string) $parsed['title'] ? (string) $parsed['title'] : ( '' !== $title ? $title : __( '未命名草稿', 'zhiwrite-ai-writer' ) ),
			'post_content' => (string) $parsed['content'],
			'post_excerpt' => (string) $parsed['excerpt'],
		);

		$post_id = wp_insert_post( $postarr, true );
		// Store content format markers for later rendering/conversion.
		update_post_meta( (int) $post_id, '_zhiwrite_content_format', sanitize_text_field( $content_format ) );
		if ( ZhiWrite_AI_Writer_Settings::CONTENT_FORMAT_MARKDOWN === $content_format ) {
			update_post_meta( (int) $post_id, '_zhiwrite_markdown', (string) $parsed['content'] );
		}

		if ( is_wp_error( $post_id ) ) {
			self::generation_status_update( $request_id, 'error', __( '草稿保存失败。', 'zhiwrite-ai-writer' ), 0 );
			self::maybe_log(
				array(
					'action'       => 'insert_post_error',
					'model'        => $use_model,
					'api_base_url' => (string) $iface['api_base_url'],
					'input_title'  => $title_for_model,
					'input_prompt' => $prompt_for_model,
					'output_text'  => (string) $api_res['text'],
					'elapsed_ms'   => (int) $usage_fields['elapsed_ms'],
					'prompt_tokens' => (int) $usage_fields['prompt_tokens'],
					'completion_tokens' => (int) $usage_fields['completion_tokens'],
					'total_tokens' => (int) $usage_fields['total_tokens'],
					'meta'         => wp_json_encode( array( 'error' => $post_id->get_error_message(), 'raw' => $api_res['raw'] ), JSON_UNESCAPED_UNICODE ),
				)
			);
			self::release_generation_lock( $lock );
			self::webhook_send(
				'generation_save_failed',
				array(
					'request_id' => (string) $request_id,
					'error'      => $post_id->get_error_message(),
				)
			);
			wp_send_json_error( array( 'message' => $post_id->get_error_message() ), 500 );
		}

		self::generation_status_update( $request_id, 'finalize', __( '写入 SEO 信息与日志…', 'zhiwrite-ai-writer' ), 95 );
		if ( ! empty( $parsed['slug'] ) ) {
			wp_update_post(
				array(
					'ID'        => (int) $post_id,
					'post_name' => sanitize_title( (string) $parsed['slug'] ),
				)
			);
		}

		// Store basic SEO meta in post meta (theme/SEO plugin may read differently).
		if ( $do_seo ) {
			if ( ! empty( $parsed['focus_keyword'] ) ) {
				update_post_meta( (int) $post_id, '_zhiwrite_focus_keyword', sanitize_text_field( (string) $parsed['focus_keyword'] ) );
			}
			update_post_meta( (int) $post_id, '_zhiwrite_seo_title', sanitize_text_field( (string) $postarr['post_title'] ) );
			if ( '' !== (string) $postarr['post_excerpt'] ) {
				update_post_meta( (int) $post_id, '_zhiwrite_seo_description', sanitize_textarea_field( (string) $postarr['post_excerpt'] ) );
			}
		}
		// Apply suggested categories/tags if enabled.
		// Note: when "require confirm" is enabled, auto-save paths should NOT apply terms.
		if ( $do_terms && ! self::should_require_terms_confirm() ) {
			$cats = isset( $parsed['categories'] ) && is_array( $parsed['categories'] ) ? $parsed['categories'] : array();
			$tags = isset( $parsed['tags'] ) && is_array( $parsed['tags'] ) ? $parsed['tags'] : array();
			self::apply_terms_to_post( (int) $post_id, $cats, $tags );
			update_post_meta( (int) $post_id, '_zhiwrite_term_suggestions', wp_json_encode( array( 'categories' => $cats, 'tags' => $tags ), JSON_UNESCAPED_UNICODE ) );
		}
		if ( ! empty( $seo_hints ) ) {
			update_post_meta( (int) $post_id, '_zhiwrite_seo_hints', wp_json_encode( $seo_hints, JSON_UNESCAPED_UNICODE ) );
		}
		if ( ! empty( $internal ) ) {
			update_post_meta( (int) $post_id, '_zhiwrite_internal_links', wp_json_encode( $internal, JSON_UNESCAPED_UNICODE ) );
		}
		if ( ! empty( $toc_meta ) ) {
			update_post_meta( (int) $post_id, '_zhiwrite_toc', wp_json_encode( $toc_meta, JSON_UNESCAPED_UNICODE ) );
		}
		if ( ! empty( $faq_meta ) ) {
			update_post_meta( (int) $post_id, '_zhiwrite_faq', wp_json_encode( $faq_meta, JSON_UNESCAPED_UNICODE ) );
		}
		if ( ! empty( $precheck ) ) {
			update_post_meta( (int) $post_id, '_zhiwrite_precheck', wp_json_encode( $precheck, JSON_UNESCAPED_UNICODE ) );
		}
		if ( ! empty( $fact ) && ( ! empty( $fact['verify_points'] ) || ! empty( $fact['source_hints'] ) ) ) {
			update_post_meta( (int) $post_id, '_zhiwrite_fact_check', wp_json_encode( $fact, JSON_UNESCAPED_UNICODE ) );
		}

		$meta = array(
			'raw'         => $api_res['raw'],
			'suggestions' => array(
				'categories' => isset( $parsed['categories'] ) ? $parsed['categories'] : array(),
				'tags'       => isset( $parsed['tags'] ) ? $parsed['tags'] : array(),
			),
		);

		// 日志中记录一个“更贴近最终文章标题”的标题：
		// - 优先使用 AI 返回的 title；
		// - 其次使用用户输入的标题；
		// - 最后回退到实际保存的文章标题（post_title）。
		$log_title = '';
		if ( ! empty( $parsed['title'] ) ) {
			$log_title = (string) $parsed['title'];
		} elseif ( '' !== (string) $title ) {
			$log_title = (string) $title;
		} else {
			$log_title = (string) $postarr['post_title'];
		}

		$cache_hit = ! empty( $api_res['meta'] ) && is_array( $api_res['meta'] ) && ! empty( $api_res['meta']['cache_hit'] ) ? 1 : 0;
		$log_meta = array(
			'raw'       => $api_res['raw'],
			'cache_hit' => $cache_hit,
			'template_id' => $template_id,
			'style_id'    => $style_id,
			// When cache hits, these tokens represent "saved" tokens (best-effort).
			'prompt_tokens'     => (int) $usage_fields['prompt_tokens'],
			'completion_tokens' => (int) $usage_fields['completion_tokens'],
			'total_tokens'      => (int) $usage_fields['total_tokens'],
		);

		self::maybe_log(
			array(
				'action'       => 'generate',
				'model'        => $use_model,
				'api_base_url' => (string) $iface['api_base_url'],
				'input_title'  => $log_title,
				'input_prompt' => $prompt_for_model,
				'output_text'  => (string) $parsed['content'],
				'elapsed_ms'   => (int) $usage_fields['elapsed_ms'],
				'prompt_tokens' => (int) $usage_fields['prompt_tokens'],
				'completion_tokens' => (int) $usage_fields['completion_tokens'],
				'total_tokens' => (int) $usage_fields['total_tokens'],
				'post_id'      => (int) $post_id,
				'meta'         => wp_json_encode( wp_parse_args( $meta, $log_meta ), JSON_UNESCAPED_UNICODE ),
			)
		);

		self::generation_status_update( $request_id, 'done', __( '已完成。', 'zhiwrite-ai-writer' ), 100 );
		self::generation_status_clear( $request_id );
		self::release_generation_lock( $lock );
		self::webhook_send(
			'generation_saved',
			array(
				'request_id'   => (string) $request_id,
				'post_id'      => (int) $post_id,
				'edit_url'     => get_edit_post_link( (int) $post_id, 'raw' ),
				'api_base_url' => (string) $iface['api_base_url'],
				'model'        => (string) $use_model,
				'title'        => (string) $postarr['post_title'],
			)
		);
		wp_send_json_success(
			array(
				'saved'    => true,
				'postId'   => (int) $post_id,
				'requestId' => (string) $request_id,
				'editUrl'  => get_edit_post_link( (int) $post_id, 'raw' ),
				'title'    => (string) $postarr['post_title'],
				'excerpt'  => (string) $postarr['post_excerpt'],
				'content'  => (string) $parsed['content'],
				'contentFormat' => $content_format,
				'seo'      => array(
					'slug'         => (string) $parsed['slug'],
					'focusKeyword' => (string) $parsed['focus_keyword'],
				),
				'terms'    => array(
					'categories' => isset( $parsed['categories'] ) ? $parsed['categories'] : array(),
					'tags'       => isset( $parsed['tags'] ) ? $parsed['tags'] : array(),
				),
				'seoHints' => is_array( $seo_hints ) ? $seo_hints : array(),
				'internalLinks' => $internal,
				'toc' => $toc_meta,
				'faq' => $faq_meta,
				'precheck' => $precheck,
				'fact' => $fact,
			)
		);
	}

	public static function ajax_delete_log() {
		if ( ! current_user_can( ZhiWrite_AI_Writer_Settings::capability_logs() ) ) {
			wp_send_json_error( array( 'message' => __( '权限不足。', 'zhiwrite-ai-writer' ) ), 403 );
		}
		check_ajax_referer( 'zhiwrite_ai_nonce', 'nonce' );

		$id = isset( $_POST['id'] ) ? (int) $_POST['id'] : 0;
		if ( $id <= 0 ) {
			wp_send_json_error( array( 'message' => __( '参数错误。', 'zhiwrite-ai-writer' ) ), 400 );
		}

		ZhiWrite_AI_Writer_DB::delete_log( $id );
		wp_send_json_success( array( 'ok' => true ) );
	}

	public static function ajax_save_post() {
		if ( ! current_user_can( ZhiWrite_AI_Writer_Settings::capability_generate() ) ) {
			wp_send_json_error( array( 'message' => __( '权限不足。', 'zhiwrite-ai-writer' ) ), 403 );
		}
		check_ajax_referer( 'zhiwrite_ai_nonce', 'nonce' );

		$status = isset( $_POST['post_status'] ) ? sanitize_key( (string) wp_unslash( $_POST['post_status'] ) ) : 'draft';
		$status = in_array( $status, array( 'draft', 'publish' ), true ) ? $status : 'draft';
		if ( 'publish' === $status && ! current_user_can( 'publish_posts' ) ) {
			$status = 'draft';
		}

		$title   = isset( $_POST['title'] ) ? sanitize_text_field( (string) wp_unslash( $_POST['title'] ) ) : '';
		$excerpt = isset( $_POST['excerpt'] ) ? sanitize_textarea_field( (string) wp_unslash( $_POST['excerpt'] ) ) : '';
		$content = isset( $_POST['content'] ) ? (string) wp_unslash( $_POST['content'] ) : '';
		$format  = isset( $_POST['content_format'] ) ? sanitize_key( (string) wp_unslash( $_POST['content_format'] ) ) : '';

		if ( '' === trim( $content ) ) {
			wp_send_json_error( array( 'message' => __( '正文为空，无法保存。', 'zhiwrite-ai-writer' ) ), 400 );
		}
		if ( '' === $title ) {
			$title = __( '未命名草稿', 'zhiwrite-ai-writer' );
		}

		$postarr = array(
			'post_type'    => 'post',
			'post_status'  => $status,
			'post_title'   => $title,
			'post_excerpt' => $excerpt,
			'post_content' => $content,
		);

		// Content safety check before saving.
		$safety = self::content_safety_apply( (string) $postarr['post_content'], 'content' );
		if ( ! empty( $safety['hits'] ) ) {
			if ( 'block' === (string) $safety['action'] && empty( $safety['ok'] ) ) {
				wp_send_json_error(
					array(
						'message' => __( '内容安全拦截：命中敏感词，请修改内容或调整策略后再保存。', 'zhiwrite-ai-writer' ),
						'code'    => 'content_safety',
						'hits'    => $safety['hits'],
					),
					200
				);
			}
			if ( 'replace' === (string) $safety['action'] && ! empty( $safety['text'] ) ) {
				$postarr['post_content'] = (string) $safety['text'];
			}
		}

		$post_id = wp_insert_post( $postarr, true );
		if ( is_wp_error( $post_id ) ) {
			wp_send_json_error( array( 'message' => $post_id->get_error_message() ), 500 );
		}

		// Preserve original generation version (best-effort; only save once).
		$orig_title   = isset( $_POST['original_title'] ) ? sanitize_text_field( (string) wp_unslash( $_POST['original_title'] ) ) : '';
		$orig_excerpt = isset( $_POST['original_excerpt'] ) ? sanitize_textarea_field( (string) wp_unslash( $_POST['original_excerpt'] ) ) : '';
		$orig_content = isset( $_POST['original_content'] ) ? (string) wp_unslash( $_POST['original_content'] ) : '';
		$orig_fmt     = isset( $_POST['original_content_format'] ) ? sanitize_key( (string) wp_unslash( $_POST['original_content_format'] ) ) : '';
		if ( '' !== $orig_title || '' !== $orig_excerpt || '' !== trim( $orig_content ) ) {
			$existing = get_post_meta( (int) $post_id, '_zhiwrite_original_generation', true );
			if ( '' === (string) $existing ) {
				update_post_meta(
					(int) $post_id,
					'_zhiwrite_original_generation',
					wp_json_encode(
						array(
							'title'   => (string) $orig_title,
							'excerpt' => (string) $orig_excerpt,
							'content' => (string) $orig_content,
							'format'  => (string) $orig_fmt,
							'ts'      => time(),
						),
						JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
					)
				);
			}
		}

		// Precheck: optionally block publish.
		$opts = ZhiWrite_AI_Writer_Settings::get_options();
		$precheck = self::precheck_run( (string) $postarr['post_title'], (string) $postarr['post_excerpt'], (string) $postarr['post_content'], (string) $format, is_array( $safety ) ? $safety : array() );
		if ( 'publish' === $status && ! empty( $opts['precheck_block_publish'] ) && ! empty( $precheck['enabled'] ) && empty( $precheck['passed'] ) ) {
			// Rollback: convert to draft instead of publishing.
			wp_update_post( array( 'ID' => (int) $post_id, 'post_status' => 'draft' ) );
			update_post_meta( (int) $post_id, '_zhiwrite_precheck', wp_json_encode( $precheck, JSON_UNESCAPED_UNICODE ) );
			wp_send_json_error(
				array(
					'message'  => __( '发布前校验未通过：已保存为草稿，请根据清单修正后再发布。', 'zhiwrite-ai-writer' ),
					'code'     => 'precheck',
					'precheck' => $precheck,
					'postId'   => (int) $post_id,
					'editUrl'  => get_edit_post_link( (int) $post_id, 'raw' ),
				),
				200
			);
		}
		update_post_meta( (int) $post_id, '_zhiwrite_precheck', wp_json_encode( $precheck, JSON_UNESCAPED_UNICODE ) );

		// Store content format markers for later rendering/conversion.
		if ( '' !== $format ) {
			update_post_meta( (int) $post_id, '_zhiwrite_content_format', sanitize_text_field( $format ) );
			if ( ZhiWrite_AI_Writer_Settings::CONTENT_FORMAT_MARKDOWN === $format ) {
				update_post_meta( (int) $post_id, '_zhiwrite_markdown', (string) $content );
			}
		}

		$slug = isset( $_POST['slug'] ) ? sanitize_title( (string) wp_unslash( $_POST['slug'] ) ) : '';
		if ( '' !== $slug ) {
			wp_update_post(
				array(
					'ID'        => (int) $post_id,
					'post_name' => $slug,
				)
			);
		}

		$focus_keyword = isset( $_POST['focus_keyword'] ) ? sanitize_text_field( (string) wp_unslash( $_POST['focus_keyword'] ) ) : '';
		if ( '' !== $focus_keyword ) {
			update_post_meta( (int) $post_id, '_zhiwrite_focus_keyword', $focus_keyword );
		}
		update_post_meta( (int) $post_id, '_zhiwrite_seo_title', sanitize_text_field( (string) $title ) );
		if ( '' !== $excerpt ) {
			update_post_meta( (int) $post_id, '_zhiwrite_seo_description', sanitize_textarea_field( (string) $excerpt ) );
		}

		// Apply terms from UI (preview save).
		$cats = array();
		$tags = array();
		if ( isset( $_POST['categories'] ) ) {
			$cats_in = wp_unslash( $_POST['categories'] );
			if ( is_array( $cats_in ) ) {
				$cats = array_map( 'sanitize_text_field', $cats_in );
			} elseif ( is_string( $cats_in ) ) {
				$cats = array_filter( array_map( 'trim', explode( ',', (string) $cats_in ) ) );
			}
		}
		if ( isset( $_POST['tags'] ) ) {
			$tags_in = wp_unslash( $_POST['tags'] );
			if ( is_array( $tags_in ) ) {
				$tags = array_map( 'sanitize_text_field', $tags_in );
			} elseif ( is_string( $tags_in ) ) {
				$tags = array_filter( array_map( 'trim', explode( ',', (string) $tags_in ) ) );
			}
		}
		if ( ! empty( $cats ) || ! empty( $tags ) ) {
			self::apply_terms_to_post( (int) $post_id, $cats, $tags );
			update_post_meta( (int) $post_id, '_zhiwrite_term_suggestions', wp_json_encode( array( 'categories' => $cats, 'tags' => $tags ), JSON_UNESCAPED_UNICODE ) );
		}

		wp_send_json_success(
			array(
				'postId'  => (int) $post_id,
				'editUrl' => get_edit_post_link( (int) $post_id, 'raw' ),
				'status'  => $status,
			)
		);
	}

	public static function ajax_apply_terms() {
		if ( ! current_user_can( ZhiWrite_AI_Writer_Settings::capability_generate() ) ) {
			wp_send_json_error( array( 'message' => __( '权限不足。', 'zhiwrite-ai-writer' ) ), 403 );
		}
		check_ajax_referer( 'zhiwrite_ai_nonce', 'nonce' );

		$post_id = isset( $_POST['post_id'] ) ? (int) $_POST['post_id'] : 0;
		if ( $post_id <= 0 || ! current_user_can( 'edit_post', $post_id ) ) {
			wp_send_json_error( array( 'message' => __( '无权操作该文章。', 'zhiwrite-ai-writer' ) ), 403 );
		}

		$cats = isset( $_POST['categories'] ) ? wp_unslash( $_POST['categories'] ) : array();
		$tags = isset( $_POST['tags'] ) ? wp_unslash( $_POST['tags'] ) : array();
		$cats = is_array( $cats ) ? $cats : array();
		$tags = is_array( $tags ) ? $tags : array();
		$cats = self::normalize_term_names( $cats );
		$tags = self::normalize_term_names( $tags );

		$applied = self::apply_terms_to_post( $post_id, $cats, $tags );
		update_post_meta( (int) $post_id, '_zhiwrite_term_suggestions', wp_json_encode( array( 'categories' => $cats, 'tags' => $tags ), JSON_UNESCAPED_UNICODE ) );

		if ( empty( $applied['ok'] ) ) {
			$msg = __( '写入失败。', 'zhiwrite-ai-writer' );
			if ( isset( $applied['message'] ) && '' !== (string) $applied['message'] ) {
				$msg = sprintf( __( '写入失败：%s', 'zhiwrite-ai-writer' ), (string) $applied['message'] );
			}
			wp_send_json_error( array( 'message' => $msg ), 200 );
		}
		$cat_written = isset( $applied['cat_written'] ) ? (int) $applied['cat_written'] : 0;
		$tag_written = isset( $applied['tag_written'] ) ? (int) $applied['tag_written'] : 0;
		$cat_skipped = isset( $applied['cat_skipped'] ) ? (int) $applied['cat_skipped'] : 0;
		$tag_skipped = isset( $applied['tag_skipped'] ) ? (int) $applied['tag_skipped'] : 0;
		$auto_create = ! empty( $applied['auto_create'] ) ? 1 : 0;

		if ( 0 === $cat_written && 0 === $tag_written ) {
			$hint = $auto_create ? __( '请检查术语是否有效。', 'zhiwrite-ai-writer' ) : __( '可能是术语不存在且未开启“自动创建不存在术语”。', 'zhiwrite-ai-writer' );
			wp_send_json_error(
				array(
					'message' => __( '未写入任何分类/标签。', 'zhiwrite-ai-writer' ) . ' ' . $hint,
					'meta'    => $applied,
				),
				200
			);
		}

		wp_send_json_success(
			array(
				'message' => sprintf(
					__( '已写入：分类 %1$d 个、标签 %2$d 个。跳过：分类 %3$d 个、标签 %4$d 个。', 'zhiwrite-ai-writer' ),
					$cat_written,
					$tag_written,
					$cat_skipped,
					$tag_skipped
				),
				'meta'    => $applied,
			)
		);
	}

	public static function ajax_prompt_builder_rollback() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( '权限不足。', 'zhiwrite-ai-writer' ) ), 403 );
		}
		check_ajax_referer( 'zhiwrite_ai_nonce', 'nonce' );

		$idx = isset( $_POST['idx'] ) ? (int) $_POST['idx'] : -1;
		if ( $idx < 0 ) {
			wp_send_json_error( array( 'message' => __( '参数错误。', 'zhiwrite-ai-writer' ) ), 400 );
		}

		$opts = ZhiWrite_AI_Writer_Settings::get_options();
		$revs = isset( $opts['prompt_builder_revisions'] ) && is_array( $opts['prompt_builder_revisions'] ) ? $opts['prompt_builder_revisions'] : array();
		if ( ! isset( $revs[ $idx ] ) || ! is_array( $revs[ $idx ] ) || empty( $revs[ $idx ]['data'] ) || ! is_array( $revs[ $idx ]['data'] ) ) {
			wp_send_json_error( array( 'message' => __( '未找到该历史版本。', 'zhiwrite-ai-writer' ) ), 404 );
		}

		// Push current into revisions, then restore selected.
		$current = isset( $opts['prompt_builder'] ) ? $opts['prompt_builder'] : array();
		array_unshift(
			$revs,
			array(
				'ts'   => time(),
				'data' => $current,
			)
		);
		$opts['prompt_builder'] = $revs[ $idx + 1 ]['data']; // +1 because we unshifted
		$opts['prompt_builder_revisions'] = array_slice( $revs, 0, 10 );
		update_option( ZhiWrite_AI_Writer_Settings::OPTION_KEY, $opts, false );

		wp_send_json_success( array( 'message' => __( '已回滚提示词构建器配置。', 'zhiwrite-ai-writer' ) ) );
	}

	public static function render_original_generation_metabox( $post ) {
		$post = is_object( $post ) ? $post : null;
		$post_id = $post && isset( $post->ID ) ? (int) $post->ID : 0;
		$raw = $post_id > 0 ? (string) get_post_meta( $post_id, '_zhiwrite_original_generation', true ) : '';
		$data = '' !== $raw ? json_decode( $raw, true ) : array();
		$data = is_array( $data ) ? $data : array();
		$ts = isset( $data['ts'] ) ? (int) $data['ts'] : 0;
		?>
		<div>
			<?php if ( '' === $raw ) : ?>
				<p class="description"><?php echo esc_html__( '暂无原始生成版本（仅在“仅展示结果”模式保存/发布时会自动记录）。', 'zhiwrite-ai-writer' ); ?></p>
			<?php else : ?>
				<p class="description">
					<?php
					echo esc_html__(
						'该文章保存了“原始生成版本”，可用于一键回滚覆盖当前内容。',
						'zhiwrite-ai-writer'
					);
					?>
					<?php if ( $ts > 0 ) : ?>
						<br />
						<?php echo esc_html( sprintf( __( '记录时间：%s', 'zhiwrite-ai-writer' ), gmdate( 'Y-m-d H:i:s', $ts ) ) ); ?>
					<?php endif; ?>
				</p>
				<p>
					<button type="button" class="button button-secondary" id="zhiwrite-rollback-original" data-post-id="<?php echo esc_attr( (string) $post_id ); ?>">
						<?php echo esc_html__( '回滚到原始版本', 'zhiwrite-ai-writer' ); ?>
					</button>
				</p>
			<?php endif; ?>
		</div>
		<?php
	}

	public static function ajax_rollback_post() {
		if ( ! current_user_can( ZhiWrite_AI_Writer_Settings::capability_generate() ) ) {
			wp_send_json_error( array( 'message' => __( '权限不足。', 'zhiwrite-ai-writer' ) ), 403 );
		}
		check_ajax_referer( 'zhiwrite_ai_nonce', 'nonce' );

		$post_id = isset( $_POST['post_id'] ) ? (int) $_POST['post_id'] : 0;
		if ( $post_id <= 0 || ! current_user_can( 'edit_post', $post_id ) ) {
			wp_send_json_error( array( 'message' => __( '无权操作该文章。', 'zhiwrite-ai-writer' ) ), 403 );
		}

		$raw = (string) get_post_meta( $post_id, '_zhiwrite_original_generation', true );
		if ( '' === $raw ) {
			wp_send_json_error( array( 'message' => __( '未找到原始生成版本。', 'zhiwrite-ai-writer' ) ), 200 );
		}
		$data = json_decode( $raw, true );
		$data = is_array( $data ) ? $data : array();
		$title = isset( $data['title'] ) ? sanitize_text_field( (string) $data['title'] ) : '';
		$excerpt = isset( $data['excerpt'] ) ? sanitize_textarea_field( (string) $data['excerpt'] ) : '';
		$content = isset( $data['content'] ) ? (string) $data['content'] : '';

		$upd = array(
			'ID'           => (int) $post_id,
			'post_title'   => '' !== $title ? $title : get_the_title( $post_id ),
			'post_excerpt' => (string) $excerpt,
			'post_content' => (string) $content,
		);
		$res = wp_update_post( $upd, true );
		if ( is_wp_error( $res ) ) {
			wp_send_json_error( array( 'message' => $res->get_error_message() ), 500 );
		}
		update_post_meta( $post_id, '_zhiwrite_rollback_at', time() );

		wp_send_json_success( array( 'message' => __( '已回滚到原始生成版本。', 'zhiwrite-ai-writer' ) ) );
	}

	public static function ajax_test_api() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( '权限不足。', 'zhiwrite-ai-writer' ) ), 403 );
		}
		check_ajax_referer( 'zhiwrite_ai_nonce', 'nonce' );

		$interface_id = isset( $_POST['interface_id'] ) ? sanitize_text_field( (string) wp_unslash( $_POST['interface_id'] ) ) : '';
		$api_base_url = isset( $_POST['api_base_url'] ) ? esc_url_raw( trim( (string) wp_unslash( $_POST['api_base_url'] ) ) ) : '';
		$api_key      = isset( $_POST['api_key'] ) ? sanitize_text_field( (string) wp_unslash( $_POST['api_key'] ) ) : '';
		$model        = isset( $_POST['model'] ) ? sanitize_text_field( (string) wp_unslash( $_POST['model'] ) ) : '';

		// If API key is not provided from the UI, fall back to stored interface config (do not expose key to frontend).
		if ( '' !== $interface_id && '' === $api_key ) {
			$iface = ZhiWrite_AI_Writer_Settings::get_interface( (string) $interface_id );
			if ( is_array( $iface ) ) {
				$api_base_url = '' !== $api_base_url ? $api_base_url : ( isset( $iface['api_base_url'] ) ? (string) $iface['api_base_url'] : '' );
				$api_key      = isset( $iface['api_key'] ) ? (string) $iface['api_key'] : '';
				$model        = '' !== $model ? $model : ( isset( $iface['model'] ) ? (string) $iface['model'] : '' );
			}
		}

		if ( '' === $api_base_url || '' === $api_key || '' === $model ) {
			wp_send_json_error(
				array( 'message' => __( '请先填写 API 接口地址、API Key 与默认模型名称（无需先保存，也可直接测试当前输入）。若该行已保存过 Key，则无需回填 Key，直接点“测试”即可。', 'zhiwrite-ai-writer' ) ),
				400
			);
		}

		$out = self::do_test_api( $api_base_url, $api_key, $model );
		if ( empty( $out['ok'] ) ) {
			wp_send_json_error(
				array(
					'message' => (string) $out['message'],
					'ms'      => (int) $out['ms'],
					'debug'   => isset( $out['debug'] ) ? $out['debug'] : array(),
					'advice'  => isset( $out['advice'] ) ? $out['advice'] : array(),
				),
				200
			);
		}
		wp_send_json_success(
			array(
				'message' => __( '连接成功。', 'zhiwrite-ai-writer' ),
				'ms'      => (int) $out['ms'],
				'debug'   => isset( $out['debug'] ) ? $out['debug'] : array(),
			)
		);
	}

	/**
	 * Batch test all configured interfaces.
	 */
	public static function ajax_test_api_all() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( '权限不足。', 'zhiwrite-ai-writer' ) ), 403 );
		}
		check_ajax_referer( 'zhiwrite_ai_nonce', 'nonce' );

		$opts       = ZhiWrite_AI_Writer_Settings::get_options();
		$interfaces = isset( $opts['interfaces'] ) && is_array( $opts['interfaces'] ) ? $opts['interfaces'] : array();

		$items = array();
		foreach ( $interfaces as $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}
			$id           = isset( $row['id'] ) ? sanitize_text_field( (string) $row['id'] ) : '';
			$name         = isset( $row['name'] ) ? sanitize_text_field( (string) $row['name'] ) : '';
			$api_base_url = isset( $row['api_base_url'] ) ? esc_url_raw( trim( (string) $row['api_base_url'] ) ) : '';
			$api_key      = isset( $row['api_key'] ) ? sanitize_text_field( (string) $row['api_key'] ) : '';
			$model        = isset( $row['model'] ) ? sanitize_text_field( (string) $row['model'] ) : '';

			if ( '' === $api_base_url || '' === $api_key || '' === $model ) {
				$items[] = array(
					'id'      => $id,
					'name'    => $name,
					'ok'      => 0,
					'message' => __( '跳过：接口地址/API Key/模型未填写完整。', 'zhiwrite-ai-writer' ),
					'ms'      => 0,
					'debug'   => array(
						'api_base_url' => $api_base_url,
						'model'        => $model,
					),
					'advice'  => array( __( '请先补全该行配置并保存（或在输入框里补全后单独点“测试”）。', 'zhiwrite-ai-writer' ) ),
				);
				continue;
			}

			$out      = self::do_test_api( $api_base_url, $api_key, $model );
			$items[]  = array(
				'id'      => $id,
				'name'    => $name,
				'ok'      => empty( $out['ok'] ) ? 0 : 1,
				'message' => (string) $out['message'],
				'ms'      => (int) $out['ms'],
				'debug'   => isset( $out['debug'] ) ? $out['debug'] : array(),
				'advice'  => isset( $out['advice'] ) ? $out['advice'] : array(),
			);
		}

		wp_send_json_success(
			array(
				'message' => __( '批量测试完成。', 'zhiwrite-ai-writer' ),
				'items'   => $items,
			)
		);
	}

	/**
	 * Low-level test runner for a single interface.
	 *
	 * @return array { ok, message, ms, debug, advice }
	 */
	private static function do_test_api( $api_base_url, $api_key, $model ) {
		$debug = array();
		$probe = self::probe_endpoint( (string) $api_base_url );
		if ( ! empty( $probe ) ) {
			$debug = array_merge( $debug, $probe );
		}

		$start = microtime( true );
		$res   = ZhiWrite_AI_Writer_API::chat_completions(
			array(
				'api_base_url' => (string) $api_base_url,
				'api_key'      => (string) $api_key,
				'model'        => (string) $model,
				// Keep test moderately fast; real generation uses configured retries/timeouts.
				'timeout'      => 60,
				'retry_times'  => 0,
				'retry_backoff_ms' => 0,
				'messages'     => array(
					array( 'role' => 'user', 'content' => 'ping' ),
				),
			)
		);
		$ms = (int) round( ( microtime( true ) - $start ) * 1000 );

		if ( isset( $res['meta'] ) && is_array( $res['meta'] ) ) {
			$debug = array_merge( $debug, $res['meta'] );
		}
		$debug['error_code'] = isset( $res['error_code'] ) ? (string) $res['error_code'] : '';

		if ( empty( $res['ok'] ) ) {
			return array(
				'ok'      => 0,
				'message' => (string) $res['error'],
				'ms'      => $ms,
				'debug'   => $debug,
				'advice'  => self::diagnose_api_error( $debug ),
			);
		}

		return array(
			'ok'      => 1,
			'message' => __( '连接成功。', 'zhiwrite-ai-writer' ),
			'ms'      => $ms,
			'debug'   => $debug,
			'advice'  => array(),
		);
	}

	/**
	 * Lightweight network probe: DNS resolve + TCP connect.
	 *
	 * @return array
	 */
	private static function probe_endpoint( $api_base_url ) {
		$api_base_url = trim( (string) $api_base_url );
		if ( '' === $api_base_url ) {
			return array();
		}
		$u = wp_parse_url( $api_base_url );
		if ( empty( $u['host'] ) ) {
			return array();
		}
		$host = (string) $u['host'];
		$port = isset( $u['port'] ) ? (int) $u['port'] : ( ( isset( $u['scheme'] ) && 'https' === strtolower( (string) $u['scheme'] ) ) ? 443 : 80 );

		$out = array(
			'host' => $host,
			'port' => $port,
		);

		// DNS.
		$t0 = microtime( true );
		$ip = @gethostbyname( $host );
		$out['dns_ms'] = (int) round( ( microtime( true ) - $t0 ) * 1000 );
		if ( is_string( $ip ) && '' !== $ip && $ip !== $host ) {
			$out['ip'] = $ip;
		}

		// TCP connect.
		$errno  = 0;
		$errstr = '';
		$t1     = microtime( true );
		$fp     = @fsockopen( $host, $port, $errno, $errstr, 5 );
		$out['tcp_ms'] = (int) round( ( microtime( true ) - $t1 ) * 1000 );
		if ( $fp ) {
			fclose( $fp );
			$out['tcp_ok'] = 1;
		} else {
			$out['tcp_ok']   = 0;
			$out['tcp_errno'] = (int) $errno;
			$out['tcp_error'] = (string) $errstr;
		}

		return $out;
	}

	/**
	 * Export plugin settings as JSON.
	 * POST: include_keys=1|0
	 */
	public static function ajax_export_settings() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( '权限不足。', 'zhiwrite-ai-writer' ) ), 403 );
		}
		check_ajax_referer( 'zhiwrite_ai_nonce', 'nonce' );

		$include_keys = ! empty( $_POST['include_keys'] ) ? 1 : 0;
		$opts         = ZhiWrite_AI_Writer_Settings::get_options();
		$payload      = array(
			'format'  => 'zhiwrite-ai-writer-settings',
			'version' => defined( 'ZHIWRITE_AI_WRITER_VERSION' ) ? (string) ZHIWRITE_AI_WRITER_VERSION : '0.0.0',
			'exported_at' => current_time( 'mysql' ),
			'options' => $opts,
		);

		if ( empty( $include_keys ) && isset( $payload['options']['interfaces'] ) && is_array( $payload['options']['interfaces'] ) ) {
			foreach ( $payload['options']['interfaces'] as $i => $row ) {
				if ( is_array( $row ) && isset( $row['api_key'] ) && '' !== (string) $row['api_key'] ) {
					$payload['options']['interfaces'][ $i ]['api_key'] = '***masked***';
				}
			}
			// Also mask legacy key if present.
			if ( isset( $payload['options']['api_key'] ) && '' !== (string) $payload['options']['api_key'] ) {
				$payload['options']['api_key'] = '***masked***';
			}
		}

		wp_send_json_success(
			array(
				'json' => wp_json_encode( $payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ),
			)
		);
	}

	/**
	 * Import plugin settings from JSON (overwrites current options).
	 * POST: json=<string>
	 */
	public static function ajax_import_settings() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( '权限不足。', 'zhiwrite-ai-writer' ) ), 403 );
		}
		check_ajax_referer( 'zhiwrite_ai_nonce', 'nonce' );

		$json_text = isset( $_POST['json'] ) ? (string) wp_unslash( $_POST['json'] ) : '';
		$json_text = trim( $json_text );
		if ( '' === $json_text ) {
			wp_send_json_error( array( 'message' => __( '请输入要导入的 JSON。', 'zhiwrite-ai-writer' ) ), 400 );
		}
		$data = json_decode( $json_text, true );
		if ( ! is_array( $data ) ) {
			wp_send_json_error( array( 'message' => __( 'JSON 解析失败，请检查格式。', 'zhiwrite-ai-writer' ) ), 400 );
		}

		// Accept both wrapped and raw options.
		$options_in = array();
		if ( isset( $data['options'] ) && is_array( $data['options'] ) ) {
			$options_in = $data['options'];
		} else {
			$options_in = $data;
		}

		$old = get_option( ZhiWrite_AI_Writer_Settings::OPTION_KEY, array() );
		// Sanitize using the same callback as Settings API.
		$sanitized = ZhiWrite_AI_Writer_Settings::sanitize( $options_in );

		// Guard: if user imported masked export, warn about missing real keys.
		$masked_detected = false;
		if ( isset( $options_in['interfaces'] ) && is_array( $options_in['interfaces'] ) ) {
			foreach ( $options_in['interfaces'] as $row ) {
				if ( is_array( $row ) && isset( $row['api_key'] ) && '***masked***' === (string) $row['api_key'] ) {
					$masked_detected = true;
					break;
				}
			}
		}
		update_option( ZhiWrite_AI_Writer_Settings::OPTION_KEY, $sanitized );

		// Add an explicit audit log with import source info (in addition to update_option hook).
		$meta = array(
			'format'      => isset( $data['format'] ) ? (string) $data['format'] : '',
			'version'     => isset( $data['version'] ) ? (string) $data['version'] : '',
			'exported_at' => isset( $data['exported_at'] ) ? (string) $data['exported_at'] : '',
			'changes'     => self::diff_options_for_audit( is_array( $old ) ? $old : array(), $sanitized ),
		);
		ZhiWrite_AI_Writer_DB::insert_log(
			array(
				'action' => 'settings_import',
				'meta'   => wp_json_encode( $meta ),
			)
		);

		$msg = __( '已导入并覆盖当前配置。', 'zhiwrite-ai-writer' );
		if ( $masked_detected ) {
			$msg .= ' ' . __( '注意：导入内容包含 ***masked***（脱敏导出）。请到“接口设置”补全真实 API Key。', 'zhiwrite-ai-writer' );
		}
		wp_send_json_success( array( 'message' => $msg ) );
	}

	/**
	 * Compare options for audit log: returns only high-signal diffs.
	 *
	 * @param array $old
	 * @param array $new
	 * @return array
	 */
	public static function diff_options_for_audit( array $old, array $new ) {
		$keys = array(
			'default_interface_id',
			'timeout',
			'retry_times',
			'retry_backoff_ms',
			'enable_editors',
			'default_post_status',
			'content_format',
			'system_context',
			'save_logs',
			'keep_data_on_uninstall',
			'interfaces',
		);
		$out = array();
		foreach ( $keys as $k ) {
			$ov = array_key_exists( $k, $old ) ? $old[ $k ] : null;
			$nv = array_key_exists( $k, $new ) ? $new[ $k ] : null;
			if ( $ov === $nv ) {
				continue;
			}
			if ( 'interfaces' === $k ) {
				$out[ $k ] = self::diff_interfaces_for_audit( $ov, $nv );
			} elseif ( 'system_context' === $k ) {
				$out[ $k ] = array(
					'old_len' => is_string( $ov ) ? strlen( $ov ) : 0,
					'new_len' => is_string( $nv ) ? strlen( $nv ) : 0,
				);
			} else {
				$out[ $k ] = array(
					'old' => $ov,
					'new' => $nv,
				);
			}
		}
		return $out;
	}

	private static function diff_interfaces_for_audit( $old, $new ) {
		$old_list = is_array( $old ) ? $old : array();
		$new_list = is_array( $new ) ? $new : array();

		$index = function ( $list ) {
			$map = array();
			foreach ( $list as $row ) {
				if ( ! is_array( $row ) ) {
					continue;
				}
				$id = isset( $row['id'] ) ? (string) $row['id'] : '';
				if ( '' === $id ) {
					continue;
				}
				$map[ $id ] = $row;
			}
			return $map;
		};

		$om = $index( $old_list );
		$nm = $index( $new_list );

		$added   = array();
		$removed = array();
		$changed = array();

		foreach ( $nm as $id => $row ) {
			if ( ! isset( $om[ $id ] ) ) {
				$added[] = array(
					'id'   => $id,
					'name' => isset( $row['name'] ) ? (string) $row['name'] : '',
				);
				continue;
			}
			$prev = $om[ $id ];
			$fields = array( 'name', 'api_base_url', 'model' );
			$delta  = array();
			foreach ( $fields as $f ) {
				$pv = isset( $prev[ $f ] ) ? (string) $prev[ $f ] : '';
				$nv = isset( $row[ $f ] ) ? (string) $row[ $f ] : '';
				if ( $pv !== $nv ) {
					$delta[ $f ] = array( 'old' => $pv, 'new' => $nv );
				}
			}
			// API key change: only record boolean, never store secrets.
			$pk = isset( $prev['api_key'] ) ? (string) $prev['api_key'] : '';
			$nk = isset( $row['api_key'] ) ? (string) $row['api_key'] : '';
			if ( $pk !== $nk ) {
				$delta['api_key_changed'] = true;
			}
			if ( ! empty( $delta ) ) {
				$changed[] = array(
					'id'     => $id,
					'name'   => isset( $row['name'] ) ? (string) $row['name'] : '',
					'delta'  => $delta,
				);
			}
		}

		foreach ( $om as $id => $row ) {
			if ( ! isset( $nm[ $id ] ) ) {
				$removed[] = array(
					'id'   => $id,
					'name' => isset( $row['name'] ) ? (string) $row['name'] : '',
				);
			}
		}

		return array(
			'added'   => $added,
			'removed' => $removed,
			'changed' => $changed,
			'count'   => array( 'old' => count( $old_list ), 'new' => count( $new_list ) ),
		);
	}

	private static function diagnose_api_error( array $debug ) {
		$code      = isset( $debug['http_code'] ) ? (int) $debug['http_code'] : 0;
		$errorcode = isset( $debug['error_code'] ) ? (string) $debug['error_code'] : '';
		$advice    = array();

		if ( 'non_json' === $errorcode ) {
			$advice[] = __( '接口返回了非 JSON 内容：常见原因是 API 接口地址未填写到 /v1，或被反向代理/防火墙拦截返回了 HTML。', 'zhiwrite-ai-writer' );
		}
		if ( 401 === $code || 403 === $code ) {
			$advice[] = __( '鉴权失败：请检查 API Key 是否正确，或中转是否需要额外的 Header/鉴权方式。', 'zhiwrite-ai-writer' );
		}
		if ( 404 === $code ) {
			$advice[] = __( '路径不存在：请确认 API 接口地址是 OpenAI 兼容的 /v1（例如 https://host/v1）。', 'zhiwrite-ai-writer' );
		}
		if ( 429 === $code ) {
			$advice[] = __( '触发限流：建议降低并发/减少重试次数，或更换额度更高的 Key/接口。', 'zhiwrite-ai-writer' );
		}
		if ( $code >= 500 ) {
			$advice[] = __( '上游服务异常（5xx）：可稍后重试，或切换到备用接口。', 'zhiwrite-ai-writer' );
		}
		if ( '' !== $errorcode && 0 === $code ) {
			$advice[] = __( '网络/连接层错误：请检查服务器是否能出网、DNS、以及 PHP 的 cURL/SSL 配置。', 'zhiwrite-ai-writer' );
		}

		return array_values( array_unique( $advice ) );
	}

	private static function maybe_log( array $row ) {
		$opts = ZhiWrite_AI_Writer_Settings::get_options();
		if ( empty( $opts['save_logs'] ) ) {
			return;
		}
		ZhiWrite_AI_Writer_DB::insert_log( $row );
	}

	/**
	 * Extract usage fields from API response meta (best-effort).
	 *
	 * @param array $api_res
	 * @return array { elapsed_ms, prompt_tokens, completion_tokens, total_tokens }
	 */
	private static function extract_usage_fields( array $api_res ) {
		$meta = isset( $api_res['meta'] ) && is_array( $api_res['meta'] ) ? $api_res['meta'] : array();
		return array(
			'elapsed_ms'        => isset( $meta['elapsed_ms'] ) ? (int) $meta['elapsed_ms'] : 0,
			'prompt_tokens'     => isset( $meta['prompt_tokens'] ) ? (int) $meta['prompt_tokens'] : 0,
			'completion_tokens' => isset( $meta['completion_tokens'] ) ? (int) $meta['completion_tokens'] : 0,
			'total_tokens'      => isset( $meta['total_tokens'] ) ? (int) $meta['total_tokens'] : 0,
		);
	}

	private static function system_prompt( $do_seo, $do_terms, $do_disclaimer, $content_format = '' ) {
		$opts = ZhiWrite_AI_Writer_Settings::get_options();
		$parts   = array();
		$parts[] = '你是一个专业的内容写作助手，面向 WordPress 文章写作。';
		$parts[] = '你必须只输出 JSON，不要输出任何其它文字、Markdown 代码块或解释。';
		$parts[] = 'JSON 结构：{ "title": string, "excerpt": string, "slug": string, "focus_keyword": string, "content": string, "categories": string[], "tags": string[], "faq": { "q": string, "a": string }[], "verify_points": string[], "source_hints": string[] }';
		$parts[] = 'content 字段必须只输出正文内容本身，不要包含 JSON 以外的包装。';
		$format = '' !== (string) $content_format ? (string) $content_format : ZhiWrite_AI_Writer_Settings::CONTENT_FORMAT_WP_HTML;
		if ( ZhiWrite_AI_Writer_Settings::CONTENT_FORMAT_MARKDOWN === $format ) {
			$parts[] = '正文格式：Markdown（不要输出 ``` 代码块围栏；直接输出 Markdown 正文）。';
		} else {
			$parts[] = '正文格式：HTML（适配 WordPress，使用 <h2><h3><p><ul><ol><li><strong><em><a> 等常见标签；不要输出 Markdown）。';
		}
		$parts[] = 'slug 使用短横线小写英文或拼音，尽量简短。';

		// Site/system context (helps align tone and constraints).
		$site_name = get_bloginfo( 'name' );
		$tagline   = get_bloginfo( 'description' );
		$site_url  = home_url( '/' );
		$locale    = function_exists( 'get_locale' ) ? get_locale() : '';
		$timezone  = function_exists( 'wp_timezone_string' ) ? wp_timezone_string() : '';
		$parts[]   = '【站点信息】';
		$parts[]   = '站点名称：' . ( '' !== (string) $site_name ? (string) $site_name : '（未设置）' );
		$parts[]   = '站点简介：' . ( '' !== (string) $tagline ? (string) $tagline : '（未设置）' );
		$parts[]   = '站点 URL：' . (string) $site_url;
		if ( '' !== (string) $locale ) {
			$parts[] = '站点语言：' . (string) $locale;
		}
		if ( '' !== (string) $timezone ) {
			$parts[] = '站点时区：' . (string) $timezone;
		}

		$system_context = isset( $opts['system_context'] ) ? trim( (string) $opts['system_context'] ) : '';
		if ( '' !== $system_context ) {
			$parts[] = '【系统信息/业务背景】';
			$parts[] = self::filter_outbound_text( $system_context );
		}

		if ( ! $do_seo ) {
			$parts[] = '不需要 SEO 字段时，也请保持字段存在但可留空字符串。';
		}
		if ( ! $do_terms ) {
			$parts[] = '不需要分类/标签建议时，categories 与 tags 输出空数组。';
		}
		if ( $do_disclaimer ) {
			$parts[] = '在正文末尾追加一段简短免责声明：内容仅供参考，需结合实际验证。';
		}
		if ( empty( $opts['faq_enabled'] ) ) {
			$parts[] = '不需要 FAQ 时，faq 输出空数组。';
		} else {
			$n = isset( $opts['faq_count'] ) ? (int) $opts['faq_count'] : 5;
			$n = max( 1, min( 15, $n ) );
			$parts[] = sprintf( '请输出 FAQ（问答）数组 faq，包含 %d 条，每条包含 q 与 a。', $n );
		}
		if ( empty( $opts['fact_check_enabled'] ) ) {
			$parts[] = '不需要事实核查时，verify_points 与 source_hints 输出空数组。';
		} else {
			$parts[] = '请额外输出 verify_points（可验证要点清单，5-12 条）与 source_hints（建议引用来源类型/查询关键词，3-8 条）。这些仅用于人工核查，不要编造引用链接。';
		}
		return implode( "\n", $parts );
	}

	private static function user_prompt( $title, $prompt ) {
		$out  = '';
		$out .= "主题/标题（可为空）：\n" . ( '' !== $title ? $title : '（未提供）' ) . "\n\n";
		$out .= "写作需求：\n" . $prompt . "\n";
		return $out;
	}

	private static function prompt_builder_system_append( $template_id, $style_id, $vars_override_raw, $title, $prompt, array $opts ) {
		$pb = isset( $opts['prompt_builder'] ) && is_array( $opts['prompt_builder'] ) ? $opts['prompt_builder'] : array();
		$vars = isset( $pb['vars'] ) && is_array( $pb['vars'] ) ? $pb['vars'] : array();

		// Builtins (always available).
		$vars['date']      = gmdate( 'Y-m-d' );
		$vars['site_name'] = '' !== (string) ( $vars['site_name'] ?? '' ) ? (string) $vars['site_name'] : (string) get_bloginfo( 'name' );
		$vars['site_url']  = home_url();
		$vars['title']     = (string) $title;
		$vars['prompt']    = (string) $prompt;

		$override = trim( (string) $vars_override_raw );
		if ( '' !== $override ) {
			$decoded = json_decode( $override, true );
			if ( is_array( $decoded ) ) {
				foreach ( $decoded as $k => $v ) {
					$k = sanitize_key( (string) $k );
					if ( '' === $k ) {
						continue;
					}
					$vars[ $k ] = is_scalar( $v ) ? (string) $v : '';
				}
			}
		}

		$tpl_text = '';
		$style_text = '';
		$tpls = isset( $pb['templates'] ) && is_array( $pb['templates'] ) ? $pb['templates'] : array();
		$styles = isset( $pb['styles'] ) && is_array( $pb['styles'] ) ? $pb['styles'] : array();

		$template_id = sanitize_key( (string) $template_id );
		$style_id    = sanitize_key( (string) $style_id );
		if ( '' === $template_id && isset( $pb['default_template_id'] ) ) {
			$template_id = sanitize_key( (string) $pb['default_template_id'] );
		}
		if ( '' === $style_id && isset( $pb['default_style_id'] ) ) {
			$style_id = sanitize_key( (string) $pb['default_style_id'] );
		}

		foreach ( $tpls as $t ) {
			if ( ! is_array( $t ) ) {
				continue;
			}
			if ( isset( $t['id'] ) && (string) $t['id'] === (string) $template_id ) {
				$tpl_text = isset( $t['content'] ) ? (string) $t['content'] : '';
				break;
			}
		}
		foreach ( $styles as $s ) {
			if ( ! is_array( $s ) ) {
				continue;
			}
			if ( isset( $s['id'] ) && (string) $s['id'] === (string) $style_id ) {
				$style_text = isset( $s['content'] ) ? (string) $s['content'] : '';
				break;
			}
		}

		$tpl_text   = self::replace_vars( $tpl_text, $vars );
		$style_text = self::replace_vars( $style_text, $vars );

		$append = '';
		if ( '' !== trim( $tpl_text ) || '' !== trim( $style_text ) ) {
			$append .= "\n\n【提示词构建器】\n";
			if ( '' !== trim( $tpl_text ) ) {
				$append .= "【模板】\n" . trim( $tpl_text ) . "\n";
			}
			if ( '' !== trim( $style_text ) ) {
				$append .= "【风格预设】\n" . trim( $style_text ) . "\n";
			}
		}
		return $append;
	}

	private static function replace_vars( $text, array $vars ) {
		$text = (string) $text;
		if ( '' === $text || empty( $vars ) ) {
			return $text;
		}
		foreach ( $vars as $k => $v ) {
			$k = (string) $k;
			if ( '' === $k ) {
				continue;
			}
			$text = str_replace( '{{' . $k . '}}', (string) $v, $text );
		}
		return $text;
	}

	private static function parse_response_json( $text ) {
		$text = trim( (string) $text );
		// Try to extract JSON object even if model added noise.
		$start = strpos( $text, '{' );
		$end   = strrpos( $text, '}' );
		if ( false !== $start && false !== $end && $end > $start ) {
			$text = substr( $text, $start, $end - $start + 1 );
		}
		$data = json_decode( $text, true );
		if ( ! is_array( $data ) ) {
			return array(
				'title'         => '',
				'excerpt'       => '',
				'slug'          => '',
				'focus_keyword' => '',
				'content'       => '',
				'categories'    => array(),
				'tags'          => array(),
				'faq'           => array(),
				'verify_points' => array(),
				'source_hints'  => array(),
			);
		}
		return array(
			'title'         => isset( $data['title'] ) ? (string) $data['title'] : '',
			'excerpt'       => isset( $data['excerpt'] ) ? (string) $data['excerpt'] : '',
			'slug'          => isset( $data['slug'] ) ? (string) $data['slug'] : '',
			'focus_keyword' => isset( $data['focus_keyword'] ) ? (string) $data['focus_keyword'] : '',
			'content'       => isset( $data['content'] ) ? (string) $data['content'] : '',
			'categories'    => isset( $data['categories'] ) && is_array( $data['categories'] ) ? array_values( $data['categories'] ) : array(),
			'tags'          => isset( $data['tags'] ) && is_array( $data['tags'] ) ? array_values( $data['tags'] ) : array(),
			'faq'           => isset( $data['faq'] ) && is_array( $data['faq'] ) ? array_values( $data['faq'] ) : array(),
			'verify_points' => isset( $data['verify_points'] ) && is_array( $data['verify_points'] ) ? array_values( $data['verify_points'] ) : array(),
			'source_hints'  => isset( $data['source_hints'] ) && is_array( $data['source_hints'] ) ? array_values( $data['source_hints'] ) : array(),
		);
	}

	/**
	 * Conditionally mask basic PII (email, phone, simple IDs) from free text before sending to model/logs.
	 *
	 * @param string $text
	 * @return string
	 */
	private static function filter_outbound_text( $text ) {
		$text = (string) $text;
		if ( '' === $text ) {
			return $text;
		}
		$opts = ZhiWrite_AI_Writer_Settings::get_options();

		// 1) PII masking.
		if ( ! empty( $opts['privacy_pii_mask'] ) ) {
			$text = self::mask_basic_pii( $text );
		}

		// 2) Field blocking/redaction by keywords (line-based).
		if ( ! empty( $opts['privacy_block_enabled'] ) ) {
			$keywords_raw = isset( $opts['privacy_block_keywords'] ) ? (string) $opts['privacy_block_keywords'] : '';
			$keywords_raw = trim( $keywords_raw );
			if ( '' !== $keywords_raw ) {
				$keywords = preg_split( "/\r\n|\n|\r/", $keywords_raw );
				$keywords = is_array( $keywords ) ? $keywords : array();
				$keywords = array_values(
					array_filter(
						array_map(
							static function ( $k ) {
								return trim( (string) $k );
							},
							$keywords
						),
						static function ( $k ) {
							return '' !== (string) $k;
						}
					)
				);

				if ( ! empty( $keywords ) ) {
					$lines = preg_split( "/\r\n|\n|\r/", $text );
					$lines = is_array( $lines ) ? $lines : array( $text );
					foreach ( $lines as $i => $line ) {
						$line_s = (string) $line;
						foreach ( $keywords as $kw ) {
							if ( false !== stripos( $line_s, (string) $kw ) ) {
								// Replace value after common separators to keep structure.
								$lines[ $i ] = preg_replace( '/([:=：]\s*).*/u', '$1***removed***', $line_s );
								if ( null === $lines[ $i ] || '' === (string) $lines[ $i ] ) {
									$lines[ $i ] = (string) $kw . ': ***removed***';
								}
								break;
							}
						}
					}
					$text = implode( "\n", $lines );
				}
			}
		}

		return $text;
	}

	private static function mask_basic_pii( $text ) {
		$text = (string) $text;
		if ( '' === $text ) {
			return $text;
		}

		// Mask email addresses: keep first 2 chars of local-part, mask the rest.
		$text = preg_replace_callback(
			'/([a-zA-Z0-9._%+\-]{1,64})@([a-zA-Z0-9.\-]+\.[A-Za-z]{2,})/',
			static function ( $m ) {
				$name   = isset( $m[1] ) ? (string) $m[1] : '';
				$domain = isset( $m[2] ) ? (string) $m[2] : '';
				if ( '' === $name ) {
					return '***@' . $domain;
				}
				$len      = strlen( $name );
				$visible  = substr( $name, 0, min( 2, $len ) );
				$masked   = str_repeat( '*', max( 1, $len - strlen( $visible ) ) );
				return $visible . $masked . '@' . $domain;
			},
			$text
		);

		// Mask Mainland China-like mobile numbers: 1[3-9]XXXXXXXXX -> 1xx****xxxx.
		$text = preg_replace_callback(
			'/\b(1[3-9]\d{9})\b/',
			static function ( $m ) {
				$num = isset( $m[1] ) ? (string) $m[1] : '';
				if ( strlen( $num ) !== 11 ) {
					return '***';
				}
				return substr( $num, 0, 3 ) . '****' . substr( $num, -4 );
			},
			$text
		);

		// Generic sequences of 8–20 digits (possible IDs/order numbers) -> partially masked.
		$text = preg_replace_callback(
			'/\b(\d{8,20})\b/',
			static function ( $m ) {
				$num = isset( $m[1] ) ? (string) $m[1] : '';
				$len = strlen( $num );
				if ( $len < 8 ) {
					return $num;
				}
				$head  = substr( $num, 0, 3 );
				$tail  = substr( $num, -2 );
				$stars = str_repeat( '*', max( 3, $len - 5 ) );
				return $head . $stars . $tail;
			},
			$text
		);

		return $text;
	}
}


